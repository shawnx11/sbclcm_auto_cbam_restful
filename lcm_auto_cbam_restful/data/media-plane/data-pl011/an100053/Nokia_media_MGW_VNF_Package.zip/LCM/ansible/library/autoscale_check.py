#!/usr/bin/env python

import getopt,sys,os,time

def main(argv):
    try:
        opts, args = getopt.getopt(argv[1:],
                    'hva:r:',
                    ['help'])
    except getopt.GetoptError as err:
        print('ERROR: Invalid arguments: ' + str(err))
        sys.exit(1)

    filename = args[0]
    max_vms_num = int(args[1])
    curr_vms_num = int(args[2])
    scale_out_threshold = float(args[3])
    scale_in_threshold = float(args[4])
    vm_type = args[5]
    platform = args[6]
    quiet_period = int(args[7])
    time_file = args[8]
    pim_cpuload_avg = []

    if vm_type not in ('pim', 'mcm'):
        print False
        return

    if platform not in ('OpenStack', 'VMWare'):
        print False
        return

    for keyword in ['PIM_OBC_AVG_MIN', 'PIM_NPU_LOAD_RX_AVG_MIN', 'PIM_NPU_LOAD_RT_AVG_MIN', 'PIM_NPU_LOAD_NRT_AVG_MIN', 'MCM_LOAD_MAX', 'CURRENT_INTERVAL_TIME', 'CURRENT_UPTIME']:
        cmd = "grep -w %s %s|cut -d':' -f2 |sed 's/ //g'"%(keyword, filename)
        result = os.popen(cmd).read().split()
        try:
            result = float(result[0].strip('%'))
        except:
            print False
            return
        if keyword in ['PIM_OBC_AVG_MIN', 'PIM_NPU_LOAD_RX_AVG_MIN', 'PIM_NPU_LOAD_RT_AVG_MIN', 'PIM_NPU_LOAD_NRT_AVG_MIN']:
            pim_cpuload_avg.append(result)
        elif keyword == 'MCM_LOAD_MAX':
            mcm_load_max = result
        elif keyword == 'CURRENT_INTERVAL_TIME':
            cur_interval_time = int(result)
        else:
            cur_uptime = int(result)
    
    pim_load_max = max(pim_cpuload_avg)

    if time_file == "NULL":
        pim_last_scale_time = 0
        mcm_last_scale_time = 0
        pim_last_up_time = 0
        mcm_last_up_time = 0
    else:
        for keyword in ['PIM', 'MCM', 'PIM_Uptime', 'MCM_Uptime']:
            cmd = "grep -w %s %s|cut -d':' -f2 |sed 's/ //g'"%(keyword, time_file)
            result = os.popen(cmd).read().split()
            try:
                result = int(result[0])
            except:
                print False
                return
            if (keyword == 'PIM'):
                pim_last_scale_time = result
            elif (keyword == 'MCM'):
                mcm_last_scale_time = result
            elif (keyword == 'PIM_Uptime'):
                pim_last_up_time = result
            else:
                mcm_last_up_time = result

    if vm_type in ('pim'):
        #pim_last_scale_time is the time of pim last scale-out/in finishing, cur_interval_time is the time of v7510 history load statistics
        #pim_last_up_time is the time of active scm's up time when pim last scale-out/in finishing
        #cur_uptime is the time of current active scm's up time
        if not(((cur_interval_time > (pim_last_scale_time + quiet_period)) and (cur_uptime > (pim_last_up_time + quiet_period))) or (cur_uptime > (pim_last_up_time + quiet_period*2))):
            print False
            return

        if (pim_load_max > scale_out_threshold):
            if curr_vms_num == max_vms_num:
                print False
                return
            else:
                if platform in ('OpenStack'):
                    stepnum = 1
                else:
                    stepnum = 2

                scale_type = "OUT"
                print scale_type
                print stepnum
                return
        elif (pim_load_max < scale_in_threshold):
            if platform in ('OpenStack'):
                if curr_vms_num <= 1:
                    print False
                    return
            else:
                if curr_vms_num <= 2:
                    print False
                    return

            if platform in ('OpenStack'):
                stepnum = 1
            else:
                stepnum = 2

            scale_type = "IN"
            print scale_type
            print stepnum
            return
        else:
            print False
            return
    else:
        #mcm_last_scale_time is the time of mcm last scale-out/in finishing, cur_interval_time is the time of v7510 history load statistics
        #mcm_last_up_time is the time of active scm's up time when mcm last scale-out/in finishing
        if not (((cur_interval_time > (mcm_last_scale_time + quiet_period)) and (cur_uptime > (mcm_last_up_time + quiet_period))) or (cur_uptime > (mcm_last_up_time + quiet_period*2))):
            print False
            return

        if (mcm_load_max > scale_out_threshold):
            if curr_vms_num == max_vms_num:
                print False
                return
            elif curr_vms_num == 0 or curr_vms_num == 7:
                stepnum = 2
            else:
                stepnum = 1

            if (curr_vms_num+stepnum) > max_vms_num:
                print False
                return
            else:
                scale_type = "OUT"
                print scale_type
                print stepnum
                return
        elif (mcm_load_max < scale_in_threshold):
            if curr_vms_num <= 2:
                print False
                return
            elif curr_vms_num == 9:
                stepnum = 2
            else:
                stepnum = 1

            if (curr_vms_num - stepnum) < 2:
                print False
                return
            else:
                scale_type = "IN"
                print scale_type
                print stepnum
                return
        else:
            print False
            return

if __name__ == "__main__":
    main(sys.argv)
