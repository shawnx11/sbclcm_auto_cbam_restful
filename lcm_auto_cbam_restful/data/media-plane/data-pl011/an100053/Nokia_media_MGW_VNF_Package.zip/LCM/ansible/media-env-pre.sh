#!/bin/bash
. ./media-env-vars.sh

sed -i '/log_path/d' ansible.cfg
echo log_path = $ANSIBLE_LOG/ansible.log >> ansible.cfg

if [[ ! -d $ANSIBLE_LOG ]]; then
    mkdir $ANSIBLE_LOG
fi
if [[ ! -d $MEDIA_LOG ]]; then
    mkdir $MEDIA_LOG
fi

ENV_FILE="./inventory/group_vars/all/cloud-env.yml"
echo "---" > $ENV_FILE
echo "# Global environment Variable" >> $ENV_FILE
echo " " >> $ENV_FILE
echo "vars:" >> $ENV_FILE

#echo "platform: \"$platform\"" >> $ENV_FILE
echo "deploy_via_media_oam: \"$deploy_via_media_oam\"" >> $ENV_FILE
echo "home_path: \"$GUEST_DATA\"" >> $ENV_FILE
echo "playbook_dir: \"$MEDIA_PLAYBOOKS\"" >> $ENV_FILE
echo "config_drive_path: \"$CONFIG_DRIVE\"" >> $ENV_FILE
echo "media_config_drive_path: \"$MEDIA_CONFIG_DRIVE\"" >> $ENV_FILE
echo "media_log_path: \"$MEDIA_LOG\"" >> $ENV_FILE
# 
#echo "oam_vm_super_user: \"lcmadm\"" >> $ENV_FILE
#echo "oam_vm_normal_user: \"lcmadm\"" >> $ENV_FILE

echo "env preparation Succeed!"
