#!/usr/bin/env bash

path=$1
scm_tipc_ip=$2
user=$3
key_file=$4
shift 4
ip_arraystring=$*
temp1=$(echo $ip_arraystring|sed s/[[:space:]]//g)
temp=$(echo $temp1|cut -d "[" -f 2)
ip_array=$(echo $temp|cut -d ']' -f 1)
OLD_IFS="$IFS"
IFS=","
array=($ip_array)

if [[ ! -f $key_file ]]
then
   echo "There is no $key_file on this host"
   exit 1
fi

IFS="$OLD_IFS"
for tempip in ${array[*]}
do
  ip=$(echo $tempip|cut -d 'u' -f 2)
  if [ "$ip" != "$scm_tipc_ip" ]
  then 
    #transfer key.pem to vm
    scp -o StrictHostKeyChecking=no -i $key_file $key_file $user@$ip:$key_file
    #create tar
    ssh -t -o StrictHostKeyChecking=no $user@$ip -i $key_file "cd $path;sudo tar -czvpf $ip.tar.gz ./ --exclude=*.RPM --exclude=$ip.tar.gz --exclude=.vmware_delay;sudo chmod 0777 $ip.tar.gz"
    #transfer tar to scm
    ssh -t $user@$ip -i $key_file -o StrictHostKeyChecking=no "scp -o StrictHostKeyChecking=no -i $key_file $path/$ip.tar.gz $user@$scm_tipc_ip:/mnt/backup;rm -rf $path/$ip.tar.gz"
    #cleanup - delete key file from vm
    ssh -t $user@$ip -i $key_file -o StrictHostKeyChecking=no "sudo rm -f $key_file;echo $key_file existed on $ip,has been deleted"
  fi
done
# ------now SCM-----------
#create tar on SCM (localhost)
cd $path;sudo tar -czvpf $scm_tipc_ip.tar.gz ./ --exclude=*.RPM --exclude=$scm_tipc_ip.tar.gz --exclude=.vmware_delay;sudo chmod 0777 $scm_tipc_ip.tar.gz
#scm - transfer tar to /mnt/backup
sudo cp $path/$scm_tipc_ip.tar.gz /mnt/backup;rm -f $path/$scm_tipc_ip.tar.gz
#cleanup - delete key file from scm
sudo rm -f $key_file;echo "$key_file existed on $scm_tipc_ip, has been deleted"

sleep 30s;

