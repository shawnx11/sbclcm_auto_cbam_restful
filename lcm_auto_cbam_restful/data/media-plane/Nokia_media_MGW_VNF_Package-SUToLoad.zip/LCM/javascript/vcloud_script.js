var script=[
"#!/bin/sh", 
"echo \"$1\" >> /root/params",
"if [ \"x$1\" = \"xprecustomization\" ]; then", 
"  export LC_ALL=\"en_US.UTF-8\"", 
"fi", 
"if [ \"x$1\" = \"xpostcustomization\" ]; then", 
"cd /opt/v7510/bin/",
"./cloud_init_disable.sh",
"./v7510_OS_vmware_tools_script.sh",
"fi", 
"exit 0"
].join("\n")


function isNumeric(n) {
 return !isNaN(parseFloat(n)) && isFinite(n)
}
function getCustomization(imageId){
  if(imageId.includes("scm"))
  {
   return script;
   }
  if(imageId.includes("pim"))
  {
   return script;
   }
  if(imageId.includes("mcm"))
  {
   return script;
   }
}


function processaffinityRules(cbam) {
   //var keyname="ruleId";
   var keyname="ruleName";
   var affinityRulesArr = [];
   var pimRuleNum=8;
   var mcmRuleNum=2;
   var BaseName="";
   if (cbam.extensions.media_params.affinity_config.SCM == "anti-affinity"){
       //add scm AntiAffinityRule
       var scmAffinityRulesObj = {"isAnti":true, "cbamIds":["SCM_Server_Pair.0.server","SCM_Server_Pair.1.server"]};
       scmAffinityRulesObj[keyname]= "scmAntiAffinityRule";
       affinityRulesArr.push(scmAffinityRulesObj);
   }
   
   if (cbam.extensions.media_params.affinity_config.PIM == "anti-affinity"){
       //add pim AntiAffinityRule
       for (var i=0;i<pimRuleNum;i++){
           var ruleIndex=i+1;
           var ruleName=BaseName.concat("pim",ruleIndex,"AntiAffinityRule");
           var pim1Name=BaseName.concat("PIM_Server_Pair_Group",".",(2*i),".","server");
           var pim2Name=BaseName.concat("PIM_Server_Pair_Group",".",(2*i+1),".","server");         
           var pimAffinityRulesObj = {"isAnti":true, "cbamIds":[pim1Name,pim2Name]};
           pimAffinityRulesObj[keyname]= ruleName;
           affinityRulesArr.push(pimAffinityRulesObj);
       }
   }
   if (cbam.extensions.media_params.affinity_config.MCM == "anti-affinity"){
       //add mcm AntiAffinityRule
       var mcmNumPerRedGroup=7;
       for (var i=0;i<mcmRuleNum;i++){
           var ruleIndex=i+1;
           var ruleName=BaseName.concat("mcm",ruleIndex,"AntiAffinityRule");
           var mcms=[];
           for (var j=0;j<mcmNumPerRedGroup;j++){
               var mcmName=BaseName.concat("MCM_Server_Group",".",(i*7+j),".","server");
               mcms.push(mcmName);
           }
           var mcmAffinityRulesObj = {"isAnti":true, "cbamIds":mcms};
           mcmAffinityRulesObj[keyname]= ruleName;
           affinityRulesArr.push(mcmAffinityRulesObj);
       }
   }
   cbam.affinityRules=affinityRulesArr.slice();
   return cbam;
}

function processServer(cbam, zones, templateName,aspectGroup) {
  var serverIndex = -1;
  var zoneCount = 0;
  var zoneIndexArray = [];
  for(var zone in zones){
     zoneIndexArray[zoneCount] = zone;
     zoneCount++;
   }
  var zonescmPrefix="zoneSCM";
  var zonepimPrefix="zonePIM";
  var zonemcmPrefix="zoneMCM";
  var nicCount = 0;
  var externalnicPrefix = "nic_"
  var vnf_name = cbam.extensions.media_params.vnf_name;
  var nicsInterfaceName = "";    
  for(var step in aspectGroup){
    if(isNumeric(step)){  
      serverIndex = aspectGroup[step]._mappedIndexNumeric;
      serverId = aspectGroup[step]._mappedIndex;
      aspectGroup[step].server.configuration = { };
      aspectGroup[step].server.configuration.loginUsername = "cloud-user";
      aspectGroup[step].server.configuration.publicSshKey = cbam.publicSshKey;
      aspectGroup[step].server.configuration.bgw_id = cbam.extensions.media_params.cbam_bgw_id;
      aspectGroup[step].server.templateName = templateName;
      aspectGroup[step].server.script = getCustomization(aspectGroup[step].server.imageId);
      if(aspectGroup[step].server.vduId == 'SCM_Server'){
        if(cbam.extensions.media_params.vm_metadata.SCM[serverIndex].metadata[0].type !== "null"){
          aspectGroup[step].server.vmMetadata = cbam.extensions.media_params.vm_metadata.SCM[serverIndex].metadata.slice(0);
        }
        scmZoneName = zonescmPrefix.concat(serverIndex);
        aspectGroup[step].server.azId = zones[scmZoneName].zoneId;
        aspectGroup[step].server.name = vnf_name.concat(cbam.extensions.media_params.vm_name.SCM[serverIndex])
        aspectGroup[step].server.configuration.nbr_bearer = cbam.extensions.media_params.cbam_nbr_bearer.vscm;
        aspectGroup[step].server.configuration.slot = cbam.extensions.media_params.cbam_appl_id.SCM[serverIndex];
        aspectGroup[step].server.configuration.tipc_ip = cbam.extensions.media_params.tipc_network_ip_config.SCM[serverIndex];
        if(typeof(cbam.extensions.media_params.provider_networks.SCM.OAM.ipv4)!='undefined')
        {
          aspectGroup[step].server.configuration.scm_oam_ipv4_ip = cbam.extensions.media_params.provider_networks.SCM.OAM.ipv4.fixed_ips[serverIndex];
          aspectGroup[step].server.configuration.scm_oam_ipv4_cidr = cbam.extensions.media_params.provider_networks.SCM.OAM.ipv4.cidr;
          aspectGroup[step].server.configuration.scm_oam_ipv4_gw = cbam.extensions.media_params.provider_networks.SCM.OAM.ipv4.gw;
        }
        if(typeof(cbam.extensions.media_params.provider_networks.SCM.OAM.ipv6)!='undefined')
        {
          aspectGroup[step].server.configuration.scm_oam_ipv6_ip = cbam.extensions.media_params.provider_networks.SCM.OAM.ipv6.fixed_ips[serverIndex];
          aspectGroup[step].server.configuration.scm_oam_ipv6_cidr = cbam.extensions.media_params.provider_networks.SCM.OAM.ipv6.cidr;
          aspectGroup[step].server.configuration.scm_oam_ipv6_gw = cbam.extensions.media_params.provider_networks.SCM.OAM.ipv6.gw;
        }
        aspectGroup[step].server.nics =  { "nic_0":{ "expectIp" : true, "ipAddress": cbam.extensions.media_params.tipc_network_ip_config.SCM.serverId} };
        aspectGroup[step].server.nics["nic_1"] = { "nic_1": { "expectIp" : true } };
        aspectGroup[step].server.nics["nic_2"] = { "nic_2": { "expectIp" : true } };
       }

     if(aspectGroup[step].server.vduId == 'PIM_Server'){
        if(cbam.extensions.media_params.vm_metadata.PIM[serverIndex].metadata[0].type !== "null"){
          aspectGroup[step].server.vmMetadata = cbam.extensions.media_params.vm_metadata.PIM[serverIndex].metadata.slice(0);
        }
        pimZoneName = zonepimPrefix.concat(serverIndex%2);
        aspectGroup[step].server.azId = zones[pimZoneName].zoneId;
        aspectGroup[step].server.name = vnf_name.concat(cbam.extensions.media_params.vm_name.PIM[serverIndex]);
        aspectGroup[step].server.configuration.tipc_ip = cbam.extensions.media_params.tipc_network_ip_config.PIM[serverIndex];
        aspectGroup[step].server.configuration.slot = cbam.extensions.media_params.cbam_appl_id.PIM[serverIndex];
        aspectGroup[step].server.configuration.nbr_bearer = cbam.extensions.media_params.cbam_nbr_bearer.vpim;
        // nic adaption
        aspectGroup[step].server.nics = { "nic_0": { "expectIp" : true } };
        aspectGroup[step].server.nics["nic_1"] = { "nic_1": { "expectIp" : true } };
        var voiceindexint = parseInt(aspectGroup[step].server.configuration.nbr_bearer);
          if (isNumeric(voiceindexint)){
            for(var nicCount=0;nicCount<voiceindexint;nicCount++)
              {
                nicsInterfaceName = externalnicPrefix.concat(nicCount+2);
                aspectGroup[step].server.nics[nicsInterfaceName] = { [nicsInterfaceName]: { "expectIp" : true } };
              }
          }
      }
      if(aspectGroup[step].server.vduId == 'MCM_Server'){
        if(cbam.extensions.media_params.vm_metadata.MCM[serverIndex].metadata[0].type !== "null"){
          aspectGroup[step].server.vmMetadata = cbam.extensions.media_params.vm_metadata.MCM[serverIndex].metadata.slice(0);
        }
        mcmZoneName = zonemcmPrefix.concat(serverIndex);
        aspectGroup[step].server.azId = zones[mcmZoneName].zoneId;
        aspectGroup[step].server.name = vnf_name.concat(cbam.extensions.media_params.vm_name.MCM[serverIndex]);
        aspectGroup[step].server.configuration.tipc_ip = cbam.extensions.media_params.tipc_network_ip_config.MCM[serverIndex]
        aspectGroup[step].server.configuration.slot = cbam.extensions.media_params.cbam_appl_id.MCM[serverIndex];
        aspectGroup[step].server.configuration.nbr_bearer = cbam.extensions.media_params.cbam_nbr_bearer.vmcm;
         aspectGroup[step].server.nics = { "nic_0": { "expectIp" : true } };
         aspectGroup[step].server.nics["nic_1"] = { "nic_1": { "expectIp" : true } };
      }	 
         aspectGroup[step].server.configuration.hostname = aspectGroup[step].server.name  
    }  
  }
  return aspectGroup;
}
function processResources(cbam, zones, templateName) {
  for (var aspectGroupID in cbam.resources){
    cbam.resources[aspectGroupID] = processServer(cbam, zones, templateName, cbam.resources[aspectGroupID]);
  }
  return cbam.resources
}
function prepare_stack_params(operation_params,resource_model,stack_params)
{
   var op_type = "";
   if (typeof($.operation_params) !== "undefined") {
     if ( ("flavourId" in $.operation_params) || ("instantiationLevelId" in $.operation_params) ) {	
        op_type = "INSTANTIATE";
         }
     else
       op_type = "other";
   }
   else
     op_type = "other";
     if (op_type == "INSTANTIATE")
        stack_params.cbam.templateName = stack_params.cbam.extensions.template_name;
     else 
     {
       for(var step in resource_model.resources.SCM_Server_Pair.resources)
         stack_params.cbam.templateName = resource_model.resources.SCM_Server_Pair.resources[0].resources.server.attributes.metadata.templateName;
     }
   stack_params.cbam = processaffinityRules(stack_params.cbam);
   return stack_params;
}	
function prepare(operation_params,resource_model,stack_params,zones){
  stack_params = prepare_stack_params(operation_params,resource_model,stack_params);
  stack_params.cbam.resources = processResources(stack_params.cbam, zones, stack_params.cbam.templateName);
  return stack_params;
}

return prepare($.operation_params, $.resource_model, $.stack_params, $.nfv_model.zones)
