# Global environment Variable
# This env vars prepare is reserved for future only ansible LCM
# 'platform' value: OpenStack or VMWare. This value is useless at present. 
# 'deploy_via_media_oam' value: yes or no. Now the value is hardcode as yes.
# In future, the value of deploy_via_media_oam may get from cloud-resource-data.yaml.

#export platform="OpenStack"
#if [[ $platform = "iSBC-OpenStack" ]]; then
#  export GUEST_DATA="${HOME}/SBC"
#  export APP_DATA="$GUEST_DATA/app_data"
#  export CONFIG_DRIVE="$GUEST_DATA/config_drive"
#  export MEDIA_WORKFLOWS="$APP_DATA/media-workflows"
#  export MEDIA_PLAYBOOKS="$APP_DATA/media-playbooks"
#  export MEDIA_CONFIG_DRIVE="$MEDIA_PLAYBOOKS/roles/config_drive"
#  export ANSIBLE_LOG="$GUEST_DATA/log"
#  export MEDIA_LOG="$ANSIBLE_LOG/media"
#

export deploy_via_media_oam="yes"
# GUEST_DATA is the current path of scripts in SERVICE-CSAR
# Consider current file is under the same dir with playbooks.
export GUEST_DATA=$(dirname "$PWD")
export CONFIG_DRIVE="$GUEST_DATA/../bulk-config"
export MEDIA_PLAYBOOKS="$GUEST_DATA/cloud-playbook"
export MEDIA_CONFIG_DRIVE="$GUEST_DATA/../bulk-config"
export ANSIBLE_LOG="$GUEST_DATA/log"
export MEDIA_LOG="$ANSIBLE_LOG"

