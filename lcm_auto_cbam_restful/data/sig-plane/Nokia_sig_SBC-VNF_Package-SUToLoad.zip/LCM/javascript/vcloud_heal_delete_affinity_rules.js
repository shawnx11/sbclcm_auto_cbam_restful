function isNumeric(n) {
  return !isNaN(parseFloat(n)) && isFinite(n)
}

function processaffinityRules(cbam, resourceModel, vnfcToHeal) {
    affinityRulesArr = [];
    var affinityRulesObj = "";
    var scHealPair1 = "";
    var scHealPair2 = "";
    affinityRulesObj = {
        "affinityRules": []
    }
    vduServer = [];
    j = 0;
    rulesCount = 0;
    var vnfcToHealListArr = vnfcToHeal.split(",");
    for (var id in cbam.extensions["affinityRules"]) {
        if (isNumeric(id)) {
            for (var step in cbam.extensions["affinityRules"][id]) {
                var isAnti = cbam.extensions["affinityRules"][id][step].rules_info[0].rules[0].isAnti
                var ruleName = cbam.extensions["affinityRules"][id][step].rules_info[0].rules[0].ruleName
                if ( isAnti !== "null" && ruleName !== "null") {
                    for (var aspectGroupId in resourceModel.resources){
                        var deleteVduRule = "";
                        var aspectGroup = resourceModel.resources[aspectGroupId]
                        if (aspectGroupId === "static") {
                            for (var rscId in aspectGroup.resources) {
                                if (isNaN(rscId)) {
                                    for (var rcId in aspectGroup.resources[rscId].resources) {
                                        var vduId = aspectGroup.resources[rscId].resources[rcId].resources.server.vdu
                                        if (vduId === cbam.extensions["affinityRules"][id][step].name){
                                            for (var vnfcIdx = 0; (vnfcIdx < vnfcToHealListArr.length); vnfcIdx++) {
                                                if (aspectGroup.resources[rscId].resources[rcId].resources.server.attributes.metadata.image === vnfcToHealListArr[vnfcIdx]) {
                                                    deleteVduRule = vduId;
                                                }
                                            }
                                        }
                                    }
                                    for (var rcId2 in aspectGroup.resources[rscId].resources) {
                                        var vduId = aspectGroup.resources[rscId].resources[rcId2].resources.server.vdu
                                        if (vduId === cbam.extensions["affinityRules"][id][step].name){
                                            if ( deleteVduRule != vduId ) {
                                                vduServer[j] = aspectGroup.resources[rscId].resources[rcId2].resources.server.nfvId;
                                                if (j == 1) {
                                                    if (vduServer[0] != "null" & vduServer[1] != "null") {
                                                        var tmpAffinityRulesObj = {"isAnti":isAnti, "cbamIds":[vduServer[0],vduServer[1]],"ruleName":ruleName};
                                                        affinityRulesArr[rulesCount] = tmpAffinityRulesObj;
                                                        rulesCount++;
                                                    }
                                                } else {
                                                    j++;
                                                }
                                            } else {
                                                vduServer[j] = "null";
                                                j++;
                                            }
                                        }
                                    }
                                    deleteVduRule = "";
                                    j = 0;
                                }
                            }
                        }
                        else 
                        {
                            for (var rscId in aspectGroup.resources) {
                                if (isNumeric(rscId)) {
                                    for (var rcId in aspectGroup.resources[rscId].resources) {
                                        var vduId = aspectGroup.resources[rscId].resources[rcId].resources.server.vdu
                                        if (vduId === cbam.extensions["affinityRules"][id][step].name){
                                            for (var vnfcIdx = 0; (vnfcIdx < vnfcToHealListArr.length); vnfcIdx++) {
                                                if (aspectGroup.resources[rscId].resources[rcId].resources.server.attributes.metadata.image === vnfcToHealListArr[vnfcIdx]) {
                                                    deleteVduRule = vduId;
                                                    if (vduId === "sc") {
                                                        scHealPair1 = aspectGroup.resources[rscId].resources[0].resources.server.attributes.metadata.image;
                                                        scHealPair2 = aspectGroup.resources[rscId].resources[1].resources.server.attributes.metadata.image;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    for (var rcId2 in aspectGroup.resources[rscId].resources) {
                                        var vduId = aspectGroup.resources[rscId].resources[rcId2].resources.server.vdu
                                        if (vduId === cbam.extensions["affinityRules"][id][step].name){
                                            if (vduId != "sc") {
                                                if ( deleteVduRule != vduId ) {
                                                    vduServer[j] = aspectGroup.resources[rscId].resources[rcId2].resources.server.nfvId;
                                                    if (j == 1) {
                                                        if (vduServer[0] != "null" & vduServer[1] != "null") {
                                                            var tmpAffinityRulesObj = {"isAnti":isAnti, "cbamIds":[vduServer[0],vduServer[1]],"ruleName":ruleName};
                                                            affinityRulesArr[rulesCount] = tmpAffinityRulesObj;
                                                            rulesCount++;
                                                        }
                                                    } else {
                                                        j++;
                                                    }
                                                } else {
                                                    vduServer[j] = "null";
                                                    j++;
                                                }
                                            } else {
                                                if ((scHealPair1 != aspectGroup.resources[rscId].resources[rcId2].resources.server.attributes.metadata.image) && (scHealPair2 != aspectGroup.resources[rscId].resources[rcId2].resources.server.attributes.metadata.image)){
                                                    vduServer[j] = aspectGroup.resources[rscId].resources[rcId2].resources.server.nfvId;
                                                    if (j == 1) {
                                                        if (vduId == "sc") {
                                                            ruleName = "sc" + rscId + "Rule"
                                                        }
                                                        if (vduServer[0] != "null" & vduServer[1] != "null") {
                                                            var tmpAffinityRulesObj = {"isAnti":isAnti, "cbamIds":[vduServer[0],vduServer[1]],"ruleName":ruleName};
                                                            affinityRulesArr[rulesCount] = tmpAffinityRulesObj;
                                                            rulesCount++;
                                                        }
                                                    } else {
                                                        j++;
                                                    }
                                                } else {
                                                    vduServer[j] = "null";
                                                    j++;
                                                }
                                            }
                                        }
                                    }
                                    deleteVduRule = "";
                                    j = 0;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    affinityRulesObj.affinityRules = affinityRulesArr.slice();
    return affinityRulesObj;
}

function prepare(stackParams, resourceModel, vnfcToHeal){
  affinityRulesObj = processaffinityRules(stackParams.cbam, resourceModel, vnfcToHeal);
  return affinityRulesObj;
}

return prepare($.stackParams, $.resource_model, $.vnfcToHeal);

