
// (c) 2019 Nokia

var zoneA = "";
var zoneB = "";
var zoneFwA = "";
var zoneFwB = "";
var vmware_sideA = ".0.server";
var openstack_sideA = ".NOKIA-LCP-VMA";

$.zones.forEach(function(zone){
        switch(zone.id) {
        case "0":
        case "zoneA":
            zoneA = zone.zoneId;
            break;
        case "1":
        case "zoneB":
            zoneB = zone.zoneId;
            break;
        case "zoneFwA":
            zoneFwA = zone.zoneId;
            break;
        case "zoneFwB":
            zoneFwB = zone.zoneId;
            break;
        default:
            break;
        }
    })

Object.keys($.newVnfcs).forEach(function(vnfc){
        if ((vnfc.endsWith(vmware_sideA)) || (vnfc.endsWith(openstack_sideA))) {
            $.newVnfcs[vnfc].zoneId = zoneA;
        } else {
            $.newVnfcs[vnfc].zoneId = zoneB;
        }
    })

return {
    "newVnfcs" : $.newVnfcs
} 
