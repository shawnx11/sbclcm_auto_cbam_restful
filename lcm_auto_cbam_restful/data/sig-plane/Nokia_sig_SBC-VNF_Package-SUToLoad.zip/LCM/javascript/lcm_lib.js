function get_oam_ips_list_str(resource_model) {
    var st_outputs_list = resource_model.outputs;
    var st_outputs_list_length = st_outputs_list.length;
    oam_ips_list_str = "";		
    
    for ( var idx = 0; (idx < st_outputs_list_length); idx++ ) {
        if (   (st_outputs_list[idx].output_key !== "OAMA-EXTIPS")
            && (st_outputs_list[idx].output_key !== "OAMB-EXTIPS")) {
            continue;
        }

        if (!st_outputs_list[idx].output_value) {
            throw "Invalid value [" + st_outputs_list[idx].output_value + "] for [" + st_outputs_list[idx].output_key + "]."; 
        }

        var o_val = st_outputs_list[idx].output_value.trim();
        var ips_arr = o_val.split(',');
        for ( var ip_idx = 0; (ip_idx < ips_arr.length); ip_idx++ ) {        
            if ( (ips_arr[ip_idx] !== " ") && (ips_arr[ip_idx] !== "")) {
                ips_arr[ip_idx] = ips_arr[ip_idx].trim();
                if ( oam_ips_list_str !== "" ) {
                    oam_ips_list_str += ",";
                }
                oam_ips_list_str += ips_arr[ip_idx];
            }        
        }
    }

    return oam_ips_list_str;
}

