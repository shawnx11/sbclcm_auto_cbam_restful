function isNumeric(n) {
  return !isNaN(parseFloat(n)) && isFinite(n)
}

function processaffinityRules(cbam, resourceModel) {
    affinityRulesArr = [];
    var affinityRulesObj = "";
    affinityRulesObj = {
        "affinityRules": []
    }
    vduServer = [];
    j = 0;
    rulesCount = 0;
    for (var id in cbam.extensions["affinityRules"]) {
        if (isNumeric(id)) {
            for (var step in cbam.extensions["affinityRules"][id]) {
                var isAnti = cbam.extensions["affinityRules"][id][step].rules_info[0].rules[0].isAnti
                var ruleName = cbam.extensions["affinityRules"][id][step].rules_info[0].rules[0].ruleName
                if ( isAnti !== "null" && ruleName !== "null") {
                    for (var aspectGroupId in resourceModel.resources){
                        var aspectGroup = resourceModel.resources[aspectGroupId]
                        if (aspectGroupId === "static") {
                            for (var rscId in aspectGroup.resources) {
                                if (isNaN(rscId)) {
                                    for (var rcId in aspectGroup.resources[rscId].resources) {
                                        var vduId = aspectGroup.resources[rscId].resources[rcId].resources.server.vdu
                                        if (vduId === cbam.extensions["affinityRules"][id][step].name){
                                            vduServer[j] = aspectGroup.resources[rscId].resources[rcId].resources.server.nfvId;
                                            if (j == 1) {
                                                var tmpAffinityRulesObj = {"isAnti":isAnti, "cbamIds":[vduServer[0],vduServer[1]],"ruleName":ruleName};
                                                affinityRulesArr[rulesCount] = tmpAffinityRulesObj;
                                                rulesCount++;
                                                j = 0;
                                            } else {
                                                j++;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else {
                            for (var rscId in aspectGroup.resources) {
                                if (isNumeric(rscId)) {
                                    for (var rcId in aspectGroup.resources[rscId].resources) {
                                        var vduId = aspectGroup.resources[rscId].resources[rcId].resources.server.vdu
                                        if (vduId === cbam.extensions["affinityRules"][id][step].name){
                                            vduServer[j] = aspectGroup.resources[rscId].resources[rcId].resources.server.nfvId;
                                            if (j == 1) {
                                                if (vduId == "sc") {
                                                    ruleName = "sc" + rscId + "Rule"
                                                }
                                                var tmpAffinityRulesObj = {"isAnti":isAnti, "cbamIds":[vduServer[0],vduServer[1]],"ruleName":ruleName};
                                                affinityRulesArr[rulesCount] = tmpAffinityRulesObj;
                                                rulesCount++;
                                                j = 0;
                                            } else {
                                                j++;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } 
                }
            }
        }
    }
    affinityRulesObj.affinityRules = affinityRulesArr.slice();
    return affinityRulesObj;
}

function prepare(stackParams, resourceModel){
  affinityRulesObj = processaffinityRules(stackParams.cbam, resourceModel);
  return affinityRulesObj;
}

return prepare($.stackParams, $.resource_model);

