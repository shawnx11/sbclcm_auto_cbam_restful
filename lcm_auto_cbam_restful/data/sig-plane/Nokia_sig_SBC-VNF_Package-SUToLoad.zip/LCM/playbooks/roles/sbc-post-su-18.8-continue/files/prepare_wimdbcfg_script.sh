#!/bin/bash
var1=$1
sed "s/qid/$var1/g" /tmp/dbcli_script/wimdbcfg_script.sh > /tmp/dbcli_script/expect_wimdbcfg_script.sh
