#!/bin/bash
var1=$1
sed "s/hostname/$var1/g" /tmp/dbcli_script/dbcli_i_script.sh > /tmp/dbcli_script/expect_dbcli_i_script.sh
