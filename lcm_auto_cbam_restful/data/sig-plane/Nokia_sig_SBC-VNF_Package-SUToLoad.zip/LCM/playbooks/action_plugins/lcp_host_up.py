#!/usr/bin/python

DOCUMENTATION = '''
---
action_plugin: lcp_host_up
short_description: module used to determine when an lcp host is fully up
'''

import os
import time
#import json
#import re
import socket

from ansible import constants as C
from ansible.plugins.action import ActionBase
from ansible.errors import AnsibleError
from subprocess import Popen, PIPE, STDOUT
from ansible.utils.display import Display
from subprocess import Popen, PIPE, STDOUT

display = Display()

class ActionModule(ActionBase):

    def run(self, tmp=None, task_vars=None):
        if task_vars is None:
            task_vars = dict()

        result = super(ActionModule, self).run(tmp, task_vars)


        if 'host' not in self._task.args:
            raise AnsibleError("'host' is a required argument.")
        host = self._task.args.get('host', None)

        if 'retries' not in self._task.args:
            retries = 180    # default retry attempts 180
        else:
            retries = self._task.args.get('retries')

        if 'delay' not in self._task.args:
            delay = 20    # Default delay of 20 seconds
        else:
            delay = self._task.args.get('delay')

        if 'pem' not in self._task.args:
            raise AnsibleError("'pem' is a required argument.")
        else:
            pem = self._task.args.get('pem')

        display.vv("lcp_host_up ActionModule: host=%s" % (host))

        # Default the return result
        result.update(dict(
            changed = False,
            rc      = 0,
            stderr  = '',
            stdout  = '',
        ))

        ip_list =  dict()
        host_list = host.split(",")
  
        # Confirm pem file exists
        if not os.path.exists(pem):
            result['failed'] = True
            result['msg'] = "pem file " + pem + " not found"
            return result

        # go through candidate IP address, filter out invalid ipv4 and ipv6 ip addresses
        for ip in host_list:
            if (is_valid_ipv4_address(ip)) or (is_valid_ipv6_address(ip)):
                ip_list[ip] = 0

        # Check that at least 1 valid host IP was found
        if not ip_list:
            result['failed'] = True
            result['msg'] = "No valid candidate host IP found"
            return result

        # Run through valid host IPs to find a host which is up
        host_up = lcp_host_up(ip_list, retries, delay, pem)

        if host_up is "0":
            result['failed'] = True
            result['msg'] = "host did not come up"
        else:
            result['changed'] = False
            result['host_ip'] = host_up

        return result


NUM_SUCCESSFULL_PINGS = 5

def lcp_host_up(host, retries, delay, pem):
    delay   = int(delay)
    retries = int(retries)
 
    while retries > 0 :
        for entry in host:
            # Try to ping the host
            ping_str=["/bin/ping", "-c", "1", "-W", "2", entry]
            rc = Popen(ping_str, stdin=PIPE, stdout=PIPE, stderr=STDOUT)
            output, error = rc.communicate()

            if  rc.returncode == 0:
                # ping succeeded, start incrementing successful  counter
                host[entry] += 1

                # If there's been a successive number of successfull pings
                # then try to find the lcm_util tool
                if host[entry] >= NUM_SUCCESSFULL_PINGS:
                    if find_lcm_util('lcmadm', entry, pem) == True:
                        # tool found, this is the candidate IP, return it
                        return entry
                    else:
                        # lcm_util not found, remove this candidate from the list
                        del host[entry]
            else:
                # ping failed, set host[entry] back to 0
                host[entry] = 0

        # If host dict is empty, get out
        if not host:
            return "0"

        retries -= 1
        time.sleep(delay)

    return 0


# used to confirm ip address is valid
def is_valid_ipv4_address(address):
    try:
        socket.inet_pton(socket.AF_INET, address)
    except AttributeError:  # no inet_pton here, sorry
        try:
            socket.inet_aton(address)
        except socket.error:
            return False
        return address.count('.') == 3
    except socket.error:  # not a valid address
        return False

    return True

def is_valid_ipv6_address(address):
    try:
        socket.inet_pton(socket.AF_INET6, address)
    except socket.error:  # not a valid address
        return False
    return True

def find_lcm_util(user_id, ip_addr, pem_file):

    ssh_string = [ 'ssh', '-o', 'BatchMode=yes',
                          '-o', 'ConnectTimeout=30',
                          '-o', 'StrictHostKeyChecking=no',
                          '-i',  pem_file,
                          '-l',  user_id, ip_addr,
                          '/usr/bin/test -f /opt/LSS/share/basecfg/fi/bin/lcm_util'
                 ]

    rc = Popen(ssh_string, stdout=PIPE, stderr=PIPE)
    std_out, std_err = rc.communicate()

    if rc.returncode == 0:
        return True
    else:
        return False

