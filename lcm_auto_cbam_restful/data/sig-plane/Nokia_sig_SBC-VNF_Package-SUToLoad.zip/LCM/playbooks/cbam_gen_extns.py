#!/usr/bin/python

# --------------------------------------------------------------------------- #
"""Generates CBAM extensions file."""

# --------------------------------------------------------------------------- #
# Core modules.
import argparse
import json
import os
import re
import sys
from subprocess import Popen, PIPE, STDOUT

# --------------------------------------------------------------------------- #
# Argument values.
arg_values = None

# --------------------------------------------------------------------------- #
# Extra vars dictionary.
extra_vars_dict = {}
providerType = "OPENSTACK"
apiVersion = 3.3

# --------------------------------------------------------------------------- #
def load_from_json_file(json_file, data_dict):
    """Loads data from the JSON file into the given dictionary.
       Returns data dictionary on success or None on error.
       """
    try:
        with open(json_file, 'r') as jFile:
            data_dict = json.load(jFile)
            return data_dict
    except Exception as exc:
        print('ERROR: Failed to load data from {0}.\n[{1}]'.format(
            json_file, str(exc)))
    
    return None

# --------------------------------------------------------------------------- #
def copy_files_to_mi():
    """Copies generated files to MI to be bundled with the backup zip file."""

    cmd = 'scp -i {pem_file} LCM_extensions.json LCM_instantiate_params.json cbam_info.json ' \
        '{mi_user}@[{mi_ip}]:{mi_dir}'.format(
            pem_file=arg_values.pem_file,
            mi_user=arg_values.mi_user,
            mi_ip=arg_values.mi_floating_ip,
            mi_dir=arg_values.mi_bkup_dir)

    proc = Popen(cmd, shell=True, stdout=PIPE, stderr=PIPE)
    (std_out, std_err) = proc.communicate()

    rc = proc.wait()
    if (rc != 0):
        print('ERROR: [{scp_cmd}] failed.\n[{s_out}]\n[{s_err}]'.format(
            scp_cmd=cmd,
            s_out=std_out,
            s_err=std_err))
        sys.exit(1)

# --------------------------------------------------------------------------- #
def gen_cbam_info_file():
    """Generates CBAM info file."""

    imageId = ""
    global providerType
    cbam_info_dict = {}
    if (providerType == "VMWARE"):
        aspects_dict = extra_vars_dict["vnf_context_data"]["nfv_model"]["aspects"]

        for aspect, aspect_val in aspects_dict.items():
            if ("count" in aspect_val.keys()):
                cbam_info_dict[aspect] = aspect_val['count']

        # Get ImageId
        if ("stack_params" in extra_vars_dict['vnf_context_data'].keys()):
            stack_params_dict = extra_vars_dict['vnf_context_data']['stack_params']
            if (("cbam" in stack_params_dict.keys()) and ("resources" in stack_params_dict["cbam"].keys())):
                rsrcs_dict = stack_params_dict['cbam']['resources']
                if ("static" in rsrcs_dict.keys()):
                   for rsc_key, rsc_val in rsrcs_dict["static"].items():
                       if (("0" in rsc_val.keys()) and ("server" in rsc_val["0"].keys())):
                           if ("imageId" in rsc_val["0"]["server"].keys()):
                               imageId = rsc_val["0"]["server"]["imageId"]
    else:
        stack_params_dict = extra_vars_dict['vnf_context_data']['stack_params']
        rsrcs_dict = stack_params_dict['cbam']['resources']

        # Save the current resource counts.
        for rsrc_grp, rsrc_val in rsrcs_dict.items():
            rsrc_key = rsrc_grp.lower()
            rsrc_key = re.sub('_rrg', '_Aspect', rsrc_key)
            rsrc_key += '_count'
            if ('count' in rsrc_val):        
                cbam_info_dict[rsrc_key] = rsrc_val['count']
            else:
                # Assume static vdu i.e. OAM
                if ("NOKIA-LCP-VMA" in rsrc_val.keys() and "imageId" in rsrc_val["NOKIA-LCP-VMA"].keys()):
                    imageId = rsrc_val["NOKIA-LCP-VMA"]["imageId"]

        # Save the current image.
        cbam_extns_dict = stack_params_dict['cbam']['extensions']
        if (cbam_extns_dict.has_key('defaults')):
            imageId = cbam_extns_dict['defaults']['image']['0']
    cbam_info_dict['image'] = imageId

    cbam_info_file = 'cbam_info.json'
    try:
        with open(cbam_info_file, 'w') as jFile:
            json.dump(cbam_info_dict, jFile, indent=4)
    except Exception as exc:
        print('ERROR: Failed to write data to {0}.\n[{1}]'.format(
            cbam_info_file, str(exc)))
        sys.exit(1)

# --------------------------------------------------------------------------- #
def gen_extns_file():
    """Generates the extensions file."""

    global providerType
    if (providerType == "VMWARE"):
        vnf_attributes = extra_vars_dict['vnf_context_data']['vnf_attributes']
        cbam_extns_dict = vnf_attributes['extensions']
    else:
        stack_params_dict = extra_vars_dict['vnf_context_data']['stack_params']    
        cbam_extns_dict = stack_params_dict['cbam']['extensions']
    extns_dict = {}
    if apiVersion >= 4.0:
        extns_dict['extensions'] = {}
    else:
        extns_dict['extensions'] = []

    for ex_key, ex_val in cbam_extns_dict.items():
        if (ex_key == 'defaults'):
            if ('action' not in ex_val):
                ex_val['action'] = {
                    '0': 'recreate',
                    '1': 'recreate'
                }
            else:
                ex_val['action']['0'] = 'recreate'
                ex_val['action']['1'] = 'recreate'

        if apiVersion >= 4.0:
            extns_dict['extensions'][ex_key] = ex_val
        else:
            inner_dict = {}
            inner_dict['name'] = ex_key
            inner_dict['value'] = ex_val
            extns_dict['extensions'].append(inner_dict)

    extns_file = 'LCM_extensions.json'
    try:
        with open(extns_file, 'w') as jFile:
            json.dump(extns_dict, jFile, indent=4)
    except Exception as exc:
        print('ERROR: Failed to write data to {0}.\n[{1}]'.format(
            extns_file, str(exc)))
        sys.exit(1)

# --------------------------------------------------------------------------- #
def gen_instantiate_params_file():
    """Generates the 'LCM_instantiate_params.json' file."""

    global providerType
    global apiVersion
    valid_param_list = [
          "additionalParams",
          "computeResourceFlavours",
          "extManagedVirtualLinks",
          "extVirtualLinks",
          "grantlessMode",
          "instantiationLevelId",
          "softwareImages",
          "vims",
          "flavourId",
          "zones"
       ]
    nfv_model_dict = extra_vars_dict['vnf_context_data']['nfv_model'] 
    instantiate_dict = {}
    instantiate_dict["softwareImages"] = []
    instantiate_dict["extVirtualLinks"] = []
    instantiate_dict["computeResourceFlavours"] = []
    instantiate_dict["zones"] = []
    if (providerType == "VMWARE"):
        instantiate_dict["extManagedVirtualLinks"] = []
        instantiate_dict["extVirtualLinks"] = []
        instantiate_dict["default_instantiation_level_id"] = "default"
    else:
        instantiate_dict["instantiationLevelId"] = "default"

    # Get correct apiVersion
    apiVersion = 3.3
    if "extVirtualLinksSol3" in nfv_model_dict.keys():
        apiVersion = 4.0
    elif "vim" in nfv_model_dict.keys():
        if (   (("projectDomain" not in nfv_model_dict["vim"].keys()) or (nfv_model_dict["vim"]["projectDomain"] == None))
            or (("userDomain" not in nfv_model_dict["vim"].keys()) or (nfv_model_dict["vim"]["userDomain"] == None))):
            apiVersion = 0
    if apiVersion != 0:
        instantiate_dict["apiVersion"] = apiVersion
    vim_id = ""
    if (("vim" in nfv_model_dict.keys()) and ("vimInstanceId" in nfv_model_dict["vim"].keys())):
        vim_id = nfv_model_dict["vim"]["vimInstanceId"]

    nfv_model_keys = nfv_model_dict.keys()
    for model_key, model_val in nfv_model_dict.items():
        # Convert params to expected format:
        #    - 'externalConnectionPoints' to 'extVirtualLinks'
        #    - 'swImages' to 'softwareImages'
        #    - 'vim' to 'vims'
        if (model_key == "externalConnectionPoints"):
            if "extVirtualLinksSol3" in nfv_model_dict.keys():
                instantiate_dict["extVirtualLinks"] = nfv_model_dict["extVirtualLinksSol3"]
            elif providerType == "VMWARE":
                instantiate_dict.update({model_key: model_val})
            else:
                ext_virtual_list = []
                for ext_conn_key, ext_conn_val in model_val.items():
                    resourceId = (ext_conn_val["vlResource"] if ("vlResource" in ext_conn_val.keys()) else "")
                    addresses = (ext_conn_val["addresses"] if ("addresses" in ext_conn_val.keys()) else [])
                    ext_virtual_list.append({
                           "addresses": addresses,
                           "cpdId": ext_conn_key
                       })
                    instantiate_dict["extVirtualLinks"].append({"extCps": ext_virtual_list, "resourceId": resourceId})
        elif (model_key == "swImages"):
            sw_images_list = []
            for image_key, image_val in model_val.items():
                imageId = (image_val["vimSoftwareImageId"] if ("vimSoftwareImageId" in image_val.keys()) else "")
                image_dict = {"vnfdSoftwareImageId": image_key}
                if (apiVersion >= 4.0):
                    image_dict["vimConnectionId"] = vim_id
                    image_dict["vimSoftwareImageId"] = imageId
                else:
                    image_dict["resourceId"] = imageId
                sw_images_list.append(image_dict)
            instantiate_dict["softwareImages"] = sw_images_list
        elif (model_key == "vim"):
            vim_dict = {}
            password = ""
            tenant = (model_val["tenantName"] if ("tenantName" in model_val.keys()) else "")
            username = (model_val["username"] if ("username" in model_val.keys()) else "")
            id = (model_val["vimInstanceId"] if ("vimInstanceId" in model_val.keys()) else "")
            if (providerType == "VMWARE"):
                vim_key = "vims"
                if (apiVersion >= 4.0):
                    vim_key = "vimConnectionInfo"
                instantiate_dict[vim_key] = []
                interfaceEndpoint = (model_val["vcloudUrl"] if ("vcloudUrl" in model_val.keys()) else "")
                organization = (model_val["organization"] if ("organization" in model_val.keys()) else "")
                cert_verify = (model_val["skipCertificateVerification"] if ("skipCertificateVerification" in model_val.keys()) else false)
                endpoint_key = ("endpoint" if (apiVersion >= 4.0) else "interfaceEndpoint")
                vim_dict = {
                       "accessInfo": {
                           "password" : password, "username": username,
                           "organization": organization, "skipCertificateVerification": cert_verify
                       },
                       "id": id
                   }
                if (apiVersion >= 4.0):
                    vim_dict.update({"vimType": "VMWARE_VCLOUD"})
                    vim_dict["interfaceInfo"] = {endpoint_key: interfaceEndpoint}
                else:
                    vim_dict.update({"vimInfoType": "VmWareVimInfo"})
                    vim_dict["interfaceEndpoint"] = interfaceEndpoint
                    vim_dict["interfaceInfo"] = {}
                instantiate_dict[vim_key].append(vim_dict)
            else:
                interfaceEndpoint = (model_val["keystoneUrl"] if ("keystoneUrl" in model_val.keys()) else "")
                userDomain = (model_val["userDomain"] if ("userDomain" in model_val.keys()) else "")
                projectDomain = (model_val["projectDomain"] if ("projectDomain" in model_val.keys()) else "")
                region = (model_val["region"] if ("region" in model_val.keys()) else "")
                project = (model_val["project"] if ("project" in model_val.keys()) else None)

                if apiVersion == 0:
                    instantiate_dict["vims"] = []
                    vim_dict["accessInfo"] = {"username": username, "password": password, "tenant": tenant}
                    vim_dict["interfaceInfo"] = {"region": region}
                    vim_dict["interfaceEndpoint"] = interfaceEndpoint
                    vim_dict["id"] = id
                    instantiate_dict["vims"].append(vim_dict)
                else:
                    vim_dict["id"] = id
                    vim_dict["interfaceInfo"] = {"endpoint": interfaceEndpoint}
                    vim_dict["accessInfo"] = {"username": username, "password": password,
                            "userDomain": userDomain, "projectDomain":projectDomain, "region": region}
                    if project == None:
                        if "tenantName" in model_val.keys():
                            project = model_val["tenantName"]
                        else:
                            resource_model = extra_vars_dict['vnf_context_data']['resource_model']
                            if (    ("parameters" in resource_model.keys())
                                and ("OS::project_id" in resource_model["parameters"].keys())):
                                #Use project ID
                                project = resource_model["parameters"]["OS::project_id"]
                    if project != None:
                        vim_dict["accessInfo"]["project"] = project
                    if apiVersion >= 4.0:
                        vim_dict["vimType"] = "OPENSTACK_V3"
                        instantiate_dict["vimConnectionInfo"] = []
                        instantiate_dict["vimConnectionInfo"].append(vim_dict)
                    elif apiVersion == 3.3:
                        vim_dict["vimInfoType"] = "OPENSTACK_V3_INFO"
                        instantiate_dict["vims"] = []
                        instantiate_dict["vims"].append(vim_dict)
        elif (model_key == "computeResourceFlavours"):
            for flavor_key, flavor_val in model_val.items():
                resourceId = (flavor_val["vimFlavourId"] if ("vimFlavourId" in flavor_val.keys()) else "")
                flavor_dict = {"vnfdVirtualComputeDescId": flavor_key}
                if (apiVersion >= 4.0):
                    flavor_dict["vimConnectionId"] = vim_id
                    flavor_dict["vimFlavourId"] = resourceId
                else:
                    flavor_dict["resourceId"] = resourceId
                instantiate_dict["computeResourceFlavours"].append(flavor_dict)
        elif (model_key == "flavourId"):
            if ((apiVersion >= 4.0) or (providerType == "VMWARE")):
                instantiate_dict.update({model_key: model_val})
        elif ((model_key == "zoneInfo") and ("zones" not in nfv_model_keys)):
            instantiate_dict["zones"] = model_val
        elif (model_key == "zones"):
            if ((len(model_val) == 0) and ("zoneInfo" in nfv_model_dict.keys())):
                instantiate_dict["zones"] = nfv_model_dict["zoneInfo"]
            else:
                for zone_key, zone_val in model_val.items():
                    resourceId = (zone_val["zoneId"] if ("zoneId" in zone_val.keys()) else "")
                    zone_dict = {"id": zone_key, "resourceId": resourceId}
                    if (apiVersion >= 4.0):
                        zone_dict["vimConnectionId"] = vim_id
                    instantiate_dict["zones"].append(zone_dict)
        elif ((model_key == "virtualLinks") and (providerType == "VMWARE")):
            virtual_links = []
            for virtual_key, virtual_val in model_val.items():
                networkId = ""
                if (("vlResource" in virtual_val.keys()) and ("networkId" in virtual_val["vlResource"].keys())):
                    networkId = virtual_val["vlResource"]["networkId"]
                link_dict = {"virtualLinkDescId": virtual_key, "resourceId": networkId}
                if (apiVersion >= 4.0):
                    link_dict["vimConnectionId"] = vim_id
                    if ("managedVlId" in virtual_val.keys()):
                        link_dict["id"] = virtual_val["managedVlId"]
                instantiate_dict["extManagedVirtualLinks"].append(link_dict)
                instantiate_dict["extVirtualLinks"].append({"extCps": [{"cpdId": virtual_key}], "resourceId": networkId})
        elif (model_key in valid_param_list):
            instantiate_dict.update({model_key: model_val})

    instantiate_file = 'LCM_instantiate_params.json'
    try:
        with open(instantiate_file, 'w') as jFile:
            json.dump(instantiate_dict, jFile, indent=4)
    except Exception as exc:
        print('ERROR: Failed to write data to {0}.\n[{1}]'.format(
            instantiate_file, str(exc)))
        sys.exit(1)

# --------------------------------------------------------------------------- #
def load_extra_vars():
    """Load data from the extra vars JSON file."""

    global extra_vars_dict
    extra_vars_dict = load_from_json_file(
        arg_values.extra_vars_json,
        extra_vars_dict)
    
    if (extra_vars_dict == None):
        sys.exit(1)
    if ("providerType" in extra_vars_dict.keys()):
        global providerType
        providerType = extra_vars_dict["providerType"]

# --------------------------------------------------------------------------- #
def parse_args():
    """Parse script arguments."""

    script_desc = 'CBAM extensions file generator.'

    args_parser = argparse.ArgumentParser(description=script_desc)
    args_parser.add_argument('extra_vars_json',
        help='Ansible extra vars JSON file')    
    args_parser.add_argument('mi_user',
        help='MI User')    
    args_parser.add_argument('mi_floating_ip',
        help='MI Floating IP')    
    args_parser.add_argument('pem_file',
        help='MI Access PEM file')    
    args_parser.add_argument('mi_bkup_dir',
        help='MI backup directory')

    # Parse the arguments.
    global arg_values
    arg_values = args_parser.parse_args()

# --------------------------------------------------------------------------- #
def main():
    """Script entry point."""

    # Parse arguments.
    parse_args()

    # Load extra vars to dictionary.
    load_extra_vars()

    # Generate the 'LCM_instantiate_params.json' file.
    gen_instantiate_params_file()

    # Generate the extensions file.
    gen_extns_file()

    # Generate CBAM info file.
    gen_cbam_info_file()

    # Copy files to MI to be backed up.
    copy_files_to_mi()

# --------------------------------------------------------------------------- #
# Execute when run as a script.
if (__name__ == "__main__"):
    main()
