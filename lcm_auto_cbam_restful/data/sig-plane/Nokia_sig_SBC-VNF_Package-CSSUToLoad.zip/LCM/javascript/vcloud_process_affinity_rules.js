function isNumeric(n) {
  return !isNaN(parseFloat(n)) && isFinite(n)
}

function processaffinityRules(cbam, affinityRulesInfo) {
    affinityRulesArr = [];
    vduServer = [];
    vduServer0 = [];
    vduServer1 = [];
    vduServer2 = [];
    vduServer3 = [];
    vduServer4 = [];
    vduServer5 = [];
    vduServer6 = [];
    vduServer7 = [];
    vduServer8 = [];
    vduServer9 = [];
    vduServer10 = [];
    a = 0;
    b = 0;
    c = 0;
    d = 0;
    e = 0;
    f = 0;
    g = 0;
    h = 0;
    i = 0;
    j = 0;
    k = 0;
    l = 0;
    rulesCount = 0;
    if ((typeof($.operation_params) !== "undefined") && (typeof($.operation_params.additionalParams) !== "undefined")) {
        if (("disasterRecovery" in $.operation_params.additionalParams) || (("type" in $.operation_params) && ($.operation_params.type == "out"))) {
            for (var id in cbam.extensions["affinityRules"]) {
                if (isNumeric(id)) {
                    for (var step in cbam.extensions["affinityRules"][id]) {
                        var isAnti = cbam.extensions["affinityRules"][id][step].rules_info[0].rules[0].isAnti
                        var ruleName = cbam.extensions["affinityRules"][id][step].rules_info[0].rules[0].ruleName
                        if ( isAnti !== "null" && ruleName !== "null") {
                            for (var server in $.model_diff.add) {
                                var vduId = $.model_diff.add[server].vdu;
                                if (vduId === cbam.extensions["affinityRules"][id][step].name){
                                    if (vduId !== "sc") {
                                        vduServer[i] = $.model_diff.add[server].nfvId;
                                        if (i == 1) {
                                            var tmpAffinityRulesObj = {"isAnti":isAnti, "cbamIds":[vduServer[0],vduServer[1]],"ruleName":ruleName};
                                            affinityRulesArr[rulesCount] = tmpAffinityRulesObj;
                                            rulesCount++;
                                            i = 0;
                                        } else {
                                            i++;
                                        }
                                    } else {
                                      switch($.model_diff.add[server].scalingStepId) {
                                        case "0":
                                            vduServer0[a] = $.model_diff.add[server].nfvId;
                                            if (a == 1) {
                                                var tmpAffinityRulesObj = {"isAnti":isAnti, "cbamIds":[vduServer0[0],vduServer0[1]],"ruleName":"sc0Rule"};
                                                affinityRulesArr[rulesCount] = tmpAffinityRulesObj;
                                                rulesCount++;
                                                a = 0;
                                            } else {
                                                a++;
                                            }
                                            break;
                                        case "1":
                                            vduServer1[b] = $.model_diff.add[server].nfvId;
                                            if (b == 1) {
                                                var tmpAffinityRulesObj = {"isAnti":isAnti, "cbamIds":[vduServer1[0],vduServer1[1]],"ruleName":"sc1Rule"};
                                                affinityRulesArr[rulesCount] = tmpAffinityRulesObj;
                                                rulesCount++;
                                                b = 0;
                                            } else {
                                                b++;
                                            }
                                            break;
                                        case "2":
                                            vduServer2[c] = $.model_diff.add[server].nfvId;
                                            if (c == 1) {
                                                var tmpAffinityRulesObj = {"isAnti":isAnti, "cbamIds":[vduServer2[0],vduServer2[1]],"ruleName":"sc2Rule"};
                                                affinityRulesArr[rulesCount] = tmpAffinityRulesObj;
                                                rulesCount++;
                                                c = 0;
                                            } else {
                                                c++;
                                            }
                                            break;
                                        case "3":
                                            vduServer3[d] = $.model_diff.add[server].nfvId;
                                            if (d == 1) {
                                                var tmpAffinityRulesObj = {"isAnti":isAnti, "cbamIds":[vduServer3[0],vduServer3[1]],"ruleName":"sc3Rule"};
                                                affinityRulesArr[rulesCount] = tmpAffinityRulesObj;
                                                rulesCount++;
                                                d = 0;
                                            } else {
                                                d++;
                                            }
                                            break;
                                        case "4":
                                            vduServer4[e] = $.model_diff.add[server].nfvId;
                                            if (e == 1) {
                                                var tmpAffinityRulesObj = {"isAnti":isAnti, "cbamIds":[vduServer4[0],vduServer4[1]],"ruleName":"sc4Rule"};
                                                affinityRulesArr[rulesCount] = tmpAffinityRulesObj;
                                                rulesCount++;
                                                e = 0;
                                            } else {
                                                e++;
                                            }
                                            break;
                                        case "5":
                                            vduServer5[f] = $.model_diff.add[server].nfvId;
                                            if (f == 1) {
                                                var tmpAffinityRulesObj = {"isAnti":isAnti, "cbamIds":[vduServer5[0],vduServer5[1]],"ruleName":"sc5Rule"};
                                                affinityRulesArr[rulesCount] = tmpAffinityRulesObj;
                                                rulesCount++;
                                                f = 0;
                                            } else {
                                                f++;
                                            }
                                            break;
                                        case "6":
                                            vduServer6[g] = $.model_diff.add[server].nfvId;
                                            if (g == 1) {
                                                var tmpAffinityRulesObj = {"isAnti":isAnti, "cbamIds":[vduServer6[0],vduServer6[1]],"ruleName":"sc6Rule"};
                                                affinityRulesArr[rulesCount] = tmpAffinityRulesObj;
                                                rulesCount++;
                                                g = 0;
                                            } else {
                                                g++;
                                            }
                                            break;
                                        case "7":
                                            vduServer7[h] = $.model_diff.add[server].nfvId;
                                            if (h == 1) {
                                                var tmpAffinityRulesObj = {"isAnti":isAnti, "cbamIds":[vduServer7[0],vduServer7[1]],"ruleName":"sc7Rule"};
                                                affinityRulesArr[rulesCount] = tmpAffinityRulesObj;
                                                rulesCount++;
                                                h = 0;
                                            } else {
                                                h++;
                                            }
                                            break;
                                        case "8":
                                            vduServer8[j] = $.model_diff.add[server].nfvId;
                                            if (j == 1) {
                                                var tmpAffinityRulesObj = {"isAnti":isAnti, "cbamIds":[vduServer8[0],vduServer8[1]],"ruleName":"sc8Rule"};
                                                affinityRulesArr[rulesCount] = tmpAffinityRulesObj;
                                                rulesCount++;
                                                j = 0;
                                            } else {
                                                j++;
                                            }
                                            break;
                                        case "9":
                                            vduServer9[k] = $.model_diff.add[server].nfvId;
                                            if (k == 1) {
                                                var tmpAffinityRulesObj = {"isAnti":isAnti, "cbamIds":[vduServer9[0],vduServer9[1]],"ruleName":"sc9Rule"};
                                                affinityRulesArr[rulesCount] = tmpAffinityRulesObj;
                                                rulesCount++;
                                                k = 0;
                                            } else {
                                                k++;
                                            }
                                            break;
                                        } 
                                    } 
                                }
                            }
                        }
                    }
                }
            }
        }
        cbam.affinityRules = affinityRulesArr.slice();
    } else {
        cbam.affinityRules = affinityRulesInfo.affinityRules.slice();
    }
    return cbam.affinityRules
}

function prepare(stack_params, affinityRulesInfo){
  stack_params.cbam.affinityRules = processaffinityRules(stack_params.cbam, affinityRulesInfo);
  return stack_params;
}

return prepare($.stack_params, $.affinityRulesInfo);

