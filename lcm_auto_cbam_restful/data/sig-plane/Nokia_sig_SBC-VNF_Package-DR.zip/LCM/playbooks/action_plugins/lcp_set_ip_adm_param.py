#!/usr/bin/python

DOCUMENTATION = '''
---
action_plugin: lcp_set_ip_adm_param 
short_description: action plugin used to set ip_adm argument string 
'''

import json      # json interpreter module
import re        # Regular Expressions module
import socket    # Socket module
import os        # os access module

from ansible                import constants as C
from ansible.plugins.action import ActionBase
from ansible.errors         import AnsibleError
from subprocess             import Popen, PIPE, STDOUT
from ansible.utils.display  import Display

display = Display()

class ActionModule(ActionBase):

    def run(self, tmp=None, task_vars=None):
        if task_vars is None:
            task_vars = dict()

        count_optional = 0

        result = super(ActionModule, self).run(tmp, task_vars)

        # Default the return result
        result.update(dict(
            changed = False,
            rc      = 0,
            stderr  = '',
            stdout  = '',
        ))

        # Looking for following arguments in this action plugin
        # action     : This is action for ip_adm 
	#    if an IP action, use these vars
        # svc_type   : service type   
        # pool_id    : pool id 
        # subnet     : subnet this ip assigned to 
        # ip_address : address for the given service pool member(s) 
        # porttype   : port type - direct or normal
        # membernum  : member number for a given pool id 
        # ni_type    : ni type 
	#    if a subnet action, use these vars
        # subnet_name          : the subnet name
        # subnet_base          : the subnet base or prefix
        # netmask              : the netmask or prefix length
        # subnet_number        : the subnet number in the VNF
        # eipm_mode            : the interface redundancy mode
        # subnet_gateway_ip    : the subnet gateway IP address
        # interface_name       : the interface label
        # customer_vlan        : the customer VLAN
        # detect_multiplier    : the detection multiplier
        # desired_min_rx_int   : the desired minimum receive interval
        # reqd_min_tx_int      : the required minimum transmit interval
        # mtu                  : the IPv6 MTU size if non-default

        if 'action' not in self._task.args:
            raise AnsibleError("'action' is a required argument.")
        action = self._task.args.get('action', None)

        if action != "add_subnet" and action != "del_subnet":
            if 'svc_type' not in self._task.args:
                raise AnsibleError("'svc_type' is a required argument.")
            svc_type = self._task.args.get('svc_type', None)

            if 'pool_id' not in self._task.args:
                raise AnsibleError("'pool_id' is a required argument.")
            pool_id = self._task.args.get('pool_id', None)

            if 'subnet' not in self._task.args:
                raise AnsibleError("'subnet' is a required argument.")
            subnet = self._task.args.get('subnet', None)

            if 'ip_address' not in self._task.args:
                raise AnsibleError("'ip_address' is a required argument.")
            ip_address = self._task.args.get('ip_address', None)

            if 'porttype' not in self._task.args:
                raise AnsibleError("'porttype' is a required argument.")
            porttype = self._task.args.get('porttype', None)

            if 'membernum' in self._task.args:
               membernum = self._task.args.get('membernum', None)

            if 'ni_type' not in self._task.args:
                raise AnsibleError("'ni_type' is a required argument.")
            ni_type = self._task.args.get('ni_type', None)

            # Confirm the IP address is valid
            if (not is_valid_ipv4_address(ip_address)) and (not is_valid_ipv6_address(ip_address)):
                result['failed'] = True
                result['msg'] = "Invalid IP Address %s" % ip_address
                return result

            # we already validated porttype in CBAM

            arg_string=" -a " + action + " -t " + svc_type + " -i " + pool_id + " -s " + subnet + " -o " + ip_address + " -n " + ni_type + " --porttype " + porttype + " --reuse "

            # membernum not allowed for a float
            if membernum != "unknown" and membernum != "":
                arg_string += " -m " + membernum

        else:
            # Required Args in the add_subnet and del_subnet case
            if 'subnet_base' not in self._task.args:
                raise AnsibleError("'subnet_base' is a required argument.")
            subnet_base = self._task.args.get('subnet_base', None)

            if 'subnet_number' not in self._task.args:
                raise AnsibleError("'subnet_number' is a required argument.")
            subnet_number = self._task.args.get('subnet_number', None)

            if action == "add_subnet":
                # Required Args in the add case
                if 'subnet_name' not in self._task.args:
                    raise AnsibleError("'subnet_name' is a required argument.")
                subnet_name = self._task.args.get('subnet_name', None)

                if 'netmask' not in self._task.args:
                    raise AnsibleError("'netmask' is a required argument.")
                netmask = self._task.args.get('netmask', None)

                if 'eipm_mode' not in self._task.args:
                    raise AnsibleError("'eipm_mode' is a required argument.")
                eipm_mode = self._task.args.get('eipm_mode', None)

                if 'interface_name' not in self._task.args:
                    raise AnsibleError("'interface_name' is a required argument.")
                interface_name = self._task.args.get('interface_name', None)

                arg_string=" -a " + action + " -b " + subnet_base + " -s " + subnet_number + " -m " + netmask + " -n " + subnet_name + " -t " + interface_name + " -e " + eipm_mode

                # Optional Args in the add case
                if eipm_mode == "eipm_acm" or eipm_mode == "eipm_arpndp":
                    if 'subnet_gateway_ip' not in self._task.args:
                        raise AnsibleError("'subnet_gateway_ip' is a required argument.")
                    subnet_gateway_ip = self._task.args.get('subnet_gateway_ip', None)
                else:
                    if 'subnet_gateway_ip' in self._task.args:
                        subnet_gateway_ip = self._task.args.get('subnet_gateway_ip', None)

                if subnet_gateway_ip != "unknown" and subnet_gateway_ip != "":
                    arg_string += " -o " + subnet_gateway_ip

                if eipm_mode == "eipm_arpndp":
                    if 'detect_multiplier' in self._task.args:
                        detect_multiplier = self._task.args.get('detect_multiplier', None)

                    if detect_multiplier != "unknown" and detect_multiplier != "":
                        arg_string += " -d " + detect_multiplier

                    if 'desired_min_rx_int' in self._task.args:
                        desired_min_rx_int = self._task.args.get('desired_min_rx_int', None)

                    if desired_min_rx_int != "unknown" and desired_min_rx_int != "":
                        arg_string += " -r " + desired_min_rx_int

                    if 'reqd_min_tx_int' in self._task.args:
                        reqd_min_tx_int = self._task.args.get('reqd_min_tx_int', None)

                    if reqd_min_tx_int != "unknown" and reqd_min_tx_int != "":
                        arg_string += " -x " + reqd_min_tx_int

                if 'customer_vlan' in self._task.args:
                    customer_vlan = self._task.args.get('customer_vlan', None)

                if customer_vlan != "unknown" and customer_vlan != "":
                    arg_string += " -v " + customer_vlan

                if 'mtu' in self._task.args:
                    mtu = self._task.args.get('mtu', None)

                if mtu != "unknown" and mtu != "":
                    arg_string += " --mtu " + mtu

            else:
                arg_string=" -a " + action + " -b " + subnet_base + " -s " + subnet_number


        result['changed'] = False
        result['IP_ADM_ARGS'] = arg_string
        return result

# used to confirm ip address is valid
def is_valid_ipv4_address(address):
    try:
        socket.inet_pton(socket.AF_INET, address)
    except AttributeError:  # no inet_pton here, sorry
        try:
            socket.inet_aton(address)
        except socket.error:
            return False
        return address.count('.') == 3
    except socket.error:  # not a valid address
        return False

    return True

def is_valid_ipv6_address(address):
    try:
        socket.inet_pton(socket.AF_INET6, address)
    except socket.error:  # not a valid address
        return False
    return True

