#! /bin/ksh

LOGFILE=/data0/FLD/full_restore.log

#write to log file and standard output, prefixed with current time
log() {
    curtime=`/bin/date +"%Y-%m-%d %T:"`
    /bin/echo -e ${curtime}" "$* >> ${LOGFILE}
}

# Clean up log file
> ${LOGFILE}

if [[ -z $2 ]]
then
    log "Start signaling restore."
else
    log "Start media and signaling restore."
fi

backup_file=/data0/`echo $1 | awk -F "/" '{print $NF}'`

/opt/LU3P/bin/zipinfo $backup_file | egrep ".sys_params.txt|LCM_extensions.json" >/dev/null
if [[ $? = 0 ]]
then
    log "$backup_file is a combined backup file. Extract the inner backup file."
    unzip -o -d /data0 $backup_file >> ${LOGFILE} 2>&1
    
    # Remove the combined backup file (We only need the inner zip file).
    rm -f $backup_file
    
    # Remove the syetem parameter files.
    rm -f *.json
    rm -f *.sys_params.txt
    
    # Get the inner backup file name
    backup_file=$(ls /data0/*LCP*zip)
fi

host_data="/var/opt/lib/sysconf/host.data"
host_layout="/var/opt/lib/sysconf/host.layout"

# Remove old backup files
log "Remove all old backup files."
host_index=$(grep HOST_DATA_HOST_HOSTNAME $host_layout | grep -v '^#' | awk -F'=' '{print $2}' | sed s/[[:space:]]//g)
for hostname in `grep -v '^#' $host_data | grep ';mi,' | awk -v i=$host_index -F';' '{print $i}'`
do
    ssh $hostname "rm -rf /storage/conf_backup/LCP"
done

# Command to unpack encrypted backup zip file.
log "Unpack the encrypted backup zip file ${backup_file}."
/opt/LSS/sbin/bkup_adm --force --vmstate ignore -d 2 -s -a get -i 127.0.0.1 --local --rf $backup_file >> ${LOGFILE} 2>&1
dir=/storage/conf_backup/LCP/$(ls /storage/conf_backup/LCP)
# Remove the backup file under /data0
rm -f $backup_file

# Restore media part if needed
if [[ ! -z $2 ]]
then
    log "Restoring media part ${2} from ${dir}."
    /opt/LSS/sbin/sbc_restore_mp --dir $dir --plane $2 >> ${LOGFILE} 2>&1
fi

# Retrieve the current running version number.
tmp=$(mi_adm -a version 2>/dev/null | awk 'NF==1 {print $1} NF==2 {print $2}' | grep -e "^R[0-9]" | sort -u)
if [ -z ${tmp} ]
then
	log "ERROR: failed to determine current running version number for ${arch_type} diskfull hosts."
	exit 32
fi
currVer=${tmp}

let lineNum=0
lineNum=$(print "${currVer}" | wc -l)
if (( ${lineNum} > 1 ))
then
	log "ERROR: ${arch_type} diskfull hosts have different version numbers."
	exit 33
fi

bkVer=$(cat ${dir}/BKUPINFO | grep '^VERSION' | awk -F '=' '{print $2}')
if [[ $currVer != $bkVer ]]
then
    log "ERROR: Backup version $bkVer not match with current version $currVer"
    exit 34
fi

# Terminate any previously runnning restore procedure and init the SIM data.
log "Terminate any previously runnning restore procedure and init the SIM data."
mtce_sim --action terminate --proc restore --no_prompt >/dev/null 2>&1
mtce_sim --action init --proc restore --no_prompt >/dev/null 2>&1

log "Start to restore signaling part from ${dir}. For the log details, please check the restore log /storage/sim/log/restore/sim.log"
# Note: this script completes independent of the sim script invoked.
expect -- << EXPECTEND
set timeout 3600
spawn ksh -- "sim --proc restore --action apply --sub_proc LCP_restore --level \"${dir} no\"; sleep 300; tail -f /storage/sim/log/restore/sim.log"
expect {
	"Continue? (y|n)" { send "y\r"; exp_continue;}
    "*COMPLETED SIM PROCEDURE*" { exit 0 }
    "*EXIT: (FAILURE)*" { send_user "Restore failure\r"; exit 31 }
}
close
EXPECTEND

ret=$?
# Suppose this script won't reach the end here because a reboot will be triggered during signaling restore.
log "End of full restore."

exit $ret

