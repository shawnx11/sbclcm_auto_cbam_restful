#!/usr/bin/expect
set timeout 10
set cmdstr(0) "/export/home/lss/bin/wimdbcfg.sh -q qid > /tmp/wimdbcfg.out"
spawn su - lss
expect "Enter return to acknowledge message of the day: "
exp_send "GOOD DAY\r"
expect "TERM type? (default = vt220): "
exp_send "\r"
expect "Command line editor? (default = vi):"
exp_send "emacs\r"
expect "*\>"
for {set i 0} {$i<[array size cmdstr]} {incr i} {
    send "$cmdstr($i)\r\r\r"
    expect "*\>"
}
send \"exit\r\"

