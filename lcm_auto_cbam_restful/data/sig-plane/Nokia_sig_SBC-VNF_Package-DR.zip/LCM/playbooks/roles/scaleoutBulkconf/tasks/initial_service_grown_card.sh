#!/bin/ksh


hosts_file=/etc/hosts
grow_log_vmware=/storage/VOLS/logs/sim/lcp_hostgrow/sim.log
grow_log_openstack=/data0/FLD/scale-out.log
vmware=FALSE
openstack=FALSE
grown_card_vmware_log=/storage/VOLS/logs/sim/lcp_hostgrow/grown_card.log
grown_card_openstack_log=/data0/FLD/grown_card.log
platform_config_file=/etc/opt/LSS/cloud_platform

#*****find the platform*****
#*****/storage/VOLS/logs/sim/lcp_hostgrow/sim.log file for VMWARE*****
#*****/data0/FLD/scale-out.log file for openstack
find_platform(){
if [[ ! -f $platform_config_file ]]; then
    echo "can't find the platform config file $platform_config_file, please seek next level support" >>/tmp/netconfprov-temp/initial_service_grown_card.log
    vmware=FALSE
    openstack=FALSE
    exit 1
else
    plateform_type=`cat $platform_config_file`
    if [[ $plateform_type == "vmware" && -f /storage/cloud/discover/meta_data.json ]]; then
        # This is lcm control mode scaling which has the same process with openstack platform
        plateform_type="openstack"
    fi
    echo "The plateform type is $plateform_type" >>/tmp/netconfprov-temp/initial_service_grown_card.log
    if [[ $plateform_type == "openstack" ]]; then
        echo "The grow operation is executed on the openstack platform" >>/tmp/netconfprov-temp/initial_service_grown_card.log
        openstack=TRUE
        vmware=FALSE
    elif [[ $plateform_type == "vmware" ]]; then
        echo "The grow operation is executed on the vmware platform" >>/tmp/netconfprov-temp/initial_service_grown_card.log
        vmware=TRUE
        openstack=FALSE
    else
        echo "The grow operation should be executed on the openstack platform or vmware platform" >>/tmp/netconfprov-temp/initial_service_grown_card.log
        exit 1
    fi
fi
}

#*****get the grown card log*****
#*****$grow_log_openstack using the append to create the log, search the card name from the end of the log*****
#*****$grow_log_vmware is the current grown log, the log was save in other name for the previous grow operation*****
get_grown_card_log(){

if [[ $vmware == "TRUE" ]] && [[ $openstack == "FALSE" ]]; then
    grep "closed by remote host" $grow_log_vmware > $grown_card_vmware_log
    echo "Get the grown card info for vmware $grown_card_vmware_log" >>/tmp/netconfprov-temp/initial_service_grown_card.log
elif [[ $vmware == "FALSE" ]] && [[ $openstack == "TRUE" ]]; then
    tail -n 50 $grow_log_openstack | grep "scale-out completed on" > $grown_card_openstack_log
    echo "Get the grown card info for openstack $grown_card_openstack_log" >>/tmp/netconfprov-temp/initial_service_grown_card.log
else
    echo "Can't get the grown card info, please seek next level support" >>/tmp/netconfprov-temp/initial_service_grown_card.log
fi

}

#*****get the grown card ip information form /etc/hosts
initial_service_grown_card(){

if [[ $vmware == "TRUE" ]] && [[ -f $grown_card_vmware_log ]]; then
    while read line;
    do
    card_name=`echo $line | cut -d " " -f6`
    echo "Get the card name $card_name" >>/tmp/netconfprov-temp/initial_service_grown_card.log
    IP_string=`grep $card_name $hosts_file | grep -v $card_name-`
    IP_addr=`echo $IP_string | cut -d ' ' -f1`
    echo "Get the IP addr for $card_name card" >>/tmp/netconfprov-temp/initial_service_grown_card.log
    /opt/LSS/bin/init_cli -t l -i $IP_addr
    echo "initial the service on $card_name using IP $IP_addr" >>/tmp/netconfprov-temp/initial_service_grown_card.log
    done < ${grown_card_vmware_log}
    return 0
elif [[ $openstack == "TRUE" ]] && [[ -f $grown_card_openstack_log ]]; then
    while read line;
    do
    card_name=`echo $line | cut -d ":" -f6`
    echo "Get the card name $card_name" >>/tmp/netconfprov-temp/initial_service_grown_card.log
    IP_string=`grep $card_name $hosts_file | grep -v $card_name-`
    IP_addr=`echo $IP_string | cut -d ' ' -f1`
    echo "Get the IP addr for $card_name card" >>/tmp/netconfprov-temp/initial_service_grown_card.log
    /opt/LSS/bin/init_cli -t l -i $IP_addr
    echo "initial the service on $card_name using IP $IP_addr" >>/tmp/netconfprov-temp/initial_service_grown_card.log
    done < ${grown_card_openstack_log}
    return 0
else
    echo "Can't initial the service, please seek the next level support" >>/tmp/netconfprov-temp/initial_service_grown_card.log
    return 1
fi
}
# *****Main Part*****
#*****This script is called by the ansible playbook to initial the service for the new grown card*****
find_platform
get_grown_card_log
initial_service_grown_card
exit_code=$?
if [[ $exit_code != 0 ]]; then
    echo "initial service on new grown cards failed, please seek next level for support" >>/tmp/netconfprov-temp/initial_service_grown_card.log
    exit 1
else
    echo "initial service on new grown cards successfully" >>/tmp/netconfprov-temp/initial_service_grown_card.log
    exit 0
fi

