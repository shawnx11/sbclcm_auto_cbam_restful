#!/bin/bash
. /opt/LSS/bin/RCCsetup
/export/home/lss/bin/dbdump -u lssdba -p lssdba -noversion -b -all
if [[ $? != 0 ]]; then
        echo "!!! ERROR: dbdump failed! Please seek next level of support...!!!"
        exit 1
fi
mkdir -p /storage/prov_zero_config
if [[ -d /storage/prov_zero_config ]]; then
        if [[ ! -f /storage/prov_zero_config/sig.zeroconfig.zip ]]; then
                zip /storage/prov_zero_config/sig.zeroconfig.zip *.xbin > /dev/null
		if [[ $? -ne 0 ]]; then
		        echo "!!! ERROR: sig.zeroconfig.zip generation failed! Please seek next level of support...!!!"
		        exit 1
		fi
	        echo "!!!sig.zeroconfig.zip saved at /storage/prov_zero_config for future reference...!!!"
	else
	        echo "!!!sig.zeroconfig.zip already exist at /storage/prov_zero_config for future reference...!!!"
        fi
else
        echo "/storage/prov_zero_config does not exist. Please seek next level of support !!!"
        exit 1
fi
exit 0


