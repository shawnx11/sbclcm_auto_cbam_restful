var rules = []

if (Object.keys($.newVnfcs).length > 0) {
    var firstNewVnfcId = Object.keys($.newVnfcs).sort()[0]

    if (Object.keys($.existingVnfcs).length > 0) {
        var lastExistingVnfcId = Object.keys($.existingVnfcs).sort().slice(-1)[0]
        rules.push(
            {
                "affinityOrAntiAffinity": "ANTI_AFFINITY",
                "scope": "ZONE",
                "resourceKeys": [lastExistingVnfcId, firstNewVnfcId]
            }
        )
    }

    var lastVnfcIds = []
    Object.keys($.newVnfcs).sort().forEach(function(vnfc){
        lastVnfcIds.push(vnfc)
        if (lastVnfcIds.length == 2) {
            rules.push(
                {
                    "affinityOrAntiAffinity": "ANTI_AFFINITY",
                    "scope": "ZONE",
                    "resourceKeys": lastVnfcIds
                }
            )
            lastVnfcIds = [vnfc]
        }
    })
}
return {"placementConstraints": rules}
