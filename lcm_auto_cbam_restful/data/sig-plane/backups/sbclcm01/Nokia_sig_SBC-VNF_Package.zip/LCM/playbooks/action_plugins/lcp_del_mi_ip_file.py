#!/usr/bin/python

DOCUMENTATION = '''
---
action_plugin: lcp_set_mi_ip.py
short_description: action plugin used to remove entry from the MI IP address file

This plugin will remove an entry from the MI IP address file
'''

import json      # json interpreter module
import os        # os access module

from ansible                import constants as C
from ansible.plugins.action import ActionBase
from ansible.errors         import AnsibleError

#display = Display()

class ActionModule(ActionBase):

    def run(self, tmp=None, task_vars=None):
        if task_vars is None:
            task_vars = dict()

        result = super(ActionModule, self).run(tmp, task_vars)

        # Default the return result
        result.update(dict(
            changed = False,
            rc      = 0,
            stderr  = '',
            stdout  = '',
        ))

        if 'stackID' not in self._task.args:
            raise AnsibleError("'stackID' is a required argument.")
        stackID = self._task.args.get('stackID', None)

        # This action item does not fail
        result['changed'] = False

        json_file = "mi_ip_file.json"

        # Does mi_ip_file.json exist
        if not os.path.exists(json_file):
            return result

        # If mi_ip_file.json is empty
        if os.path.getsize(json_file) == 0:
            return result

        # IP file exists and is not size 0
        with open(json_file, 'r') as json_data_file:
            file_entry_s = json_data_file.read().replace('\n', '')

        json_data_file.close

        # Confirm that the file json is valid
        if not is_valid_json(file_entry_s):
            return result
        else:
            jas = json.loads(file_entry_s)
            if stackID in jas:
                del jas[stackID]
                os.remove(json_file)
                json_data_file = open(json_file,'w')
                json.dump(jas, json_data_file)
                json_data_file.close

        return result

def is_valid_json( json_string ):
    try:
        jtst = json.loads(json_string)
    except ValueError, e:
        return False

    return True

