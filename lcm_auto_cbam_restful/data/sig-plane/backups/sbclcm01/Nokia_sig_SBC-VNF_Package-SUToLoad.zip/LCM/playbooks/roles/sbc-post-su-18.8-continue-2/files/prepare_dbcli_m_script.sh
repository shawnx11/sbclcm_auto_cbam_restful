#!/bin/bash
var1=$1
var2=$2
sed "s/hostname/$var1/g" /tmp/dbcli_script/dbcli_m_script.sh > /tmp/dbcli_script/temp.sh
sed "s/qid/$var2/g" /tmp/dbcli_script/temp.sh > /tmp/dbcli_script/expect_dbcli_m_script.sh
