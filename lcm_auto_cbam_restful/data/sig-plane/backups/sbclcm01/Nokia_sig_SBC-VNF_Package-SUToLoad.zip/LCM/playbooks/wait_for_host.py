#!/usr/bin/env python
import os
import sys
import socket
from paramiko import ssh_exception
from paramiko.client import SSHClient, AutoAddPolicy
from paramiko.rsakey import RSAKey
from time import sleep
from six import StringIO
import subprocess
from subprocess import Popen, PIPE

if __name__ == '__main__':
    args = sys.argv[1:]
    host_list = args[0].split(',')
    user = args[1]
    pass_or_key = args[2]
    retries = args[3]

    ssh_client = SSHClient()
    ssh_client.set_missing_host_key_policy(AutoAddPolicy())

    for attempt in range(int(retries)):
        for host in host_list:
            try:
                if os.path.exists(pass_or_key):
                    # The CBAM's paramiko can't support host key alg ecdsa384 and ecdsa521 currently. We have to use openssh to complete the ssh connection try here.
                    command='ssh -i ' + pass_or_key + ' -o StrictHostKeyChecking=no -o ConnectTimeout=30 -o BatchMode=yes ' + user + '@' + host + ' date '
                    proc = Popen(command, shell = True, stdout = PIPE, stderr = PIPE)
                    rc = proc.wait()
                    if rc != 0:
                        raise ssh_exception.SSHException, '"' + command + '" failed'
                else:
                    ssh_client.connect(hostname=host,
                                       username=user,
                                       password=pass_or_key,
                                       look_for_keys=False,
                                       allow_agent=False,
                                       timeout=30,
                                       banner_timeout=30)
                sys.stdout.write(host)
                sys.stdout.flush()

                exit(0)
            except (socket.error, ssh_exception.SSHException, ssh_exception.NoValidConnectionsError):
                continue

        #pause = 2 ** attempt - 1
        #if pause > 30:
        #    pause = 30
        #sleep(pause)
        sleep(30)

    print('Could not establish SSH connection for any of {0}.'.format(
        str(host_list)))
    exit(1)

