var servicenames=["mi", "cdr", "h248", "feph", "afed", "cfed", "dfed", "pfed", "ims"]
var version_node=190000

var Oam_Customization=[
"#!/bin/sh",
"echo \"$1\" >> /root/params",
"chmod 600 /root/params",
"export DEBIAN_FRONTEND=noninteractive",
"if [ \"x$1\" = \"xprecustomization\" ]; then",
"  export LC_ALL=\"en_US.UTF-8\"",
"  mkdir -p /export/home/lcmadm/.ssh",
"  mkdir -p /root/.ssh",
"  /usr/bin/vmtoolsd --cmd \"info-get guestinfo.ovfEnv\" > /tmp/config.xml",
"  /usr/bin/cat /tmp/config.xml | /bin/xmlstarlet sel -N 'ovfenv=http://schemas.dmtf.org/ovf/environment/1' -t --match '//ovfenv:Property[@ovfenv:key='\\'cbam.publicSshKey\\'']' --value-of '@ovfenv:value' --nl >> /root/.ssh/authorized_keys",
"  /usr/bin/cat /tmp/config.xml | /bin/xmlstarlet sel -N 'ovfenv=http://schemas.dmtf.org/ovf/environment/1' -t --match '//ovfenv:Property[@ovfenv:key='\\'cbam.publicSshKey\\'']' --value-of '@ovfenv:value' --nl >> /export/home/lcmadm/.ssh/authorized_keys",
"  chown lcmadm:lcmadm /export/home/lcmadm",
"  chown lcmadm:lcmadm /export/home/lcmadm/.ssh",
"  chown lcmadm:lcmadm /export/home/lcmadm/.ssh/authorized_keys",
"  /usr/bin/cat /root/.ssh/authorized_keys2 >> /export/home/lcmadm/.ssh/authorized_keys2",
"  chown lcmadm:lcmadm /export/home/lcmadm/.ssh/authorized_keys2",
"  echo \"{\\\"sbc_version_node\\\":\\\"" + version_node + "\\\"}\" > /root/meta_data.json",
"  mv /tmp/config.xml /root/config.xml",
"fi",
"if [ \"x$1\" = \"xpostcustomization\" ]; then",
"  chmod -R 700 /root/.customization",
"fi",
"exit 0"
].join("\n")

var heal_OamScript=[
"#!/bin/sh",
"echo \"$1\" >> /root/params",
"chmod 600 /root/params",
"export DEBIAN_FRONTEND=noninteractive",
"if [ \"x$1\" = \"xprecustomization\" ]; then",
"  export LC_ALL=\"en_US.UTF-8\"",
"  mkdir -p /export/home/lcmadm/.ssh",
"  mkdir -p /root/.ssh",
"  /usr/bin/vmtoolsd --cmd \"info-get guestinfo.ovfEnv\" > /tmp/config.xml",
"  /usr/bin/cat /tmp/config.xml | /bin/xmlstarlet sel -N 'ovfenv=http://schemas.dmtf.org/ovf/environment/1' -t --match '//ovfenv:Property[@ovfenv:key='\\'cbam.publicSshKey\\'']' --value-of '@ovfenv:value' --nl >> /root/.ssh/authorized_keys",
"  /usr/bin/cat /tmp/config.xml | /bin/xmlstarlet sel -N 'ovfenv=http://schemas.dmtf.org/ovf/environment/1' -t --match '//ovfenv:Property[@ovfenv:key='\\'cbam.publicSshKey\\'']' --value-of '@ovfenv:value' --nl >> /export/home/lcmadm/.ssh/authorized_keys",
"  chown lcmadm:lcmadm /export/home/lcmadm",
"  chown lcmadm:lcmadm /export/home/lcmadm/.ssh",
"  chown lcmadm:lcmadm /export/home/lcmadm/.ssh/authorized_keys",
"  /usr/bin/cat /root/.ssh/authorized_keys2 >> /export/home/lcmadm/.ssh/authorized_keys2",
"  chown lcmadm:lcmadm /export/home/lcmadm/.ssh/authorized_keys2",
"  sed -i '/vnfc.lcm_action/c\         <Property oe:key=\"vnfc.lcm_action\" oe:value=\"heal\"/>' /tmp/config.xml",
"  new_ovf_env=`cat /tmp/config.xml`",
"  /usr/bin/vmtoolsd --cmd \"info-set guestinfo.ovfEnv ${new_ovf_env}\"",
"  echo \"{\\\"sbc_version_node\\\":\\\"" + version_node + "\\\"}\" > /root/meta_data.json",
"  mv /tmp/config.xml /root/config.xml",
"fi",
"if [ \"x$1\" = \"xpostcustomization\" ]; then",
"  chmod -R 700 /root/.customization",
"fi",
"exit 0"
].join("\n")

var recreate_OamScript=[
"#!/bin/sh",
"echo \"$1\" >> /root/params",
"chmod 600 /root/params",
"export DEBIAN_FRONTEND=noninteractive",
"if [ \"x$1\" = \"xprecustomization\" ]; then",
"  export LC_ALL=\"en_US.UTF-8\"",
"  mkdir -p /export/home/lcmadm/.ssh",
"  mkdir -p /root/.ssh",
"  /usr/bin/vmtoolsd --cmd \"info-get guestinfo.ovfEnv\" > /tmp/config.xml",
"  /usr/bin/cat /tmp/config.xml | /bin/xmlstarlet sel -N 'ovfenv=http://schemas.dmtf.org/ovf/environment/1' -t --match '//ovfenv:Property[@ovfenv:key='\\'cbam.publicSshKey\\'']' --value-of '@ovfenv:value' --nl >> /root/.ssh/authorized_keys",
"  /usr/bin/cat /tmp/config.xml | /bin/xmlstarlet sel -N 'ovfenv=http://schemas.dmtf.org/ovf/environment/1' -t --match '//ovfenv:Property[@ovfenv:key='\\'cbam.publicSshKey\\'']' --value-of '@ovfenv:value' --nl >> /export/home/lcmadm/.ssh/authorized_keys",
"  chown lcmadm:lcmadm /export/home/lcmadm",
"  chown lcmadm:lcmadm /export/home/lcmadm/.ssh",
"  chown lcmadm:lcmadm /export/home/lcmadm/.ssh/authorized_keys",
"  /usr/bin/cat /root/.ssh/authorized_keys2 >> /export/home/lcmadm/.ssh/authorized_keys2",
"  chown lcmadm:lcmadm /export/home/lcmadm/.ssh/authorized_keys2",
"  sed -i '/vnfc.lcm_action/c\         <Property oe:key=\"vnfc.lcm_action\" oe:value=\"recreate\"/>' /tmp/config.xml",
"  new_ovf_env=`cat /tmp/config.xml`",
"  /usr/bin/vmtoolsd --cmd \"info-set guestinfo.ovfEnv ${new_ovf_env}\"",
"  echo \"{\\\"sbc_version_node\\\":\\\"" + version_node + "\\\"}\" > /root/meta_data.json",
"  mv /tmp/config.xml /root/config.xml",
"fi",
"if [ \"x$1\" = \"xpostcustomization\" ]; then",
"  chmod -R 700 /root/.customization",
"fi",
"exit 0"
].join("\n")


function healOamScript(imageId){
  return heal_OamScript;
}

function healVMScript(id, vnfc_suffix, current_group_count, total_pair_count){
    
    var heal_VMscript=[
"#!/bin/sh",
"echo \"$1\" >> /root/params",
"chmod 600 /root/params",
"if [ \"x$1\" = \"xprecustomization\" ]; then",
"  export LC_ALL=\"en_US.UTF-8\"",
"  export ADMIN_LOGIN=\"lcmadm\"",
"  mkdir -p /root/.ssh",
"  /usr/bin/vmtoolsd --cmd \"info-get guestinfo.ovfEnv\" > /tmp/config.xml",
"  /usr/bin/cat /tmp/config.xml | /bin/xmlstarlet sel -N 'ovfenv=http://schemas.dmtf.org/ovf/environment/1' -t --match '//ovfenv:Property[@ovfenv:key='\\'cbam.publicSshKey\\'']' --value-of '@ovfenv:value' --nl > /root/.ssh/authorized_keys",
"  mkdir -p /home/\$ADMIN_LOGIN/.ssh",
"  export publicSshKey=\"$cbam.publicSshKey\"",
"  echo \$publicSshKey >> /home/\$ADMIN_LOGIN/.ssh/authorized_keys",
"  echo \$publicSshKey >> /home/root/.ssh/authorized_keys",
"  /usr/bin/cat /home/root/.ssh/authorized_keys2 >> /home/\$ADMIN_LOGIN/.ssh/authorized_keys2",
"  sed -i '/vnfc.lcm_action/c\         <Property oe:key=\"vnfc.lcm_action\" oe:value=\"heal\"/>' /tmp/config.xml",
"  sed -i '/vnfc.suffix/c <Property oe:key=\\\"vnfc.suffix\\\" oe:value=\\\"" + vnfc_suffix + "\\\"/>' /tmp/config.xml  2>>/root/error.log",
"  new_ovf_env=`cat /tmp/config.xml`",
"  /usr/bin/vmtoolsd --cmd \"info-set guestinfo.ovfEnv ${new_ovf_env}\"",
"  echo \"{\\\"group_index\\\":\\\"" + id + "\\\", \\\"current_group_count\\\":\\\"" + current_group_count + "\\\", \\\"total_pair_count\\\":\\\"" + total_pair_count + "\\\"}\" > /root/meta_data.json",
"  mv /tmp/config.xml /root/config.xml",
"fi",
"if [ \"x$1\" = \"xpostcustomization\" ]; then",
"  chmod -R 700 /root/.customization",
"fi",
"exit 0"
].join("\n")

  return heal_VMscript;
}

function recreateOamScript(imageId){
  return recreate_OamScript;
}

function recreateVMScript(id, vnfc_suffix, current_group_count, total_pair_count){

    var recreate_VMScript=[
"#!/bin/sh",
"echo \"$1\" >> /root/params",
"chmod 600 /root/params",
"if [ \"x$1\" = \"xprecustomization\" ]; then",
"  export LC_ALL=\"en_US.UTF-8\"",
"  export ADMIN_LOGIN=\"lcmadm\"",
"  mkdir -p /root/.ssh",
"  /usr/bin/vmtoolsd --cmd \"info-get guestinfo.ovfEnv\" > /tmp/config.xml",
"  /usr/bin/cat /tmp/config.xml | /bin/xmlstarlet sel -N 'ovfenv=http://schemas.dmtf.org/ovf/environment/1' -t --match '//ovfenv:Property[@ovfenv:key='\\'cbam.publicSshKey\\'']' --value-of '@ovfenv:value' --nl > /root/.ssh/authorized_keys",
"  mkdir -p /home/\$ADMIN_LOGIN/.ssh",
"  export publicSshKey=\"$cbam.publicSshKey\"",
"  echo \$publicSshKey >> /home/\$ADMIN_LOGIN/.ssh/authorized_keys",
"  echo \$publicSshKey >> /home/root/.ssh/authorized_keys",
"  /usr/bin/cat /home/root/.ssh/authorized_keys2 >> /home/\$ADMIN_LOGIN/.ssh/authorized_keys2",
"  sed -i '/vnfc.lcm_action/c\         <Property oe:key=\"vnfc.lcm_action\" oe:value=\"recreate\"/>' /tmp/config.xml",
"  sed -i '/vnfc.suffix/c <Property oe:key=\\\"vnfc.suffix\\\" oe:value=\\\"" + vnfc_suffix + "\\\"/>' /tmp/config.xml  2>>/root/error.log",
"  new_ovf_env=`cat /tmp/config.xml`",
"  /usr/bin/vmtoolsd --cmd \"info-set guestinfo.ovfEnv ${new_ovf_env}\"",
"  echo \"{\\\"group_index\\\":\\\"" + id + "\\\", \\\"current_group_count\\\":\\\"" + current_group_count + "\\\", \\\"total_pair_count\\\":\\\"" + total_pair_count + "\\\"}\" > /root/meta_data.json",
"  mv /tmp/config.xml /root/config.xml",
"fi",
"if [ \"x$1\" = \"xpostcustomization\" ]; then",
"  chmod -R 700 /root/.customization",
"fi",
"exit 0"
].join("\n")

  return recreate_VMScript;
}

function getOamCustomization(imageId){
  return Oam_Customization;
}

function getVMCustomization(id, vnfc_suffix, current_group_count, total_pair_count){

    var VM_Customization=[
"#!/bin/sh",
"echo \"$1\" >> /root/params",
"chmod 600 /root/params",
"if [ \"x$1\" = \"xprecustomization\" ]; then",
"  export LC_ALL=\"en_US.UTF-8\"",
"  export ADMIN_LOGIN=\"lcmadm\"",
"  mkdir -p /root/.ssh",
"  /usr/bin/vmtoolsd --cmd \"info-get guestinfo.ovfEnv\" > /tmp/config.xml",
"  /usr/bin/cat /tmp/config.xml | /bin/xmlstarlet sel -N 'ovfenv=http://schemas.dmtf.org/ovf/environment/1' -t --match '//ovfenv:Property[@ovfenv:key='\\'cbam.publicSshKey\\'']' --value-of '@ovfenv:value' --nl > /root/.ssh/authorized_keys",
"  mkdir -p /home/\$ADMIN_LOGIN/.ssh",
"  export publicSshKey=\"$cbam.publicSshKey\"",
"  echo \$publicSshKey >> /home/\$ADMIN_LOGIN/.ssh/authorized_keys",
"  echo \$publicSshKey >> /home/root/.ssh/authorized_keys",
"  /usr/bin/cat /home/root/.ssh/authorized_keys2 >> /home/\$ADMIN_LOGIN/.ssh/authorized_keys2",
"  sed -i '/vnfc.suffix/c <Property oe:key=\\\"vnfc.suffix\\\" oe:value=\\\"" + vnfc_suffix + "\\\"/>' /tmp/config.xml  2>>/root/error.log",
"  echo \"{\\\"group_index\\\":\\\"" + id + "\\\", \\\"current_group_count\\\":\\\"" + current_group_count + "\\\", \\\"total_pair_count\\\":\\\"" + total_pair_count + "\\\"}\" > /root/meta_data.json",
"  mv /tmp/config.xml /root/config.xml",
"fi",
"if [ \"x$1\" = \"xpostcustomization\" ]; then",
"  chmod -R 700 /root/.customization",
"fi",
"exit 0"
].join("\n")

  return VM_Customization;
}

function getScaleoutCustomization(id, vnfc_suffix, vnfc_matesuffix, ipAddress, current_group_count, total_pair_count) {
    var group_index = parseInt(id) + 61
    
    var  scriptScaleout=[
"#!/bin/sh", 
"echo \"$1\" >> /root/params",
"chmod 600 /root/params",
"if [ \"x$1\" = \"xprecustomization\" ]; then", 
"  export LC_ALL=\"en_US.UTF-8\"", 
"  export ADMIN_LOGIN=\"lcmadm\"",
"  mkdir -p /root/.ssh",
"  /usr/bin/vmtoolsd --cmd \"info-get guestinfo.ovfEnv\" > /tmp/config.xml", 
"  /usr/bin/cat /tmp/config.xml | /bin/xmlstarlet sel -N 'ovfenv=http://schemas.dmtf.org/ovf/environment/1' -t --match '//ovfenv:Property[@ovfenv:key='\\'cbam.publicSshKey\\'']' --value-of '@ovfenv:value' --nl > /root/.ssh/authorized_keys",
"  mkdir -p /home/\$ADMIN_LOGIN/.ssh",
"  export publicSshKey=\"$cbam.publicSshKey\"",
"  echo \$publicSshKey >> /home/\$ADMIN_LOGIN/.ssh/authorized_keys",
"  echo \$publicSshKey >> /home/root/.ssh/authorized_keys",
"  /usr/bin/cat /home/root/.ssh/authorized_keys2 >> /home/\$ADMIN_LOGIN/.ssh/authorized_keys2",
"  sed -i '/vnfc.suffix/c <Property oe:key=\\\"vnfc.suffix\\\" oe:value=\\\"" + vnfc_suffix + "\\\"/>' /tmp/config.xml  2>>/root/error.log",
"  sed -i '/vnfc.group_index/c <Property oe:key=\\\"vnfc.group_index\\\" oe:value=\\\"" + group_index + "\\\"/>' /tmp/config.xml 2>>/root/error.log",
"  sed -i '/<\\/PropertySection>/i <Property oe:key=\\\"vnfc.matesuffix\\\" oe:value=\\\"" + vnfc_matesuffix + "\\\"/>' /tmp/config.xml 2>>/root/error.log",
"  sed -i '/<\\/PropertySection>/i <Property oe:key=\\\"vnf.growth_svcinfo\\\" oe:value=\\\"" + ipAddress + "\\\"/>' /tmp/config.xml 2>>/root/error.log",
"  sed -i '/vnfc.lcm_action/c <Property oe:key=\\\"vnfc.lcm_action\\\" oe:value=\\\"scale-out\\\"/>' /tmp/config.xml 2>>/root/error.log",
"  new_ovf_env=`cat /tmp/config.xml`",
"  /usr/bin/vmtoolsd --cmd \"info-set guestinfo.ovfEnv ${new_ovf_env}\"",
"  echo \"{\\\"group_index\\\":\\\"" + id + "\\\", \\\"current_group_count\\\":\\\"" + current_group_count + "\\\", \\\"total_pair_count\\\":\\\"" + total_pair_count + "\\\"}\" > /root/meta_data.json",
"  mv /tmp/config.xml /root/config.xml",
"fi", 
"if [ \"x$1\" = \"xpostcustomization\" ]; then", 
"  chmod -R 700 /root/.customization",
"fi",
"exit 0"
].join("\n")

    return scriptScaleout;
}

function healVMScript_olv(id, vnfc_suffix, current_group_count, total_pair_count){
    
    var heal_VMscript=[
"#!/bin/sh",
"echo \"$1\" >> /root/params",
"chmod 600 /root/params",
"if [ \"x$1\" = \"xprecustomization\" ]; then",
"  export LC_ALL=\"en_US.UTF-8\"",
"  export ADMIN_LOGIN=\"lcmadm\"",
"  mkdir -p /root/.ssh",
"  /usr/bin/vmtoolsd --cmd \"info-get guestinfo.ovfEnv\" > /tmp/config.xml",
"  /usr/bin/cat /tmp/config.xml | /bin/xmlstarlet sel -N 'ovfenv=http://schemas.dmtf.org/ovf/environment/1' -t --match '//ovfenv:Property[@ovfenv:key='\\'cbam.publicSshKey\\'']' --value-of '@ovfenv:value' --nl > /root/.ssh/authorized_keys",
"  mkdir -p /home/\$ADMIN_LOGIN/.ssh",
"  export publicSshKey=\"$cbam.publicSshKey\"",
"  echo \$publicSshKey >> /home/\$ADMIN_LOGIN/.ssh/authorized_keys",
"  echo \$publicSshKey >> /home/root/.ssh/authorized_keys",
"  /usr/bin/cat /home/root/.ssh/authorized_keys2 >> /home/\$ADMIN_LOGIN/.ssh/authorized_keys2",
"  sed -i '/vnfc.lcm_action/c\         <Property oe:key=\"vnfc.lcm_action\" oe:value=\"heal\"/>' /tmp/config.xml",
"  sed -i '/vnfc.suffix/c <Property oe:key=\\\"vnfc.suffix\\\" oe:value=\\\"" + vnfc_suffix + "\\\"/>' /tmp/config.xml  2>>/root/error.log",
"  new_ovf_env=`cat /tmp/config.xml`",
"  /usr/bin/vmtoolsd --cmd \"info-set guestinfo.ovfEnv ${new_ovf_env}\"",
"  echo \"{\\\"group_index\\\":\\\"" + id + "\\\", \\\"current_group_count\\\":\\\"" + current_group_count + "\\\", \\\"total_pair_count\\\":\\\"" + total_pair_count + "\\\"}\" > /root/meta_data.json",
"  mv /tmp/config.xml /root/config.xml",
"fi",
"if [ \"x$1\" = \"xpostcustomization\" ]; then",
"  chmod -R 700 /root/.customization",
"fi",
"exit 0"
].join("\n")

  return heal_VMscript;
}

function recreateVMScript_olv(id, vnfc_suffix, current_group_count, total_pair_count){
    
    var recreate_VMScript=[
"#!/bin/sh",
"echo \"$1\" >> /root/params",
"chmod 600 /root/params",
"if [ \"x$1\" = \"xprecustomization\" ]; then",
"  export LC_ALL=\"en_US.UTF-8\"",
"  export ADMIN_LOGIN=\"lcmadm\"",
"  mkdir -p /root/.ssh",
"  /usr/bin/vmtoolsd --cmd \"info-get guestinfo.ovfEnv\" > /tmp/config.xml",
"  /usr/bin/cat /tmp/config.xml | /bin/xmlstarlet sel -N 'ovfenv=http://schemas.dmtf.org/ovf/environment/1' -t --match '//ovfenv:Property[@ovfenv:key='\\'cbam.publicSshKey\\'']' --value-of '@ovfenv:value' --nl > /root/.ssh/authorized_keys",
"  mkdir -p /home/\$ADMIN_LOGIN/.ssh",
"  export publicSshKey=\"$cbam.publicSshKey\"",
"  echo \$publicSshKey >> /home/\$ADMIN_LOGIN/.ssh/authorized_keys",
"  echo \$publicSshKey >> /home/root/.ssh/authorized_keys",
"  /usr/bin/cat /home/root/.ssh/authorized_keys2 >> /home/\$ADMIN_LOGIN/.ssh/authorized_keys2",
"  sed -i '/vnfc.lcm_action/c\         <Property oe:key=\"vnfc.lcm_action\" oe:value=\"recreate\"/>' /tmp/config.xml",
"  sed -i '/vnfc.suffix/c <Property oe:key=\\\"vnfc.suffix\\\" oe:value=\\\"" + vnfc_suffix + "\\\"/>' /tmp/config.xml  2>>/root/error.log",
"  new_ovf_env=`cat /tmp/config.xml`",
"  /usr/bin/vmtoolsd --cmd \"info-set guestinfo.ovfEnv ${new_ovf_env}\"",
"  echo \"{\\\"group_index\\\":\\\"" + id + "\\\", \\\"current_group_count\\\":\\\"" + current_group_count + "\\\", \\\"total_pair_count\\\":\\\"" + total_pair_count + "\\\"}\" > /root/meta_data.json",
"  mv /tmp/config.xml /root/config.xml",
"fi",
"if [ \"x$1\" = \"xpostcustomization\" ]; then",
"  chmod -R 700 /root/.customization",
"fi",
"exit 0"
].join("\n")

  return recreate_VMScript;
}

function getVMCustomization_olv(id, vnfc_suffix, current_group_count, total_pair_count, action){
    
    var VM_Customization=[
"#!/bin/sh",
"echo \"$1\" >> /root/params",
"chmod 600 /root/params",
"if [ \"x$1\" = \"xprecustomization\" ]; then",
"  export LC_ALL=\"en_US.UTF-8\"",
"  export ADMIN_LOGIN=\"lcmadm\"",
"  mkdir -p /root/.ssh",
"  /usr/bin/vmtoolsd --cmd \"info-get guestinfo.ovfEnv\" > /tmp/config.xml",
"  /usr/bin/cat /tmp/config.xml | /bin/xmlstarlet sel -N 'ovfenv=http://schemas.dmtf.org/ovf/environment/1' -t --match '//ovfenv:Property[@ovfenv:key='\\'cbam.publicSshKey\\'']' --value-of '@ovfenv:value' --nl > /root/.ssh/authorized_keys",
"  mkdir -p /home/\$ADMIN_LOGIN/.ssh",
"  export publicSshKey=\"$cbam.publicSshKey\"",
"  echo \$publicSshKey >> /home/\$ADMIN_LOGIN/.ssh/authorized_keys",
"  echo \$publicSshKey >> /home/root/.ssh/authorized_keys",
"  /usr/bin/cat /home/root/.ssh/authorized_keys2 >> /home/\$ADMIN_LOGIN/.ssh/authorized_keys2",
"  sed -i '/vnfc.suffix/c <Property oe:key=\\\"vnfc.suffix\\\" oe:value=\\\"" + vnfc_suffix + "\\\"/>' /tmp/config.xml  2>>/root/error.log",
"  sed -i '/vnfc.lcm_action/c <Property oe:key=\\\"vnfc.lcm_action\\\" oe:value=\\\"" + action + "\\\"/>' /tmp/config.xml  2>>/root/error.log",
"  echo \"{\\\"group_index\\\":\\\"" + id + "\\\", \\\"current_group_count\\\":\\\"" + current_group_count + "\\\", \\\"total_pair_count\\\":\\\"" + total_pair_count + "\\\"}\" > /root/meta_data.json",
"  mv /tmp/config.xml /root/config.xml",
"fi",
"if [ \"x$1\" = \"xpostcustomization\" ]; then",
"  chmod -R 700 /root/.customization",
"fi",
"exit 0"
].join("\n")

  return VM_Customization;
}

function getScaleoutCustomization_olv(id, vnfc_suffix, vnfc_matesuffix, ipAddress, current_group_count, total_pair_count) {
    var group_index = parseInt(id) + 61
    
    var  scriptScaleout=[
"#!/bin/sh", 
"echo \"$1\" >> /root/params",
"chmod 600 /root/params",
"if [ \"x$1\" = \"xprecustomization\" ]; then", 
"  export LC_ALL=\"en_US.UTF-8\"", 
"  export ADMIN_LOGIN=\"lcmadm\"",
"  mkdir -p /root/.ssh",
"  /usr/bin/vmtoolsd --cmd \"info-get guestinfo.ovfEnv\" > /tmp/config.xml", 
"  /usr/bin/cat /tmp/config.xml | /bin/xmlstarlet sel -N 'ovfenv=http://schemas.dmtf.org/ovf/environment/1' -t --match '//ovfenv:Property[@ovfenv:key='\\'cbam.publicSshKey\\'']' --value-of '@ovfenv:value' --nl > /root/.ssh/authorized_keys",
"  mkdir -p /home/\$ADMIN_LOGIN/.ssh",
"  export publicSshKey=\"$cbam.publicSshKey\"",
"  echo \$publicSshKey >> /home/\$ADMIN_LOGIN/.ssh/authorized_keys",
"  echo \$publicSshKey >> /home/root/.ssh/authorized_keys",
"  /usr/bin/cat /home/root/.ssh/authorized_keys2 >> /home/\$ADMIN_LOGIN/.ssh/authorized_keys2",
"  sed -i '/vnfc.suffix/c <Property oe:key=\\\"vnfc.suffix\\\" oe:value=\\\"" + vnfc_suffix + "\\\"/>' /tmp/config.xml  2>>/root/error.log",
"  sed -i '/vnfc.group_index/c <Property oe:key=\\\"vnfc.group_index\\\" oe:value=\\\"" + group_index + "\\\"/>' /tmp/config.xml 2>>/root/error.log",
"  sed -i '/<\\/PropertySection>/i <Property oe:key=\\\"vnfc.matesuffix\\\" oe:value=\\\"" + vnfc_matesuffix + "\\\"/>' /tmp/config.xml 2>>/root/error.log",
"  sed -i '/<\\/PropertySection>/i <Property oe:key=\\\"vnf.growth_svcinfo\\\" oe:value=\\\"" + ipAddress + "\\\"/>' /tmp/config.xml 2>>/root/error.log",
"  sed -i '/vnfc.lcm_action/c <Property oe:key=\\\"vnfc.lcm_action\\\" oe:value=\\\"scale-out\\\"/>' /tmp/config.xml 2>>/root/error.log",
"  new_ovf_env=`cat /tmp/config.xml`",
"  /usr/bin/vmtoolsd --cmd \"info-set guestinfo.ovfEnv ${new_ovf_env}\"",
"  echo \"{\\\"group_index\\\":\\\"" + id + "\\\", \\\"current_group_count\\\":\\\"" + current_group_count + "\\\", \\\"total_pair_count\\\":\\\"" + total_pair_count + "\\\"}\" > /root/meta_data.json",
"  mv /tmp/config.xml /root/config.xml",
"fi", 
"if [ \"x$1\" = \"xpostcustomization\" ]; then",
"  chmod -R 700 /root/.customization",
"fi",
"exit 0"
].join("\n")

    return scriptScaleout;
}

function isNumeric(n) {
  return !isNaN(parseFloat(n)) && isFinite(n)
}

function processResources(cbam, zones, templateName, media, operationType, vnfcToHeal) {
   var temp_prefix = cbam.extensions.system_prefix + cbam.extensions.cloud_name_delimiter
   var total_pair_count = get_total_pair_count(cbam)
   var total_pair_count = get_total_pair_count_olv(cbam)
   var disasterRecovery = ""
   if ((typeof($.operation_params) !== "undefined") &&
      (typeof($.operation_params.additionalParams) !== "undefined") &&
      (typeof($.operation_params.additionalParams.disasterRecovery) !== "undefined")) {
      disasterRecovery = $.operation_params.additionalParams.disasterRecovery
   }

   var zoneKeys = Object.keys(zones);
   if (zoneKeys.length < 1) {
       throw "There ain't enough zones available for this operation! Check instantiation parameters!";
   }

   for (var aspectGroupID in cbam.resources) {
      var aspectGroup = cbam.resources[aspectGroupID];
      if (aspectGroupID === "static"){
         for (var id in aspectGroup) {
            if (isNaN(id)) {
               if("disks" in aspectGroup[id][0].server){
                        aspectGroup[id][0].server.disks.forEach(function(disk){
                        disk["busType"] = "6";
                        disk["busSubType"] = "VirtualSCSI";
                    });
               }
               if("disks" in aspectGroup[id][1].server){
                        aspectGroup[id][1].server.disks.forEach(function(disk){
                        disk["busType"] = "6";
                        disk["busSubType"] = "VirtualSCSI";
                    });
               }
               aspectGroup[id][0].server.imageId = cbam.extensions[id][0][0].name;
               aspectGroup[id][0].server.templateName = templateName;
               aspectGroup[id][0].server.media = media;
               aspectGroup[id][0].server.name = temp_prefix + cbam.extensions[id][0][0].name
               aspectGroup[id][0].server.azId = zones["zoneA"].zoneId;
               aspectGroup[id][0].server.additionalAction = "poweredon"
               if (cbam.extensions[id][0][0].vmMetadata_info[0].metadata[0].type !== "null") {
                   aspectGroup[id][0].server.vmMetadata = cbam.extensions[id][0][0].vmMetadata_info[0].metadata.slice(0);
               }
               aspectGroup[id][0].server.configuration = { }
               aspectGroup[id][0].server.configuration.publicSshKey = cbam.publicSshKey;
               if (operationType === "heal") {
                  var vnfcToHealListArr = vnfcToHeal.split(",");
                  for (var vnfcIdx = 0; (vnfcIdx < vnfcToHealListArr.length); vnfcIdx++) {
                     if (aspectGroup[id][0].server.imageId === vnfcToHealListArr[vnfcIdx]) {
                        aspectGroup[id][0].server.script = healOamScript(aspectGroup[id][0].server.imageId);
                     }
                  }
               } else if (disasterRecovery == "yes") {
                  aspectGroup[id][0].server.script = recreateOamScript(aspectGroup[id][0].server.imageId);
               } else {
                  aspectGroup[id][0].server.script = getOamCustomization(aspectGroup[id][0].server.imageId);
               }

               aspectGroup[id][0].server.nics = { "nic_0": { "expectIp" : true }, "nic_1": { "expectIp" : true } }

               aspectGroup[id][1].server.imageId = cbam.extensions[id][0][1].name;
               aspectGroup[id][1].server.templateName = templateName;
               aspectGroup[id][1].server.media = media;
               aspectGroup[id][1].server.name = temp_prefix + cbam.extensions[id][0][1].name
               aspectGroup[id][1].server.azId = zones["zoneB"].zoneId;
               aspectGroup[id][1].server.additionalAction = "poweredon"
               if (cbam.extensions[id][0][1].vmMetadata_info[0].metadata[0].type !== "null") {
                  aspectGroup[id][1].server.vmMetadata = cbam.extensions[id][0][1].vmMetadata_info[0].metadata.slice(0);
               }
               aspectGroup[id][1].server.configuration = { }
               aspectGroup[id][1].server.configuration.publicSshKey = cbam.publicSshKey;
               if (operationType === "heal") {
                  var vnfcToHealListArr = vnfcToHeal.split(",");
                  for (var vnfcIdx = 0; (vnfcIdx < vnfcToHealListArr.length); vnfcIdx++) {
                     if (aspectGroup[id][1].server.imageId === vnfcToHealListArr[vnfcIdx]) {
                        aspectGroup[id][1].server.script = healOamScript(aspectGroup[id][1].server.imageId);
                     }
                  }
               } else if (disasterRecovery == "yes") {
                  aspectGroup[id][1].server.script = recreateOamScript(aspectGroup[id][1].server.imageId);
               } else {
                  aspectGroup[id][1].server.script = getOamCustomization(aspectGroup[id][1].server.imageId);
               }

               aspectGroup[id][1].server.nics = { "nic_0": { "expectIp" : true }, "nic_1": { "expectIp" : true } }
            }
         }
      } else {
         current_group_count = get_current_group_count(cbam, aspectGroupID)
         current_group_count = get_current_group_count_olv(cbam, aspectGroupID)
         for (var step in aspectGroup) {
            if(isNumeric(step)) {
                var rsc_group = aspectGroupID.substring(0, aspectGroupID.indexOf("_Aspect"));

                if (! (step in cbam.extensions[rsc_group])) {
                    throw rsc_group + " didn't define No." + step + " VM."
                }

                ext_vm_a=cbam.extensions[rsc_group][step][0];
                ext_vm_b=cbam.extensions[rsc_group][step][1];

                var servicename = JSON.stringify(ext_vm_a.vnic_info);
                temp_servicename = "";
                for (var svcname of servicenames) {
                    if (servicename.indexOf("servicetype=" + svcname) !== -1) {
                        temp_servicename = svcname;
                        break;
                    }
                }

                if("disks" in aspectGroup[step][0].server){
                        aspectGroup[step][0].server.disks.forEach(function(disk){
                        disk["busType"] = "6";
                        disk["busSubType"] = "VirtualSCSI";
                    });
                }
                if("disks" in aspectGroup[step][1].server){
                        aspectGroup[step][1].server.disks.forEach(function(disk){
                        disk["busType"] = "6";
                        disk["busSubType"] = "VirtualSCSI";
                    });
                }

                aspectGroup[step][0].server.imageId = cbam.extensions[rsc_group][0][0].name;
                aspectGroup[step][1].server.imageId = cbam.extensions[rsc_group][0][1].name;

                aspectGroup[step][0].server.imageId = cbam.extensions[rsc_group][0][0].name;
                aspectGroup[step][1].server.imageId = cbam.extensions[rsc_group][0][1].name;
                aspectGroup[step][0].server.name = temp_prefix + ext_vm_a.name;
                aspectGroup[step][1].server.name = temp_prefix + ext_vm_b.name;
                if (ext_vm_a.vmMetadata_info[0].metadata[0].type !== "null") {
                   aspectGroup[step][0].server.vmMetadata = ext_vm_a.vmMetadata_info[0].metadata.slice(0);
                }
                if (ext_vm_b.vmMetadata_info[0].metadata[0].type !== "null") {
                   aspectGroup[step][1].server.vmMetadata = ext_vm_b.vmMetadata_info[0].metadata.slice(0);
                }
                aspectGroup[step][0].server.media = media;
                aspectGroup[step][0].server.additionalAction = "poweredon"
                aspectGroup[step][0].server.configuration = { }
                aspectGroup[step][0].server.configuration.publicSshKey = cbam.publicSshKey;

                if ((temp_servicename === "feph" || temp_servicename === "pfed") && zoneKeys.length > 2 && cbam.extensions.template_fw_name !== "") {
                   aspectGroup[step][0].server.azId = zones["zoneFwA"].zoneId;
                   aspectGroup[step][1].server.azId = zones["zoneFwB"].zoneId;
                   aspectGroup[step][0].server.templateName = cbam.extensions.template_fw_name;
                   aspectGroup[step][1].server.templateName = cbam.extensions.template_fw_name;
                } else {
                   aspectGroup[step][0].server.azId = zones["zoneA"].zoneId;
                   aspectGroup[step][1].server.azId = zones["zoneB"].zoneId;
                   aspectGroup[step][0].server.templateName = templateName;
                   aspectGroup[step][1].server.templateName = templateName;
                }

                if (operationType === "heal") {
                   var vnfcToHealListArr = vnfcToHeal.split(",");
                   for (var vnfcIdx = 0; (vnfcIdx < vnfcToHealListArr.length); vnfcIdx++) {
                      if (ext_vm_a.name === vnfcToHealListArr[vnfcIdx]) {
                         aspectGroup[step][0].server.script = healVMScript(step, ext_vm_a["name"], current_group_count, total_pair_count);
                         // R8.0m, R18.2m, and R18.5m only
                         aspectGroup[step][0].server.script = healVMScript_olv(step, ext_vm_a["name"], current_group_count, total_pair_count);
                      }
                   }
                } else if (disasterRecovery == "yes") {
                   aspectGroup[step][0].server.script = recreateVMScript(step, ext_vm_a["name"], current_group_count, total_pair_count);
                   // R8.0m, R18.2m, and R18.5m only
                   aspectGroup[step][0].server.script = recreateVMScript_olv(step, ext_vm_a["name"], current_group_count, total_pair_count);
                } else if (typeof($.operation_params) !== "undefined" && ("type" in $.operation_params) && (($.operation_params.type == "in") || $.operation_params.type == "out")) {

                   service_ips=""
                   if (typeof(ext_vm_a["ipv4_service_ip"]) !== "undefined" && ext_vm_a["ipv4_service_ip"] !== "") {
                       service_ips=service_ips + "IPv4," + ext_vm_a["ipv4_service_ip"]
                   }
                   if (typeof(ext_vm_a["ipv6_service_ip"]) !== "undefined" && ext_vm_a["ipv6_service_ip"] !== "") {
                       if (service_ips !== "") {
                           service_ips=service_ips + ";"
                       }
                       service_ips=service_ips + "IPv6," + ext_vm_a["ipv6_service_ip"]
                   }
                   
                   aspectGroup[step][0].server.script = getScaleoutCustomization(step, ext_vm_a["name"], ext_vm_b["name"], service_ips, current_group_count, total_pair_count);
                   // R8.0m, R18.2m, and R18.5m only
                   aspectGroup[step][0].server.script = getScaleoutCustomization_olv(step, ext_vm_a["name"], ext_vm_b["name"], service_ips, current_group_count, total_pair_count);
                } else {
                   aspectGroup[step][0].server.script = getVMCustomization(step, ext_vm_a["name"], current_group_count, total_pair_count);
                   // R8.0m, R18.2m, and R18.5m only
                   aspectGroup[step][0].server.script = getVMCustomization_olv(step, ext_vm_a["name"], current_group_count, total_pair_count, "install");
                }

                aspectGroup[step][0].server.nics = { "nic_0": { "expectIp" : true } }

                aspectGroup[step][1].server.media = media;
                aspectGroup[step][1].server.additionalAction = "poweredon"
                aspectGroup[step][1].server.configuration = { }
                aspectGroup[step][1].server.configuration.publicSshKey = cbam.publicSshKey;
                if (operationType === "heal") {
                   var vnfcToHealListArr = vnfcToHeal.split(",");
                   for (var vnfcIdx = 0; (vnfcIdx < vnfcToHealListArr.length); vnfcIdx++) {
                      if (ext_vm_b.name === vnfcToHealListArr[vnfcIdx]) {
                         aspectGroup[step][1].server.script = healVMScript(step, ext_vm_b["name"], current_group_count, total_pair_count);
                         // R8.0m, R18.2m, and R18.5m only
                         aspectGroup[step][1].server.script = healVMScript_olv(step, ext_vm_b["name"], current_group_count, total_pair_count);
                      }
                   }
                } else if (disasterRecovery == "yes") {
                   aspectGroup[step][1].server.script = recreateVMScript(step, ext_vm_b["name"], current_group_count, total_pair_count);
                   // R8.0m, R18.2m, and R18.5m only
                   aspectGroup[step][1].server.script = recreateVMScript_olv(step, ext_vm_b["name"], current_group_count, total_pair_count);
                } else if ((typeof(ext_vm_a["ipv4_service_ip"]) !== "undefined") && typeof($.operation_params) !== "undefined" && ("type" in $.operation_params) && (($.operation_params.type == "in") || $.operation_params.type == "out")) {
                   service_ips=""
                   if (typeof(ext_vm_b["ipv4_service_ip"]) !== "undefined" && ext_vm_b["ipv4_service_ip"] !== "") {
                       service_ips=service_ips + "IPv4," + ext_vm_b["ipv4_service_ip"]
                   }
                   if (typeof(ext_vm_b["ipv6_service_ip"]) !== "undefined" && ext_vm_b["ipv6_service_ip"] !== "") {
                       if (service_ips !== "") {
                           service_ips=service_ips + ";"
                       }
                       service_ips=service_ips + "IPv6," + ext_vm_b["ipv6_service_ip"]
                   }
                   aspectGroup[step][1].server.script = getScaleoutCustomization(step, ext_vm_b["name"], ext_vm_a["name"], service_ips, current_group_count, total_pair_count);
                   // R8.0m, R18.2m, and R18.5m only
                   aspectGroup[step][1].server.script = getScaleoutCustomization_olv(step, ext_vm_b["name"], ext_vm_a["name"], service_ips, current_group_count, total_pair_count);
                } else {
                   aspectGroup[step][1].server.script = getVMCustomization(step, ext_vm_b["name"], current_group_count, total_pair_count);
                   // R8.0m, R18.2m, and R18.5m only
                   aspectGroup[step][1].server.script = getVMCustomization_olv(step, ext_vm_b["name"], current_group_count, total_pair_count, "install");
                }

                aspectGroup[step][1].server.nics = { "nic_0": { "expectIp" : true } }
            }
         }
      }
   }
   return cbam.resources
}

function get_current_group_count_olv(cbam, aspectGroupID) {
    var count = 0
    var aspectGroup = cbam.resources[aspectGroupID];
    
    if (aspectGroupID === "static"){
        for (var id in aspectGroup) {
            if (!isNaN(id)) {
                continue
            }
            
            count = count + 1
        }
    } else {
        for (var step in aspectGroup) {
            if (!isNumeric(step)) {
                continue
            }

            count = count + 1
        }
    }
    
    return count;
}

function get_total_pair_count_olv(cbam) {
    // Provisioning the other vms affinity rules
    var count = 0
    for (var aspectGroupID in cbam.resources) {
        count = count + get_current_group_count_olv(cbam, aspectGroupID)
    }

    return count;
}

function processaffinityRules(cbam) {

    var keyname="ruleName";
    var BaseName="";
    var affinityRulesArr = [];

    // Provisioning oam affinity rule
    var isAnti = cbam.extensions["oam"].rules_info[0].rules[0].isAnti;
    var oamAffinityRulesObj = {"isAnti":isAnti, "cbamIds":["static.oam.0.server","static.oam.1.server"]};
    oamAffinityRulesObj[keyname]= "oamRule";
    affinityRulesArr.push(oamAffinityRulesObj);

    // Provisioning the other vms affinity rules
    for (var aspectGroupID in cbam.resources) {
        if (aspectGroupID === "static") {
            continue
        }

        var aspectGroup = cbam.resources[aspectGroupID];
        var rsc_group = aspectGroupID.substring(0, aspectGroupID.indexOf("_Aspect"));
        for (var step in aspectGroup) {
            if (!isNumeric(step)) {
                continue
            }

            var ruleName = BaseName.concat(rsc_group,step,"Rule");
            var vm_a_Name = BaseName.concat(aspectGroupID,".",step,".0.server");
            var vm_b_Name = BaseName.concat(aspectGroupID,".",step,".1.server");
            isAnti = cbam.extensions[rsc_group].rules_info[0].rules[0].isAnti;
            var tmpAffinityRulesObj = {"isAnti":isAnti, "cbamIds":[vm_a_Name,vm_b_Name]};
            tmpAffinityRulesObj[keyname]= ruleName;
            affinityRulesArr.push(tmpAffinityRulesObj);
        }
    }

   cbam.affinityRules = affinityRulesArr.slice();
   return cbam;
}

function get_current_group_count(cbam, aspectGroupID) {
    var count = 0
    var aspectGroup = cbam.resources[aspectGroupID];
    
    if (aspectGroupID === "static"){
        for (var id in aspectGroup) {
            if (!isNaN(id)) {
                continue
            }
            
            count = count + 1
        }
    } else {
        for (var step in aspectGroup) {
            if (!isNumeric(step)) {
                continue
            }

            count = count + 1
        }
    }
    
    return count;
}

function get_total_pair_count(cbam) {
    // Provisioning the other vms affinity rules
    var count = 0
    for (var aspectGroupID in cbam.resources) {
        count = count + get_current_group_count(cbam, aspectGroupID)
    }

    return count;
}

function processConfiguration(cbam) {
   cbam.configuration = { }
   cbam.configuration.timing = {
      "vapp": {
          "create" : {
              "timeout": 1800000,
              "period": 5000
          }
      },
      "network": {
         "validIp": {
            "timeout": 1800000,
            "period": 5000
         },
         "reconfiguration": {
            "timeout": 1800000,
            "period": 5000
         },
         "ipReconfiguration": {
            "timeout": 1800000,
            "period": 5000
         }
      }
   };
   return cbam.configuration
}

function prepare(stack_params, zones, operationType, vnfcToHeal){
  stack_params.cbam.resources = processResources(stack_params.cbam, zones, stack_params.cbam.extensions.template_name, stack_params.cbam.extensions.media, operationType, vnfcToHeal);
  stack_params.cbam.configuration = processConfiguration(stack_params.cbam);
  stack_params.cbam.templateName = stack_params.cbam.extensions.template_name;
  stack_params.cbam = processaffinityRules(stack_params.cbam);
  return stack_params;
}

var zones = $.nfv_model.zones;
var zone_keys = Object.keys(zones);
if (zone_keys.length < 1) {
    if ($.nfv_model.hasOwnProperty("zoneInfo")) {
        var zoneInfo = $.nfv_model["zoneInfo"];
        for (var i = 0; i < zoneInfo.length; i++) {
           zones[zoneInfo[i]["id"]] = {"zoneId": zoneInfo[i]["zoneId"]};
        }
    }
}

return prepare($.stack_params, zones, $.operationType, $.vnfcToHeal);

