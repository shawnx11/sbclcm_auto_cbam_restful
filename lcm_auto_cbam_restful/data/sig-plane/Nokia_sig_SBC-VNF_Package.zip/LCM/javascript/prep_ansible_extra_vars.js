function isJsonString(str) {
  try {
    JSON.parse(str);
  } catch (e) {
    return false;
  }
  return true;
}

function isNumeric(n) {
   return !isNaN(parseFloat(n)) && isFinite(n)
}

function ValidateIPv6(ipaddress)
{
   //Remove [] if exist just for validting IP locally
   var ipv6ip = ipaddress.replace( /(^.*\[|\].*$)/g, '' );
   if (/^((?=.*::)(?!.*::.+::)(::)?([\dA-F]{1,4}:(:|\b)|){5}|([\dA-F]{1,4}:){6})((([\dA-F]{1,4}((?!\3)::|:\b|$))|(?!\2\3)){2}|(((2[0-4]|1\d|[1-9])?\d|25[0-5])\.?\b){4})$/i.test(ipv6ip))
   {
      return 0;
   }
   return 1;
}

function ValidateIP4(ipaddress)
{
   if (/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(ipaddress))
   {
      return 0;
   }
   return 1;
}
//Set to either "OPENSTACK" or "VMWARE"
var providerType = "OPENSTACK";
if (typeof($.provider_type) !== "undefined") {
   providerType = $.provider_type.toUpperCase();
}
else if ((typeof($.nfv_model) !== "undefined") && (typeof($.nfv_model.vim) !== "undefined")) {
    if ("providerType" in $.nfv_model.vim) {
       providerType = $.nfv_model.vim.providerType.toUpperCase();
    }
}
if (providerType == "VMWARE") {
    if (typeof($.stack_params) !== "undefined") {
       stack_id_str = $.stack_params.cbam.extensions.vnf_name;
       mi_ip_list = $.stack_params.cbam.extensions.oam_ext_ips;
    } else if (typeof($.cbam_extensions) !== "undefined") {
       stack_id_str = $.cbam_extensions.vnf_name;
       mi_ip_list = $.cbam_extensions.oam_ext_ips;
    } else {
        throw "Unable to get cbam extensions...!";
    }
}
else {
    mi_ip_list = get_oam_ips_list_str($.resource_model);
    stack_id_str = $.resource_model.parameters["OS::project_id"] + "@" + $.resource_model.parameters["OS::stack_id"];
}

// Setup extra-vars.
var extraVars = {};

extraVars["MI_IP_list"] = mi_ip_list;
extraVars["MI_IP_string"] = stack_id_str;
extraVars["MI_user_name"] = "lcmadm";
extraVars["op_type"] = $.op_type
extraVars["providerType"] = providerType;

// Set application type
extraVars["application_name"] = "";
var ext_install_config = "";
if ((typeof($.resource_model) !== "undefined") &&
    (typeof($.resource_model.parameters) !== "undefined") &&
    (typeof($.resource_model.parameters.cbam) !== "undefined") ) {
    var cbam_str = $.resource_model.parameters.cbam;
    var cbam_dict = {};
    if (isJsonString(cbam_str)) {
        cbam_dict = JSON.parse(cbam_str);
    }
    if ((typeof(cbam_dict.extensions) !== "undefined") &&
        (typeof(cbam_dict.extensions.install_config) !== "undefined")) {
        ext_install_config = cbam_dict.extensions.install_config.trim();
    }
}
else if ((typeof($.cbam_extensions) !== "undefined") &&
      (typeof($.cbam_extensions.install_config) !== "undefined")) {
    ext_install_config = $.cbam_extensions.install_config.trim();
}
if (ext_install_config != "") {
    var install_config_dict = {};
    if (ext_install_config.startsWith("{")) {
        install_config_dict = JSON.parse(ext_install_config);
    } else {
        install_config_dict = JSON.parse("{" + ext_install_config + "}");
    }
    if (install_config_dict.hasOwnProperty("application_name")) {
        extraVars["application_name"] = install_config_dict["application_name"];
    }
}

if ($.op_type === "heal") {
    if (providerType == "VMWARE") {
       extraVars["marker_file_delay"] = $.monitor_delay;
       extraVars["marker_file_retries"] = $.monitor_retries;
       extraVars["heal_server_count"] = $.heal_server_count;
       return extraVars;
    } else {
       // providerType is OPENSTACK
       extraVars["marker_file_delay"] = $.monitor_delay;
       extraVars["marker_file_retries"] = $.monitor_retries;
       extraVars["heal_server_count"] = $.heal_server_count;
   }
} else if ($.op_type === "mi_ips") {
    return extraVars;
} else if ((($.op_type === "backout") || ($.op_type === "rollback")) && (providerType == "VMWARE")) {
    return extraVars;
} else if ($.op_type === "recreate") {
    return extraVars;
} else if ($.op_type === "update") {
    if (providerType == "VMWARE") {
      extraVars["update_imagename"] = $.update_imagename;
      extraVars["update_toload"] = $.update_toload;
      extraVars["update_fromload"] = $.update_fromload;
      extraVars["update_deft_key"] = $.update_deftkey;
      extraVars["update_deft_url"] = $.update_defturl;
      extraVars["lcp_monolithic_zip_url"] = $.lcp_monolithic_zip_url;
      extraVars["lcp_monolithic_zip"] = $.lcp_monolithic_zip;
    } else {
      // providerType is OPENSTACK
      extraVars["update_imagename"] = $.update_imagename;
      extraVars["update_toload"] = $.update_toload;
      extraVars["update_deftkey"] = $.update_deftkey;
      extraVars["update_defturl"] = $.update_defturl;
      extraVars["MI_A_IP_address"] = $.MI_A_IP_address;
      extraVars["MI_B_IP_address"] = $.MI_B_IP_address;
    }
}
else if ($.op_type === "update_archive") {
    // The Update_Archive operation - make an archive to use for update-recreate (SU).
    extraVars["update_toload"] = $.update_toload;
    extraVars["update_deftkey"] = $.update_deftkey;
    extraVars["update_defturl"] = $.update_defturl;

    extraVars["update_IP_address"] = $.update_server_IP;
    extraVars["update_remote_dir"] = $.update_server_dir;
    extraVars["update_user_name"]  = $.update_server_user_name;

    extraVars["update_srv_creds"] = "";
    if (typeof($.operation_params) !== "undefined") {
      if ("upgradeServerCredentials" in $.operation_params.additionalParams) {
        extraVars["update_srv_creds"] = ($.operation_params.additionalParams.upgradeServerCredentials).trim();
      }
    }
}
else if ($.op_type === "ip_manage") {
    // ansible name     = mistral name
    extraVars["action"] = $.ipOpType;
    extraVars["svc_type"] = $.ipSvcType;
    extraVars["pool_id"] = $.ipPoolId;
    extraVars["subnet"] = $.ipSubnet;
    extraVars["ip_address"] = $.ipIpAddress;
    extraVars["porttype"] = $.ipPortType;
    extraVars["membernum"] = $.ipMemberNum;
    extraVars["ni_type"] = $.ipNiType;
}
else if ($.op_type === "add_subnet") {
    // ansible name     = mistral name
    extraVars["action"] = "add_subnet";
    extraVars["subnet_name"] = $.subSubName;
    extraVars["subnet_base"] = $.subSubBase;
    extraVars["netmask"] = $.subNetmask;
    extraVars["subnet_number"] = $.subSubNum;
    extraVars["eipm_mode"] = $.subEipmMode;
    extraVars["subnet_gateway_ip"] = $.subGatewayIpAddress;
    extraVars["interface_name"] = $.subInterfaceName;
    extraVars["customer_vlan"] = $.subCustVlan;
    extraVars["detect_multiplier"] = $.subDetectMult;
    extraVars["desired_min_rx_int"] = $.subDesiredMinRxInt;
    extraVars["reqd_min_tx_int"] = $.subReqdMinTxInt;
    extraVars["mtu"] = $.subMtu;
}
else if ($.op_type === "del_subnet") {
    // ansible name     = mistral name
    extraVars["action"] = "del_subnet";
    extraVars["subnet_base"] = $.subSubBase;
    extraVars["subnet_number"] = $.subSubNum;
}
else if ($.op_type === "backup") {
    extraVars["backup_IP_address1"] = $.backup_server_IP1;
    extraVars["backup_user_name1"]  = $.backup_server_user_name1;
    extraVars["backup_remote_dir1"] = $.backup_server_dir1;
    extraVars["backup_IP_address2"] = $.backup_server_IP2;
    extraVars["backup_user_name2"]  = $.backup_server_user_name2;
    extraVars["backup_remote_dir2"] = $.backup_server_dir2;
    extraVars["bkup_srv_creds1"] = "";
    extraVars["bkup_srv_creds2"] = "";
    if (typeof($.operation_params) !== "undefined") {
        default_creds1_str = "<First Backup Server Security Certificate>";
        default_creds2_str = "<Second Backup Server Security Certificate>";
        if ("backup_server_credentials1" in $.operation_params.additionalParams) {
           if ($.operation_params.additionalParams.backup_server_credentials1 !== default_creds1_str) {
              extraVars["bkup_srv_creds1"] = ($.operation_params.additionalParams.backup_server_credentials1).trim();
           }
        }
        if ("backup_server_credentials2" in $.operation_params.additionalParams) {
           if ($.operation_params.additionalParams.backup_server_credentials2 !== default_creds2_str) {
              extraVars["bkup_srv_creds2"] = ($.operation_params.additionalParams.backup_server_credentials2).trim();
           }
        }
    }
}
else if ($.op_type === "db_restore" || $.op_type === "restore") {
    var backupServerIP = $.backup_server_IP;
    var retval = ValidateIPv6(backupServerIP);
    if (retval === 0) {
       var ret1 = backupServerIP.indexOf("[");
       var ret2 = backupServerIP.indexOf("]");
       if (ret1 !== -1 && ret2 !== -1) {
          extraVars["backup_IP_address"] = backupServerIP;
       }
       else if (ret1 === -1 && ret2 === -1) {
          extraVars["backup_IP_address"] = "[" + backupServerIP + "]";
       }
       else {
          throw "IP6 address is badly formated...Please check!";
       }
    }
    else {
       var ret3 = ValidateIP4(backupServerIP);
       if (ret3 === 0) {
          extraVars["backup_IP_address"] = backupServerIP;
       }
       else {
          throw "IP4 address is badly formated...Please check!";
       }
    }
    extraVars["backup_user_name"]  = $.backup_server_user_name;
    extraVars["backup_remote_dir_file"] = $.backup_server_dir_file;
    if (typeof($.operation_params) !== "undefined") {
        if ("restore_media_plane" in $.operation_params.additionalParams) {
            extraVars["restore_media"] = $.operation_params.additionalParams.restore_media_plane;
        }
    }
}
else if ($.op_type === "sgsiwf_provision_update") {
    extraVars["health_check_mode"] = $.health_check_mode;
    extraVars["update_conf_url"] = $.update_conf_url;
}
else if ($.op_type === "sgsiwf_provision_smsc") {
    extraVars["provision_mode"] = $.provision_mode;
    extraVars["update_conf_url"] = $.update_conf_url;
}
else if ($.op_type === "sgsiwf_provision_mme") {
    extraVars["mme_index"] = $.mme_index;
    extraVars["provision_mode"] = $.provision_mode;
    extraVars["update_conf_url"] = $.update_conf_url;
    extraVars["reset_flag"] = $.reset_flag;
    extraVars["reset_delay"] = $.reset_delay;
}
else if ($.op_type === "sgsiwf_rebalance") {
    extraVars["mme_index"] = $.mme_index;
    extraVars["delay_time"] = $.delay_time;
}
else if ($.op_type === "sgsiwf_provision_roaming_plmn") {
    extraVars["update_conf_url"] = $.update_conf_url;
}
else if ($.op_type === "auto_scale") {
    extraVars["aspectList"] = $.aspect_list;
}
else if (typeof($.operation_params) !== "undefined") {
    if ((providerType == "VMWARE") && ("type" in $.operation_params) && (($.operation_params.type == "in") || $.operation_params.type == "out")) {
        var scale_info = {};
        var aspect_grp = $.operation_params.aspectId;   
        var resources = $.stack_params.cbam.resources;
        var extensions = $.stack_params.cbam.extensions;
        var vm_group_id = "";
        
        vm_group_tag = aspect_grp.substring(0, aspect_grp.indexOf("_Aspect"));
        scale_info[vm_group_tag] = {};
        scale_info[vm_group_tag]["numberOfSteps"] = $.operation_params.numberOfSteps;
        
        lowerIndex = 0
        var vm_count = parseInt(resources[aspect_grp]["count"]);

        if ($.operation_params.type == "in") {
            extraVars["op_type"] = "scale-in";
            extraVars["graceful_delay_timer"] = extensions.scale_in_waiting_period;

            if (vm_count === 0) {
                throw "At least one pair of SC VMs should be kept!"
            }
            
            var degrow_sc = ""
            for (var i = 0; (i < $.operation_params.numberOfSteps); i++) {
                scalingStepId = i + parseInt(vm_count)
                scale_info[vm_group_tag][scalingStepId] = scalingStepId;
                var tmpsc= extensions[vm_group_tag][scalingStepId][0]["name"] + "," + extensions[vm_group_tag][scalingStepId][1]["name"]
                if (degrow_sc === "") {
                    degrow_sc = tmpsc
                } else {
                    degrow_sc = degrow_sc + "," + tmpsc
                }
            }

            extraVars["degrow_sc"] = degrow_sc;
            if (typeof(extensions[vm_group_tag]["group_id"]) !== "undefined") {
                vm_group_id = extensions[vm_group_tag]["group_id"]
            }
        }
        else if ($.operation_params.type == "out") {
            extraVars["op_type"] = "scale-out";
            
            var lowerIndex = parseInt(vm_count) - $.operation_params.numberOfSteps
            for (var i = lowerIndex; (i < vm_count); i++) {
                scale_info[vm_group_tag][i] = i;
            }
        }

        extraVars["scale_info"] = {};
        extraVars["scale_info"] = scale_info;
        extraVars["vm_group_tag"] = vm_group_tag; 
        extraVars["vm_group_id"] = vm_group_id;
        extraVars["vm_pair_count"] = vm_count;
    } else if (("type" in $.operation_params) && (($.operation_params.type == "in") || $.operation_params.type == "out")) {
        var scale_list = [];
        var scale_info = {};
        var vm_pair_count = "";
        var vm_group_tag = "";
        var vm_group_id = "";
        var aspect_grp = $.operation_params.aspectId;   
        var resources = $.stack_params.cbam.resources;  
        var host_vars = $.ansible_inventory["_meta"]["hostvars"];

        if ($.operation_params.type == "in") {
            scale_list = $.ansible_inventory.retiring;
            extraVars["op_type"] = "scale-in";
            extraVars["graceful_delay_timer"] = $.stack_params.cbam.extensions.scale_in_waiting_period;

        }
        else if ($.operation_params.type == "out") {
            scale_list = $.ansible_inventory.new;
            extraVars["op_type"] = "scale-out";
        }

        vm_group_tag = aspect_grp.substring(0, aspect_grp.indexOf("_Aspect"));
        scale_info[vm_group_tag] = {};
        scale_info[vm_group_tag]["numberOfSteps"] = $.operation_params.numberOfSteps;
        for(var i = 0; (i < scale_list.length); i++) {
            var grp_uuid = scale_list[i];
            if (grp_uuid in host_vars) {
                openstack_dict = host_vars[grp_uuid]["openstack"];
                if (vm_group_id === "") {
                    vm_group_id = openstack_dict["metadata"]["group_id"];
                    vm_group_tag = openstack_dict["metadata"]["vnf_role"];
                }
                group_index = openstack_dict["metadata"]["group_index"];
                if (!(group_index in scale_info[vm_group_tag])) {
                    scale_info[vm_group_tag][group_index] = {};
                    scale_info[vm_group_tag][group_index]["name"] = [];
                }
                scale_info[vm_group_tag][group_index]["name"].push(openstack_dict["name"]);
            }
        }
        extraVars["scale_info"] = {};
        extraVars["scale_info"] = scale_info;

        for (var rsc in resources) {
            if (resources[rsc].count === 0) {
                continue;
            }
            for (var item in resources[rsc] ) {
               id = parseInt(item);
               if (isNaN(id)) {
                   continue;
               }
               vduId_vma = vm_group_tag + "_a";
               if (resources[rsc][item]["NOKIA-LCP-VMA"].vduId === vduId_vma) {
                   vm_pair_count = resources[rsc].count;
                   break;
               }
            }
            if (vm_pair_count != "") {
                break;
            }
        }
        extraVars["vm_group_id"] = vm_group_id;  
        extraVars["vm_group_tag"] = vm_group_tag; 
        extraVars["vm_pair_count"] = vm_pair_count;
    }
    else if (typeof($.operation_params.additionalParams) !== "undefined") {
        // There are additional parameters to check.
        if (("disasterRecovery" in $.operation_params.additionalParams) && (providerType == "VMWARE")) {
            var dr_state = $.operation_params.additionalParams.disasterRecovery.trim().toLowerCase()
            if (dr_state === "") {
                dr_state = "no"
            }
            if (dr_state !== "yes" && dr_state !== "no") {
                throw "disasterRecovery only can be 'yes' or 'no'!"
            }
            if (dr_state === "no") {
                extraVars["FIELD_INSTALL"] = "TRUE";
                extraVars["op_type"] = "install"
            }
            else {
	        extraVars["FIELD_INSTALL"] = "FALSE";
                extraVars["op_type"] = "recreate"
            }
        }
        else if (("backup_file1" in $.operation_params.additionalParams) &&
                 ("backup_file2" in $.operation_params.additionalParams))
        {
            // The backup_file1 and backup_file2 parameters exist.
            // This means it is a CBAM instantiate operation.
            if (($.operation_params.additionalParams.backup_file1 === "") &&
                ($.operation_params.additionalParams.backup_file2 === ""))
            {
                // backup_file1 and backup_file2 exist but were not specified.
                // If an upgrade_file exists and was specified,
                // then this is a update-recreate operation.
                // otherwise this is a field install operation.
                if (("upgrade_file" in $.operation_params.additionalParams) &&
                    ($.operation_params.additionalParams.upgrade_file !== ""))
                {
                    // upgrade_file exists and was specified,
                    // so this is an update-recreate (SU) operation.
                    extraVars["FIELD_INSTALL"] = "FALSE";
                    extraVars["op_type"] = "update-recreate";
                }
                else
                {
                    // This is a field install operation.
                    extraVars["FIELD_INSTALL"] = "TRUE";
                    extraVars["op_type"] = "install";
                }
            }
            else 
            {
                // A backup file was specified.
                // Cannot have both a backup file and an upgrade file,
                // so if an upgrade_file exists and was specified,
                // then this is an error,
                // otherwise this is a recreate (DR) operation.
                if (("upgrade_file" in $.operation_params.additionalParams) &&
                    ($.operation_params.additionalParams.upgrade_file !== ""))
                {
                    throw "Cannot specify both a backup file and the upgrade file!";
                }
                else
                {
                    // This is a recreate (DR) operation.
                    extraVars["FIELD_INSTALL"] = "FALSE";
                    extraVars["op_type"] = "recreate";
                }
            }
        }

        // Skip Instantiate health check if requested
        if (extraVars["op_type"] === "install") {
            if ("skip_health_check" in $.operation_params.additionalParams) {
                skip_health_check = $.operation_params.additionalParams.skip_health_check.toUpperCase();
                extraVars["skip_health_check"] = ((skip_health_check === "YES") ? true : false);
            }
            else {
                extraVars["skip_health_check"] = false;
            }
        }

    }
}

return extraVars;
