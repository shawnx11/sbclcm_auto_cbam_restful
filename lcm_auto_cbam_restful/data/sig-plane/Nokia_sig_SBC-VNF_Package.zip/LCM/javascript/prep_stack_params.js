function isJsonString(str) {
  try {
    JSON.parse(str);
  } catch (e) {
    return false;
  }
  return true;
}

function deepCopy(oldObj) {
    var newObj = oldObj;
    if (oldObj && typeof oldObj === 'object') {
        newObj = Object.prototype.toString.call(oldObj) === "[object Array]" ? [] : {};
        for (var i in oldObj) {
            newObj[i] = deepCopy(oldObj[i]);
        }
    }
    return newObj;
}

function buildLcpParams(stack_params, nfv_model, operation_params, op_type) {
    const extensions = stack_params.cbam.extensions;
    const extCps = nfv_model.externalConnectionPoints;
    const resources = stack_params.cbam.resources;
    var nfv_images = nfv_model.swImages;
    var new_struct = {};
    var group_info = {};
    new_struct["ext_net_info"] = deepCopy(extensions.ext_net_info);
    group_info["defaults"] = {};
    global_defaults = {};
    global_defaults["action"] = extensions.defaults["action"];
    global_defaults["image"] = {};
    switch (op_type) {
       case "recreate":
       case "update-recreate":
           global_defaults["action"] = {"0": op_type, "1": op_type};
           break;
       case "instantiate":
           global_defaults["action"] = {"0": "install", "1": "install"};
           break;
       case "scale":
           scale_op = (operation_params.type === "out") ? "scale-out" : "scale-in";
           global_defaults["action"] = {"0": scale_op, "1": scale_op};
           break;
       default:
           break;
    }
    global_defaults["storage_zone"] = {};
    global_defaults["binding_type"] = extensions.defaults["binding_type"];
    global_defaults["availability_zone"] = {};

    var zones = {};
    if (nfv_model.hasOwnProperty("zones")) {
        zones = nfv_model.zones;
    }

    var zone_keys = Object.keys(zones);
    if (zone_keys.length < 1) {
        if (nfv_model.hasOwnProperty("zoneInfo")) {
            var zoneInfo = nfv_model["zoneInfo"];
            for (var i = 0; i < zoneInfo.length; i++) {
                zones[zoneInfo[i]["id"]] = zoneInfo[i]["zoneId"];
            }
        }
    }

    for (var rsc in resources) {
        const cbam_resource = resources[rsc];
        var group_tag = "";
        if (rsc.endsWith("_RRG")) {
            group_tag = rsc.substring(0, rsc.indexOf("_RRG")).toLowerCase();
        } else {
            group_tag = rsc.toLowerCase();
        }

       group_info[group_tag] = {};
       grp_defaults = {};
       const group_data = extensions[group_tag];
       grp_defaults["image"] = {};
       grp_defaults["flavor"] = {};
       grp_defaults["storage_zone"] = {};
       grp_defaults["availability_zone"] = {};
       for (var grp_index in group_data) {
           group_info[group_tag][grp_index] = {};
           for (var member_index in group_data[grp_index]) {
              var side = ((member_index === "0") ? "NOKIA-LCP-VMA" : "NOKIA-LCP-VMB");
              group_info[group_tag][grp_index][member_index] = {};
              group_info[group_tag][grp_index][member_index]["name"] = group_data[grp_index][member_index]["name"];
              if (group_data[grp_index][member_index].hasOwnProperty("storage_name")) {
                  var storage_name = group_data[grp_index][member_index]["storage_name"];
                  group_info[group_tag][grp_index][member_index]["storage_name"] = storage_name;
              }
              if (cbam_resource.hasOwnProperty(side)) {
                  grp_defaults["flavor"][member_index] = cbam_resource[side]["flavorId"];
                  grp_defaults["storage_zone"][member_index] = zones["storage"+member_index];
                  grp_defaults["availability_zone"][member_index] = zones[member_index];

                  //Update 'defaults' as part of OAM (static vdu) update
                  global_defaults["image"][member_index] = cbam_resource[side]["imageId"];
                  global_defaults["storage_zone"][member_index] = grp_defaults["storage_zone"][member_index];
                  global_defaults["availability_zone"][member_index] = grp_defaults["availability_zone"][member_index];
              } else if (cbam_resource.hasOwnProperty(grp_index)) {
                  grp_defaults["flavor"][member_index] = cbam_resource[grp_index][side]["flavorId"];
                  grp_defaults["storage_zone"][member_index] = zones["storage"+member_index];
                  grp_defaults["availability_zone"][member_index] = zones[member_index];
              } else if (cbam_resource["count"] == "0") {
                  continue;
              }

              for (var vnic_id in group_data[grp_index][member_index]["vnic_info"]) {
                  if (vnic_id === "0") {
                      //Ignore internal netwok entries
                      continue;
                  }
                  var cpdid = group_tag+((member_index === "0") ? "_a_" : "_b_")+"external"+vnic_id+"_ECP";
                  if (typeof(extCps[cpdid]) === "undefined") {
                      if (parseInt(vnic_id) > 1) {
                          throw "No addresses for extCp: " + cpdid + "! Check instantiation parameters!";
                      }
                      continue;
                  }
                  if (typeof(group_info[group_tag][grp_index][member_index]["vnic_info"]) === "undefined") {
                      group_info[group_tag][grp_index][member_index]["vnic_info"] = {};
                  }
                  group_info[group_tag][grp_index][member_index]["vnic_info"][vnic_id] = {};
                  group_info[group_tag][grp_index][member_index]["vnic_info"][vnic_id]["set_ips"] = {};
                  const cpdid_len = extCps[cpdid].length;
                  var set_ips = group_data[grp_index][member_index]["vnic_info"][vnic_id]["set_ips"];
                  var ip_keys = Object.keys(set_ips);
                  var ip_len = ip_keys.length;
                  if (group_data[grp_index][member_index]["vnic_info"][vnic_id].hasOwnProperty("portname")) {
                      var portname = group_data[grp_index][member_index]["vnic_info"][vnic_id]["portname"];
                      group_info[group_tag][grp_index][member_index]["vnic_info"][vnic_id]["portname"] = portname;
                  }

                  //Pre-created ports
                  if (group_data[grp_index][member_index]["vnic_info"][vnic_id].hasOwnProperty("port_uuid")) {
                      var port_uuid = group_data[grp_index][member_index]["vnic_info"][vnic_id]["port_uuid"];
                      group_info[group_tag][grp_index][member_index]["vnic_info"][vnic_id]["port_uuid"] = port_uuid;
                      if (group_data[grp_index][member_index]["vnic_info"][vnic_id].hasOwnProperty("mac_address")) {
                          var mac_address = group_data[grp_index][member_index]["vnic_info"][vnic_id]["mac_address"];
                          group_info[group_tag][grp_index][member_index]["vnic_info"][vnic_id]["mac_address"] = mac_address;
                      }
                  }

                  for (var i = 0; i < ip_len; i++) {
                      var label = ip_keys[i];
                      const offset = (parseInt(grp_index) * ip_len) + parseInt(set_ips[label]);
                      if (offset >= cpdid_len) {
                          throw "Not enough addresses for extCp: " + cpdid + "! Check instantiation parameters!";
                      }
                      const address = extCps[cpdid]["addresses"][offset];
                      var use_ip = "";
                      var new_dict = {};
                      //TODO - Need to handle dynamic or cloud assigned IPs
                      if (typeof(extCps[cpdid]["numDynamicAddresses"]) !== "undefined") {
                          new_dict = {"subnetId": address["subnetId"], "numDynamicAddresses": extCps[cpdid]["numDynamicAddresses"]};
                      } else {
                          new_dict = {"subnetId": address["subnetId"], "ip": address["ip"]};
                      }
                      group_info[group_tag][grp_index][member_index]["vnic_info"][vnic_id]["set_ips"][label] = address["ip"];
                      //group_info[group_tag][grp_index][member_index]["vnic_info"][vnic_id]["set_ips"][label] = new_dict;
                      //group_info[group_tag][grp_index][member_index]["vnic_info"][vnic_id]["networkId"] = extCps[cpdid]["vlResource"];
                  }
              }
           }
       }
       group_info[group_tag]["defaults"] = grp_defaults;
    }
    new_struct["group_info"] = group_info;
    new_struct["defaults"] = global_defaults;
    return (new_struct);
}

//Unfortunately, '$.operation_type' is not passed to javascripts.
//Set 'op_type' based on expected inputs eg.
//   - "flavourId" is a required param in Instantiate
//   - "type" is a required field for in Scale
//   - "terminationType" is required in Terminate
//   - "upgrade_image_name" and "installed_image_name" side A and B are required for Upgrade
var op_type = "";
if (typeof($.operation_params) !== "undefined") {
   if ( ("flavourId" in $.operation_params) || ("instantiationLevelId" in $.operation_params) ) {
       if (($.operation_params.additionalParams.backup_file1 === "") &&
           ($.operation_params.additionalParams.backup_file2 === ""))
       {
           // backup_file1 and backup_file2 were both not specified.
           if (("upgrade_file" in $.operation_params.additionalParams) &&
               ($.operation_params.additionalParams.upgrade_file !== ""))
           {
               // The upgrade_file was specified.
               op_type = "UPDATE-RECREATE";
           }
           else
           {
               // No backup file or upgrade file was specified.
               op_type = "INSTANTIATE";
           }
       }
       else
       {
           // A backup file was specified.
           if (("upgrade_file" in $.operation_params.additionalParams) &&
               ($.operation_params.additionalParams.upgrade_file !== ""))
           {
               throw "Cannot specify both a backup file and the upgrade file!";
           }
           else
           {
               // Only a backup file was specified.
               op_type = "RECREATE";
           }
       }
   }
   else if ("type" in $.operation_params) {
       if (($.operation_params.type == "out") || ($.operation_params.type == "in")) {
           op_type = "SCALE";
       }
   }
} else {
   if ( (typeof($.upgrade_image_name) !== "undefined") || (typeof($.installed_image_name_side_a) !== "undefined") || (typeof($.installed_image_name_side_b) !== "undefined") ) {
       if (typeof($.upgrade_image_name) === "undefined") {
           throw "Missing expected upgrade image name parameter!";
       }
       if (typeof($.installed_image_name_side_a) === "undefined") {
           throw "Missing expected side A installed image name parameter!";
       }
       if (typeof($.installed_image_name_side_b) === "undefined") {
           throw "Missing expected side B installed image name parameter!";
       }
       if ($.upgrade_image_name === "") {
           throw "Expected upgrade image name not specified!";
       }
       if ($.installed_image_name_side_a === "") {
           throw "Expected side A installed image name not specified!";
       }
       if ($.installed_image_name_side_b === "") {
           throw "Expected side B installed image name not specified!";
       }
       op_type = "UPGRADE";
   }
}

// CBAM extensions might have been updated. Refresh to reflect the change.
for (var param in $.stack_params.cbam.extensions) {
    if (param == "install_config") {
        continue;
    }
    if (isJsonString($.stack_params.cbam.extensions[param])) {
        new_param = JSON.parse($.stack_params.cbam.extensions[param]);
        $.stack_params.cbam.extensions[param] = new_param;
    }
}

var ETSI_SOL_SUPPORTED = false;
//Update 'stack_params'
if (  (typeof($.stack_params.cbam.extensions) !== "undefined") &&
      (typeof($.stack_params.cbam.extensions.etsi_sol_supported) !== "undefined")) {
    ETSI_SOL_SUPPORTED = true;
    $.stack_params.cbam.lcp = buildLcpParams($.stack_params, $.nfv_model, $.operation_params, op_type.toLowerCase());
}

switch (op_type) {
    case "INSTANTIATE":
    case "RECREATE":
    case "UPDATE-RECREATE":
        if (ETSI_SOL_SUPPORTED === false) {
            var keys = Object.keys($.nfv_model.zones);
            n = keys.length;
            if (n > 0) {
               var images = $.stack_params.cbam.extensions.defaults.image;
               for(var rsc in $.stack_params.cbam.resources) {
                  for(var item in $.stack_params.cbam.resources[rsc] ) {
                      id = parseInt(item);
                      if(!isNaN(id)) {
                         $.stack_params.cbam.resources[rsc][item]["NOKIA-LCP-VMA"].azId = $.nfv_model.zones["0"].zoneId;
                         $.stack_params.cbam.resources[rsc][item]["NOKIA-LCP-VMA"].imageId = images["0"];
                         if ( typeof($.stack_params.cbam.resources[rsc][item]["NOKIA-LCP-VMB"]) !== "undefined")   {
                             $.stack_params.cbam.resources[rsc][item]["NOKIA-LCP-VMB"].azId = $.nfv_model.zones["1"].zoneId;
                             $.stack_params.cbam.resources[rsc][item]["NOKIA-LCP-VMB"].imageId = images["1"];
                         }
                      }
                      else if (item === "NOKIA-LCP-VMA") {
                         $.stack_params.cbam.resources[rsc]["NOKIA-LCP-VMA"].azId = $.nfv_model.zones["0"].zoneId;
                         $.stack_params.cbam.resources[rsc]["NOKIA-LCP-VMA"].imageId = images["0"];
                         if ( typeof($.stack_params.cbam.resources[rsc]["NOKIA-LCP-VMB"]) !=="undefined") {
                             $.stack_params.cbam.resources[rsc]["NOKIA-LCP-VMB"].azId = $.nfv_model.zones["1"].zoneId;
                             $.stack_params.cbam.resources[rsc]["NOKIA-LCP-VMB"].imageId = images["1"];
                         }
                      }
                  }
               }
            } else {
               throw "There's not enough zones available for this operation! Check instantiation parameters!";
            }
        }

        if (op_type === "RECREATE") {
           var bkup_file1 = $.operation_params.additionalParams.backup_file1;
           var bkup_file2 = $.operation_params.additionalParams.backup_file2;

           // Notes on expected 'cert_flag' values:
           //    "0" - No certificates specified.
           //    "1" - Backup server 1 certificates specified and to be used.
           //    "2" - Backup server 2 certificates specified and to be used.
           //    "3" - Backup server 1 and 2 certificates specified. Try both and 
           //          use whichever is reachable. Logic for trying is in CLDbase.
           var cert_flag = "0";
           var reg_exp = /^http:\/\/.*$/
           if ( (bkup_file1 !=="")&&(!reg_exp.test(bkup_file1) ) ) {
              cert_flag = "1";
           }

           if ( (bkup_file2 !=="")&&(!reg_exp.test(bkup_file2) ) ) {
              cert_flag = ((cert_flag === "1") ? "3" : "2");
           }

           $.stack_params.cbam.extensions["certificate"] = cert_flag;
           $.stack_params.cbam.extensions.defaults.action["0"] = "recreate";
           $.stack_params.cbam.extensions.defaults.action["1"] = "recreate";
           $.stack_params.cbam.extensions.backup_file1 = $.operation_params.additionalParams.backup_file1;
           $.stack_params.cbam.extensions.backup_file2 = $.operation_params.additionalParams.backup_file2;
        }
        else if (op_type === "UPDATE-RECREATE") {
           var upgrade_file = $.operation_params.additionalParams.upgrade_file;
           var cert_flag = 0;

           if ( (upgrade_file !=="")&&(!upgrade_file.match(/^http:\/\/.*$/) ) ) {
              cert_flag = cert_flag + 1;
           }

           $.stack_params.cbam.extensions["certificate"] = cert_flag;
           $.stack_params.cbam.extensions.defaults.action["0"] = "update-recreate";
           $.stack_params.cbam.extensions.defaults.action["1"] = "update-recreate";
           $.stack_params.cbam.extensions.backup_file1 = $.operation_params.additionalParams.upgrade_file;
        }

        break;

    case "SCALE":
        //Update 'defaults.action'
        if ($.operation_params.type === "out") {
           $.stack_params.cbam.extensions.defaults.action = {"0": "scale-out", "1": "scale-out"};
        }
        else if ($.operation_params.type === "in") {
           $.stack_params.cbam.extensions.defaults.action = {"0": "scale-in", "1": "scale-in"};
        }
        break;

    case "UPGRADE":
        if (ETSI_SOL_SUPPORTED === false) {
            $.stack_params.cbam.extensions.defaults.image["0"] = $.installed_image_name_side_a;
            $.stack_params.cbam.extensions.defaults.image["1"] = $.installed_image_name_side_b;
            $.stack_params.cbam.extensions.defaults.action["0"] = "";
            $.stack_params.cbam.extensions.defaults.action["1"] = "";
        }
        break;

    default:
        break;
}

return $.stack_params;

