#!/bin/bash
vnfcList=$1
if [[ -f /storage/lcm_marker/heal.marker_file ]]; then
   line_count=`wc -l /storage/lcm_marker/heal.marker_file`
else
   echo "/storage/lcm_marker/heal.marker_file not exist...."
   exit 0
fi
failed=false
completed=false
started=false
j=0
for i in $(echo $vnfcList | sed "s/,/ /g")
do
   vmArr[j]=$i
   j=`expr $j + 1`
done

echo "List of Healing VMs: ${vmArr[@]}"

while IFS= read -r line
do
  if [[ $line = *"Completed"* ]]; then
     for k in ${!vmArr[@]} ; do
       if [[ $line = *"${vmArr[$k]}"* ]]; then
          unset vmArr[k]
       fi
    done
  elif [[ $line = *"Failed"* ]]; then
    echo "$line"
    failed=true
    break;
  fi
done < "/storage/lcm_marker/heal.marker_file"

if [[ ${#vmArr[*]} -eq 0 ]]; then
 echo "Healing completed for all VMs"
 exit 0
elif [[ $failed == "true" ]]; then
 echo "There are failures during healing. Please check next level of support."
 exit 2
else
 echo "Healing still in progress..."
 exit 1
fi
