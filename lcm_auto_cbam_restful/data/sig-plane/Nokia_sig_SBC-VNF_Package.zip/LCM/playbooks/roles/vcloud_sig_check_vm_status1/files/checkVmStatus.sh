#!/bin/bash
vnfcList=$1
for i in $(echo $vnfcList | sed "s/,/ /g")
do
    if [[ "$i" != *"oam"* ]]; then
       vmHealing=$(cat /var/opt/lib/mtce/data/mtce_host.data|grep "$i"|cut -d';' -f13)
       result=$(/opt/LSS/sbin/rem_srv_state --action display --set host --host "$vmHealing" | tail -1 | sed 's/\s\s*/ /g' | cut -d' ' -f7)
       echo "State of $vmHealing = $result"
    elif [ "$i" == "oam-a" ]; then
       result=$(/opt/LSS/sbin/MIcmd state pri)
       echo "State of $i = $result"
    elif [ "$i" == "oam-b" ]; then
       result=$(/opt/LSS/sbin/MIcmd state alt)
       echo "State of $i = $result"
    else
       echo "ERROR - vmHealing=$vmHealing : Please seek next level of support."
    fi
done
