#!/bin/ksh
. /opt/LSS/bin/RCCsetup

#load db data for Cleanup
/export/home/lss/bin/dbload -u lssdba -p lssdba -noversion -rm -b -all 2>&1 |print> /dev/null
if [[ $? != 0 ]]; then
        echo "!!! ERROR: dbload failed! Please seek next level of support...!!!"
        exit 1
fi
#Restart CNFG
/opt/LSS/bin/FScmd stop cnfg vc 2>&1 |print>/dev/null;sleep 5;/opt/LSS/bin/FScmd start cnfg vc 2>&1 |print>/dev/null
if [[ $? != 0 ]]; then
        echo "!!! ERROR: Restart CNFG failed! Please seek next level of support...!!!"
        exit 1
fi

#restart FS
FScmd stop fs vc 2>&1 |print>/dev/null;sleep 60;FScmd start fs vc 2>&1 |print>/dev/null;sleep 5;
if [[ $? != 0 ]]; then
        echo "!!! ERROR: Restart FS failed! Please seek next level of support...!!!"
        exit 1
fi

#init diskless services
init_cli -t c -i all;sleep 10;

exit 0

