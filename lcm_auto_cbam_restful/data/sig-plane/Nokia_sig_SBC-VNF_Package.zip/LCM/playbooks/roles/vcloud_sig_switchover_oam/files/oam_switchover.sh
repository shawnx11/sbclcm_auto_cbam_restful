#!/bin/bash

# Get oam-b state
oam_b_state=$(/opt/LSS/bin/MIvmstate)

# Perform switchover if oam-b is active
if [[ "$oam_b_state" = "A" ]];
then
   /opt/LSS/bin/MIcmd switch
   exit 1
fi

