#!/usr/bin/python

DOCUMENTATION = '''
---
action_plugin: "lcp_health_chk"
short_description: action plugin used to parse a lcp health_check results
'''

import json
import re

from ansible import constants as C
from ansible.plugins.action import ActionBase
from ansible.errors import AnsibleError
from subprocess import Popen, PIPE, STDOUT
from ansible.utils.display import Display

display = Display()

class ActionModule(ActionBase):

    def run(self, tmp=None, task_vars=None):
        if task_vars is None:
            task_vars = dict()

        result = super(ActionModule, self).run(tmp, task_vars)

        health_result = self._task.args.get('health_result', None)

        if health_result is None:
            raise AnsibleError("health_result is a required argument.")

        display.vv("parse_health_result ActionModule: result=%s" % (health_result))

        # Default the return result
        result.update(dict(
            changed = False,
            rc      = 0,
            stderr  = '',
            stdout  = '',
        ))

        # See if health finished successfully
        if health_result.find("chk_all completed successfully") != -1:
            return result

        failed_tests = ""

        if health_result.find("chk_rsh_ssh completed successfully.") == -1:
            failed_tests += "chk_rsh_ssh failed\n"

        if health_result.find("chk_versions completed successfully.") == -1:
            failed_tests += "chk_versions failed\n"

        if health_result.find("log_ips completed successfully.") == -1:
            failed_tests += "log_ips failed\n"

        if health_result.find("chk_REMstates completed successfully.") == -1:
            failed_tests += "chk_REMstates failed\n"

        if health_result.find("chk_hostclocks completed successfully.") == -1:
            failed_tests += "chk_hostclocks failed\n"

        if health_result.find("chk_lv completed successfully.") == -1:
            failed_tests += "chk_lv failed\n"

        if health_result.find("chk_config completed successfully.") == -1:
            failed_tests += "chk_config failed\n"

        if health_result.find("chk_RCC_VMstates RCC completed successfully.") == -1:
            failed_tests += "chk_RCC_VMstates failed\n"

        if health_result.find("chk_RCC_VMstates VM completed successfully.") == -1:
            failed_tests += "chk_RCC_VMstates failed\n"

        if health_result.find("chk_rem_image completed successfully.") == -1:
            failed_tests += "chk_rem_image failed\n"

        if health_result.find("chk_rem_sv_bld completed successfully.") == -1:
            failed_tests += "chk_rem_sv failed\n"

        if health_result.find("chk_alarm completed successfully.") == -1:
            failed_tests += "chk_alarm failed\n"

        if health_result.find("chk_cpm completed successfully.") == -1:
            failed_tests += "chk_cpm failed\n"

        if health_result.find("chk_nk_split completed successfully.") == -1:
            failed_tests += "chk_nk_split failed\n"

        if health_result.find("log_namingdata completed successfully.") == -1:
            failed_tests += "log_namingdata failed\n"

        if health_result.find("chk_db_repl completed successfully.") == -1:
            failed_tests += "chk_db_repl failed\n"

        if health_result.find("chk_database completed successfully.") == -1:
            failed_tests += "chk_database failed\n"

        if health_result.find("chk_connectivity completed successfully.") == -1:
            failed_tests += "chk_connectivity failed\n"

        if health_result.find("chk_diskspace completed successfully.") == -1:
            failed_tests += "chk_diskspace failed\n"

        if health_result.find("chk_evolve_diskspace completed successfully.") == -1:
            failed_tests += "chk_evolve failed\n"

        if health_result.find("chk_shmc completed successfully.") == -1:
            failed_tests += "chk_shmc failed\n"

        if health_result.find("chk_hub completed successfully.") == -1:
            failed_tests += "chk_hub failed\n"

        if health_result.find("chk_oam completed successfully.") == -1:
            failed_tests += "chk_oam failed\n"

        # Fill in the error message
        result['failed'] = True
        result['msg']    = failed_tests

        return result
