#!/usr/bin/python

DOCUMENTATION = '''
---
action_plugin: lcp_host_access
short_description: used to obtain full MI access for this ansible account 
'''

from subprocess import Popen, PIPE, STDOUT
from ansible import constants as C
from ansible.errors import AnsibleError
from ansible.utils.display import Display
from ansible.plugins.action import ActionBase

import time
import os
import socket

DEFAULT_RET_MAP = {
        "returncode": 0,
        "std_err":"",
        "std_out":""
    }

class attrdict(dict):
    def __init__(self, *args, **kwargs): 
        dict.__init__(self, *args, **kwargs)     
        self.__dict__ = self

def run_cmd(command):         
    retCode = attrdict(DEFAULT_RET_MAP)
    proc = Popen(command, stdout=PIPE, stderr=PIPE)
    retCode.std_out, retCode.std_err = proc.communicate()
    retCode.returncode = proc.returncode
    return retCode

display = Display()

class ActionModule(ActionBase):

    def run(self, tmp=None, task_vars=None):
        if task_vars is None:
            task_vars = dict()

        result = super(ActionModule, self).run(tmp, task_vars)

        if 'host' not in self._task.args:
            raise AnsibleError("host is a required argument.")
        host = self._task.args.get('host', None)

        if not 'mode' in self._task.args:
            raise AnsibleError("mode is a required argument.")
        mode = self._task.args.get('mode', None)

        if (mode != "add") and (mode != "remove") and (mode != "access"):
            raise AnsibleError("'mode' can only be add, remove or access")

        if not 'user' in self._task.args:
            raise AnsibleError("user is a required argument.")
        user = self._task.args.get('user', None)

        if (mode == "add") and (not 'pem' in self._task.args):
            raise AnsibleError("pem is a required argument for add.")
        pem = self._task.args.get('pem', None)

        # Get optional op_type
        op_type = self._task.args.get('op_type', None)

        # Default the return result
        result.update(dict(
            changed = False,
            rc      = 0,
            stderr  = '',
            stdout  = '',
        ))

        # Confirm the IP address is valid
        if (not is_valid_ipv4_address(host)) and (not is_valid_ipv6_address(host)):
            result['failed'] = True
            result['msg'] = "Invalid IP Address %s" % host
            return result

        if mode == "access":
            # If the remote host is currently accessably just return true
            result['changed'] = False

            rc = ssh_host_accessable(user, host)
            if rc.returncode == 0:
                result['msg'] = "host accessable"
            else:
                result['msg'] = "host not accessable"
            return result

        if mode == "add":
            key_name="id_rsa"
            key_dir=os.path.expanduser("~") + "/.ssh/"

            # If the remote host is currently accessably just return true
            rc = ssh_host_accessable(user, host)
            if rc.returncode == 0:
                # Reserve Access - Create op_type file for the LCM request
                if op_type != None:
                    reserve_access(user, host, pem, op_type)
                result['changed'] = False
                result['msg'] = "host already accessable"
                return result

            # Remove the host from the known_hosts file 
            remove_old_key(host)

            # Create the keypair if missing
            rc = create_temp_key(key_dir, key_name)
            if rc.returncode != 0:
                result['failed'] = True
                result['msg'] = "Failed to create keypair"
                result['msg'] += "\nstd_err: " + rc.std_err + "\nstd_out: " + rc.std_out
                result['rc'] = rc.returncode
                return result

            rc, err_msg = add_keyfile_to_host(user, host, pem, key_dir, key_name)

            if rc != 0:
                result['failed'] = True
                result['msg'] = err_msg
                result['rc'] = rc
                return result

            # Reserve Access - Create op_type file for the LCM request
            if op_type != None:
                reserve_access(user, host, pem, op_type)
            
        if mode == "remove":
            # If the remote host is not currently accessably just return true
            rc = ssh_host_accessable(user, host)
            if rc.returncode != 0:
                result['changed'] = False
                return result

            # Unreserve access - Delete op_type file and check if to close access
            if op_type != None:
                result['clean'] = True
                rc = unreserve_access(user, host, pem, op_type)
                if (rc.returncode != 0):
                    # Return without closing access
                    err_msg = "FAILED to delete op_type file"
                    err_msg += "\nstd_err: " + rc.std_err.strip() + "\nstd_out: " + rc.std_out.strip()
                    result['failed'] = True # Cleanup/close access
                    result['msg']    = err_msg
                    return result
                elif (rc.std_out.strip() != "0"):
                    # Return without closing access
                    result['changed'] = False # Do not close access
                    result['clean'] = False
                    return result

            rc, err_msg = restore_keyfile_from_host(user, host)

            if rc != 0:
                result['failed'] = True
                result['msg']    = err_msg
                return result

        return result


# CONSTANTS

DEFAULT_SSH_OPTIONS = ["/usr/bin/ssh",
                       "-o",
                       "BatchMode=yes",
                       "-o",
                       "ConnectTimeout=30",
                       "-o",
                       "StrictHostKeyChecking=no"]

DEFAULT_SCP_OPTIONS = ["/usr/bin/scp",
                       "-o",
                       "BatchMode=yes",
                       "-o",
                       "ConnectTimeout=30",
                       "-o",
                       "StrictHostKeyChecking=no"]


def remove_old_key(host):
    ssh_string = ["/usr/bin/ssh-keygen", "-R", host]

    return run_cmd(ssh_string)

# This function will create a keypair in $HOME/.ssh/ansible_tmp directory
# This keypair can be used when accessing the MI
#
def create_temp_key(key_dir, key_name):
    # Maybe add check for last character in key_dir to see if it's a /
    # Set up new keyfile directory
    key_path = key_dir + key_name

    retval = os.getcwd()

    # Create the directory if it doesnt exist
    try:
        os.chdir(key_dir)
    except:
        os.mkdir(key_dir, 0700)
        os.chdir(key_dir)

    if os.path.isfile(key_name):
        return attrdict(DEFAULT_RET_MAP)

    # Do I need to change the permissions>
    ssh_string = ["/usr/bin/ssh-keygen", "-N", "", "-t", "rsa", "-f", key_name ]

    rc = run_cmd(ssh_string)

    os.chdir(retval)

    return rc


# Cleans up a temporary keygen
def remove_temp_key(key_dir, key_name):
    priv_key = key_name
    pub_key  = key_name + ".pub"

    retval = os.getcwd()

    # Create the directory if it doesnt exist
    try:
        os.chdir(key_dir)
    except:
        return 0

    if os.path.isfile(priv_key):
        os.remove(priv_key)

    if os.path.isfile(pub_key):
        os.remove(pub_key)

    os.chdir(retval)

    return 0


def confirm_remote_file(user, host, pem, rfile):
    target = user + "@" + host

    # Confirm that the remote $HOME/.ssh directory exists
    rmt_cmd    = "/usr/bin/test -f " + rfile
    ssh_string = DEFAULT_SSH_OPTIONS + ["-i", pem, target, rmt_cmd]

    return run_cmd(ssh_string)

def create_remote_file(user, host, pem, rfile):
    target = user + "@" + host

    # Confirm that the remote $HOME/.ssh directory exists
    rmt_cmd    = "/usr/bin/touch " + rfile
    ssh_string = DEFAULT_SSH_OPTIONS + ["-i", pem, target, rmt_cmd]

    return run_cmd(ssh_string)

def confirm_remote_dir(user, host, pem, rdir):
    target = user + "@" + host

    # Confirm that the remote $HOME/.ssh directory exists
    rmt_cmd    = "/usr/bin/test -d " + rdir
    ssh_string = DEFAULT_SSH_OPTIONS + ["-i", pem, target, rmt_cmd]

    return run_cmd(ssh_string)


def create_remote_dir(user, host, pem, rdir):
    target = user + "@" + host

    # Confirm that the remote $HOME/.ssh directory exists
    rmt_cmd    = "/usr/bin/mkdir -p " + rdir
    ssh_string = DEFAULT_SSH_OPTIONS + ["-i", pem, target, rmt_cmd]

    return run_cmd(ssh_string)

# Arguments:
#    user     - remote host user
#    host     - remote host
#    pem      - private rsa key for remote user@host
#    key_dir  - directory for the local public key
#    key_name - name of the local public key
# Returns:
#    returnCode - Return code for the command run
#    msg        - error message or empty string

def add_keyfile_to_host(user, host, pem, key_dir, key_name):
    src_file  = key_name + ".pub"              #
    dest_file = "ansible_key"                  #
    target    = user + "@" + host              #
    target_scp	= user + "@[" + host + "]"     #
    src       = key_dir + src_file             # local public key
    dest      = target_scp + ":/tmp/" + dest_file  # remote /tmp
    msg       = ""

    # Prechecks before copying over the public key
    rc = confirm_remote_dir(user, host, pem, "$HOME/.ssh")
    if rc.returncode != 0:
        msg = "remote directory " + target + ":$HOME/.ssh not found"
        msg += "\nstd_err: " + rc.std_err + "\nstd_out: " + rc.std_out
        return 255, msg

    # Prechecks before copying over the public key
    rc = confirm_remote_file(user, host, pem, "$HOME/.ssh/authorized_keys2")
    if rc.returncode != 0:
        msg = "remote file " + target + ":$HOME/.ssh/authorized_keys2 not found"
        msg += "\nstd_err: " + rc.std_err + "\nstd_out: " + rc.std_out
        return 255, msg

    # Copy the local public key to remote /tmp
    scp_string = DEFAULT_SCP_OPTIONS + ["-i", pem, src, dest]

    rc = run_cmd(scp_string)
    if rc.returncode != 0:
        msg = "failed to copy public key " + src_file + " to remote host " + host
        msg += "\nstd_err: " + rc.std_err + "\nstd_out: " + rc.std_out
        return rc.returncode, msg

    # backup the remote authorized_keys2 file
    rmt_cmd    = "/usr/bin/cp $HOME/.ssh/authorized_keys2 $HOME/.ssh/authorized_keys2.bkup"
    ssh_string = DEFAULT_SSH_OPTIONS + ["-i", pem, target, rmt_cmd]

    rc = run_cmd(ssh_string)
    if rc.returncode != 0:
        msg = "failed to backup authorized_keys2 file on remote host "+ host
        msg += "\nstd_err: " + rc.std_err + "\nstd_out: " + rc.std_out
        return rc.returncode, msg

    # cat the public key to the remote authorized_keys2 file
    rmt_cmd    = "/usr/bin/cat /tmp/" + dest_file + " >> $HOME/.ssh/authorized_keys2"
    ssh_string = DEFAULT_SSH_OPTIONS + ["-i", pem, target, rmt_cmd]

    rc = run_cmd(ssh_string)
    if rc.returncode != 0:
        msg = "failed to cat public key to authorized_keys2 file on remote host " + host
        msg += "\nstd_err: " + rc.std_err + "\nstd_out: " + rc.std_out
        return rc.returncode, msg

    # remove the public keyfile from /tmp
    rmt_cmd    = "/usr/bin/rm /tmp/" + dest_file
    ssh_string = DEFAULT_SSH_OPTIONS + ["-i", pem, target, rmt_cmd]

    rc = run_cmd(ssh_string)
    if rc.returncode != 0:
        msg = "failed to remove public keyfile %s on remote host %s" % (dest_file, host)
        msg += "\nstd_err: " + rc.std_err + "\nstd_out: " + rc.std_out

    return rc.returncode, msg


def restore_keyfile_from_host(user, host):
    target    = user + "@" + host              #

    rmt_cmd = "test -f $HOME/.ssh/authorized_keys2.bkup"
    ssh_string = DEFAULT_SSH_OPTIONS + [target, rmt_cmd]

    rc = run_cmd(ssh_string)
    if (rc.returncode != 0):
        # File does not exist. Return success.
        # This may because the host was already accessible.
        return 0, "Restore not needed."

    rmt_cmd    = "/usr/bin/mv $HOME/.ssh/authorized_keys2.bkup $HOME/.ssh/authorized_keys2"
    ssh_string = DEFAULT_SSH_OPTIONS + [target, rmt_cmd]
    msg = ""

    rc = run_cmd(ssh_string)
    if rc.returncode != 0:
        msg = "failed to restore authorized_keys2 file on remote host " + host
        msg += "\nstd_err: " + rc.std_err + "\nstd_out: " + rc.std_out

    return rc.returncode, msg

# used to determine if the host is already accessable
def ssh_host_accessable(user, host):
    dest="%s@%s" % (user, host)

    # You need some sort of command to run or you can get hung up on the login script asking
    # for inputted data
    ssh_string = DEFAULT_SSH_OPTIONS + [dest,'/usr/bin/true']

    return run_cmd(ssh_string)

# Create 'op_type' corresponding to the LCM operation
def reserve_access(user, host, pem, op_type):
    rdir = os.path.expanduser("~" + user) + "/LCM/"
    rc = confirm_remote_dir(user, host, pem, rdir)
    if rc.returncode != 0:
        # Create directore
        rc = create_remote_dir(user, host, pem, rdir)
        if rc.returncode != 0:
            return rc

    # Create file for the given op_type
    remote_file = rdir + op_type + "_op_type"
    return create_remote_file(user, host, pem, remote_file)

# Delete 'op_type' file and check if to close access
def unreserve_access(user, host, pem, op_type):
    target    = user + "@" + host
    # Delete file for the given op_type
    rdir = os.path.expanduser("~" + user) + "/LCM/"
    remote_file = rdir + op_type + "_op_type"
    rmt_cmd = "rm -rf  " + remote_file
    ssh_string = DEFAULT_SSH_OPTIONS + ["-i", pem, target, rmt_cmd]
    rc = run_cmd(ssh_string)
    if rc.returncode != 0:
        return rc

    # Check if more op_type files left
    rmt_cmd = "/usr/bin/ls -1 "+ rdir + "*_op_type"
    ssh_string = DEFAULT_SSH_OPTIONS + ["-i", pem, target, rmt_cmd]
    ret = run_cmd(ssh_string)
    keep_files = False
    if ret.returncode == 0:
        file_list = ret.std_out.strip()
        for file_n in file_list.split("\n"):
            rmt_cmd = "OLD=`stat -c %Z " + file_n + "`;" + "NOW=`date +%s`; echo $(( (NOW - OLD)/60 ))"
            ssh_string = DEFAULT_SSH_OPTIONS + ["-i", pem, target, rmt_cmd]
            ret = run_cmd(ssh_string)
            if ret.returncode == 0:
                # Delete older files older than 120 mins. It's
                # unlikely that any LCM operation will take that long.
                # This ensures that we close access in case any LCM did fail.
                if (int(ret.std_out.strip()) >= 120):
                    rmt_cmd = "rm -rf  " + file_n
                    ssh_string = DEFAULT_SSH_OPTIONS + ["-i", pem, target, rmt_cmd]
                    run_cmd(ssh_string)
                else:
                    keep_files = True
    rc.std_out = ("1" if (keep_files == True) else "0")

    return rc

# used to confirm ip address is valid
def is_valid_ipv4_address(address):
    try:
        socket.inet_pton(socket.AF_INET, address)
    except AttributeError:  # no inet_pton here, sorry
        try:
            socket.inet_aton(address)
        except socket.error:
            return False
        return address.count('.') == 3
    except socket.error:  # not a valid address
        return False

    return True

def is_valid_ipv6_address(address):
    try:
        socket.inet_pton(socket.AF_INET6, address)
    except socket.error:  # not a valid address
        return False
    return True
