#!/usr/bin/python

DOCUMENTATION = '''
---
action_plugin: lcp_monitor
short_description: used to monitor file on specified host
'''

from subprocess import Popen, PIPE, STDOUT
from ansible import constants as C
from ansible.errors import AnsibleError
from ansible.utils.display import Display
from ansible.plugins.action import ActionBase

import time
import os
import socket

display = Display()

class ActionModule(ActionBase):

    def run(self, tmp=None, task_vars=None):
        if task_vars is None:
            task_vars = dict()

        result = super(ActionModule, self).run(tmp, task_vars)

        if 'host' not in self._task.args:
            raise AnsibleError("host is a required argument.")
        host = self._task.args.get('host', None)

        if not 'file_type' in self._task.args:
            raise AnsibleError("file_type is a required argument.")
        file_type = self._task.args.get('file_type', None)

        if (file_type not in ['install', 'recreate', 'scale-out', 'scale-in', 'scale-up', 'scale-down', 'heal', 'restore', 'update', 'db-restore', 'update-recreate']):
            raise AnsibleError("{0} - invalid file/request type.".format(file_type))

        if not 'user' in self._task.args:
            raise AnsibleError("user is a required argument.")
        user = self._task.args.get('user', None)

        if (not 'pem' in self._task.args):
            raise AnsibleError("pem is a required argument.")
        pem = self._task.args.get('pem', None)

        if (not 'retries' in self._task.args):
            raise AnsibleError("retries is a required argument.")
        retries = int(self._task.args.get('retries', None))

        if (not 'delay' in self._task.args):
            raise AnsibleError("delay is a required argument.")
        delay = int(self._task.args.get('delay', None))

        delete = False
        if ('delete' in self._task.args):
            delete = self._task.args.get('delete', None)

        backup = False
        if ('backup' in self._task.args):
            backup = self._task.args.get('backup', None)

        entries = 1
        if ('entries' in self._task.args):
            entries = int(self._task.args.get('entries', None))
        if entries < 1 :
            raise AnsibleError("entries argument must be 1 or more")

        # Default the return result
        result.update(dict(
            changed = False,
            rc      = 0,
            msg     = '',
            stderr  = '',
            stdout  = '',
            json    = '{}',
        ))

        # Confirm the IP address is valid
        if (not is_valid_ipv4_address(host)) and (not is_valid_ipv6_address(host)):
            result['failed'] = True
            result['msg'] = "Invalid IP Address %s" % host
            return result

        # Monitor specified file.  Return will be 
        (result['rc'], result['stdout'], result['stderr'], result['json']) = \
          monitor_progress(user, host, pem, file_type, retries, delay, entries)

        if (result['rc'] != 0):
            result['failed'] = True
            result['msg'] = "{0} failed.".format(file_type)

        if backup:
            # do not check for any failure
            bkup_marker(user, host, pem, file_type)

        if delete:
            # do not check for any failure
            del_marker(user, host, pem, file_type)

        return result

# CONSTANTS
DEFAULT_SSH = "/usr/bin/ssh -o BatchMode=yes -o ConnectTimeout=30 -o StrictHostKeyChecking=no"
MARKER_FILE_LOC = "/storage/lcm_marker"

def monitor_progress(user, host, pem, file_type, retries, delay, entries):

    #print('TRACE: monitor marker for [{0}] on host [{1}] for [{2}] entries.'.format( file_type, host, entries ))

    rmt_file = "{0}/{1}.marker_file".format(MARKER_FILE_LOC, file_type)
    rmt_cmd = "cat {0}".format(rmt_file)
    ssh_cmd = "{0} -i {1} {2}@{3} \"{4}\"".format( \
        DEFAULT_SSH, pem, user, host, rmt_cmd)

    while True:
        line_count = 0
        completed = 0
        failed = 0
        done = False

        #print('TRACE: Number of retries left: {0}. Monitoring {1}'.format(str(retries), rmt_file))
        proc = Popen(ssh_cmd, shell=True, stdout=PIPE, stderr=PIPE)
        (std_out, std_err) = proc.communicate()

        # In python 3.3 wait() would accept a timeout arg
        rc = proc.wait( )
        if (rc >= 0):
            for file_line in std_out.splitlines():
                line_count += 1
                # no need to check/count 'Started' lines
                if file_line.startswith( 'Completed' ):
                    completed += 1
                elif file_line.startswith( 'Failed' ):
                    failed += 1
           # end 'for file_line in ...'
        # end 'if rc >= 0'

        if completed + failed == entries :
            # all done, with success or failure
            break

        retries -= 1
        if ( retries <= 0 ):
            #print('TRACE: timeout - FAIL-TIMEOUT')
            # timeout
            rc = -1
            break
        time.sleep(delay)
    # end 'while True'

    if ( completed == entries ):
        rc = 0
    else:
        rc = -1

    # build json result string for each entry
    #
    # Parse out the contents of the marker file <Result> <VM Name> <Timestamp>
    # Completed ISC10-IMS-B1 pair-2-1-1 2016-09-13 04:07:29 (GMT)
    # Failed ISC10-IMS-A1 pair-2-0-1 2016-09-13 04:07:29 (GMT)
    # {"heal_status_list":[{"status":"Completed","name":"IMS-B1"},{"status":"Failed","name":"IMS-A1"}]}
    json_string='{"' + file_type + '_status_list":['
    line_count = 0
    for file_line in std_out.splitlines():
        s = file_line.split( ' ' )
        if len(s) >= 3 :
            line_count += 1
            json_string += '{"status":"' + str(s[0]) + '","name":"' + str(s[1]) + '"},'

    # remove the hanging ',' at then end of the string and cap off with the closing ]}
    if line_count > 0 :
        json_string = json_string[:-1]
    json_string += ']}'

    return (rc, std_out, std_err, json_string)

# used to confirm ip address is valid
def is_valid_ipv4_address(address):
    try:
        socket.inet_pton(socket.AF_INET, address)
    except AttributeError:  # no inet_pton here, sorry
        try:
            socket.inet_aton(address)
        except socket.error:
            return False
        return address.count('.') == 3
    except socket.error:  # not a valid address
        return False

    return True

def is_valid_ipv6_address(address):
    try:
        socket.inet_pton(socket.AF_INET6, address)
    except socket.error:  # not a valid address
        return False
    return True

# Used to check if a given marker file needs
# backup or delete. 
# Backup/Delete will only be performed on marker files
# containing "Completed"/"Failed" string i.e. for completed
# LCM scenarios.
def perform_action_on_maker_file(user, host, pem, rmt_file):
    # By the time CBAM invokes lcp_monitor, marker file might already contain
    # data for the current LCM procedure.
    rmt_cmd = "cat {0}".format(rmt_file)
    ssh_cmd = "{0} -i {1} {2}@{3} \"{4}\"".format(DEFAULT_SSH, pem, user, host, rmt_cmd)

    proc = Popen(ssh_cmd, shell=True, stdout=PIPE, stderr=PIPE)
    (std_out, std_err) = proc.communicate()
    if (proc.returncode != 0):
        return False

    for line in std_out.splitlines():
        if (   (line.startswith('Completed'))
            or (line.startswith('Failed'))):
           return True
    return False

def del_marker(user, host, pem, file_type):

    #print('TRACE: delete marker file for [{0}] on host [{1}]'.format( file_type, host ))

    rmt_file = "{0}/{1}.marker_file".format(MARKER_FILE_LOC, file_type)
    if (perform_action_on_maker_file(user, host, pem, rmt_file) == False):
        return True

    rmt_cmd = "/opt/LU3P/bin/sudo rm -f {0}".format(rmt_file)
    ssh_cmd = "{0} -i {1} {2}@{3} \"{4}\"".format( \
        DEFAULT_SSH, pem, user, host, rmt_cmd)

    #print( 'TRACE: ssh_cmd = [{0}]'.format( ssh_cmd ) )
    proc = Popen(ssh_cmd, shell=True, stdout=PIPE, stderr=PIPE)
    (std_out, std_err) = proc.communicate()

    # In python 3.3 wait() would accept a timeout arg
    proc.wait( )

    return True

def bkup_marker(user, host, pem, file_type):

    #print('TRACE: backup marker file for [{0}] on host [{1}]'.format( file_type, host ))

    rmt_file = "{0}/{1}.marker_file".format(MARKER_FILE_LOC, file_type)
    if (perform_action_on_maker_file(user, host, pem, rmt_file) == False):
        return True

    rmt_bk_file = "{0}.BK".format(rmt_file)
    rmt_cmd = "/opt/LU3P/bin/sudo rm -f {0}".format(rmt_bk_file)
    ssh_cmd = "{0} -i {1} {2}@{3} \"{4}\"".format( \
        DEFAULT_SSH, pem, user, host, rmt_cmd)

    #print( 'TRACE: ssh_cmd = [{0}]'.format( ssh_cmd ) )
    proc = Popen(ssh_cmd, shell=True, stdout=PIPE, stderr=PIPE)
    (std_out, std_err) = proc.communicate()

    # In python 3.3 wait() would accept a timeout arg
    proc.wait( )
    
    rmt_cmd = "/opt/LU3P/bin/sudo cp {0} {1}".format(rmt_file, rmt_bk_file)
    ssh_cmd = "{0} -i {1} {2}@{3} \"{4}\"".format( \
        DEFAULT_SSH, pem, user, host, rmt_cmd)

    #print( 'TRACE: ssh_cmd = [{0}]'.format( ssh_cmd ) )
    proc = Popen(ssh_cmd, shell=True, stdout=PIPE, stderr=PIPE)
    (std_out, std_err) = proc.communicate()

    # In python 3.3 wait() would accept a timeout arg
    proc.wait( )

    return True
