#!/usr/bin/python

DOCUMENTATION = '''
---
action_plugin: lcp_get_mi_ip.py
short_description: action plugin used to get MI IP address

This plugin will update the <ansible>/group_vars/main.yml file
'''

import json      # json interpreter module
import re        # Regular Expressions module
import socket    # Socket module
import subprocess
import os        # os access module

from ansible                import constants as C
from ansible.plugins.action import ActionBase
from ansible.errors         import AnsibleError
from subprocess             import Popen, PIPE, STDOUT
from ansible.utils.display  import Display

"""
Commented out instead of delete to avoid physical dependency on unsubmitted code

ROOT_OP_TYPE_LIST = ["install",
                     "recreate",
                     "update-recreate"
                    ]
"""

ROOT_OP_TYPE_LIST = ["install",
                     "update-recreate"
                    ]

DEFAULT_SSH_OPTIONS = ["/usr/bin/ssh",
                       "-o",
                       "BatchMode=yes",
                       "-o",
                       "ConnectTimeout=30",
                       "-o",
                       "StrictHostKeyChecking=no"]

class attrdict(dict):
    def __init__(self, *args, **kwargs):
        dict.__init__(self, *args, **kwargs)
        self.__dict__ = self


display = Display()
mi_a_int_ip  =  ""
mi_b_int_ip  =  ""

class ActionModule(ActionBase):

    def run(self, tmp=None, task_vars=None):
        if task_vars is None:
            task_vars = dict()

        result = super(ActionModule, self).run(tmp, task_vars)

        # Default the return result
        result.update(dict(
            changed = False,
            rc      = 0,
            stderr  = '',
            stdout  = '',
        ))

        # Looking for 3 arguments to this action plugin
        # mi_ip_list   : This is a string of IP candidates to find MI
        # user         : This is the user id to log into the MI with
        # pem          : path to pem file to get into MI

        if 'mi_ip_list' not in self._task.args:
            raise AnsibleError("'mi_ip_list' is a required argument.")
        mi_ip_list = self._task.args.get('mi_ip_list', None)

        if 'user' not in self._task.args:
            raise AnsibleError("'user' is a required argument.")
        user = self._task.args.get('user', None)

        if 'pem' not in self._task.args:
            raise AnsibleError("'pem' is a required argument.")
        pem = self._task.args.get('pem', None)

        # Get optional op_type
        op_type = self._task.args.get('op_type', None)

        # Check that the pem file exists before we go any further
        try:
            os.path.exists(pem)
        except:
            # If the pem file does not exist, raise error and return back to Ansible
            result['failed'] = True
            result['msg'] = "pem file %s not found." % pem
            result['rc'] = -1
            return result

        mi_list       = mi_ip_list.split(",") # split the string into a comma separated list

        # location of the lcm_util which will get the mi_external IPs
        exec_lcm_util = " test -f /opt/LSS/share/basecfg/fi/bin/lcm_util "

        msg = "\n'%s'" % (mi_list)
        for lcm_util_ip in mi_list:
            lcm_util_ip = lcm_util_ip.replace("\"", "").strip()
            cmd_str = DEFAULT_SSH_OPTIONS + ["-i", pem, user + "@" + lcm_util_ip, exec_lcm_util]
            proc = Popen(cmd_str, stdout=PIPE, stderr=PIPE)
            (s_out, s_err) = proc.communicate()

            if proc.returncode == 0:
                (ret, mi_int_fixed, err_msg) = get_mi_int_fixed(user, lcm_util_ip, pem, op_type)
                if ret != 0:
                    msg += '\n' + err_msg
                    continue

                # Return err if the MI int fixed IP was not found
                if not mi_int_fixed:
                    continue

                ret_dict = run_lcm_util(user, lcm_util_ip, mi_int_fixed, pem, op_type)
                if ret_dict.returncode != 0:
                    msg += '\n' + ret_dict.msg
                    continue

                # Sometimes, the 'run_lcm_util' fails on MI-B.
                # So, if the IPs are not set, continue onto the next one.
                if (ret_dict.mi_a_ip == 0):
                    continue

                result['changed'] = False
                result['MI_A_IP'] = ret_dict.mi_a_ip
                result['MI_B_IP'] = ret_dict.mi_b_ip
                result['MI_F_IP'] = ret_dict.mi_f_ip
                result['MI_A_INT_IP'] = mi_a_int_ip
                result['MI_B_INT_IP'] = mi_b_int_ip
                return result
            else:
                msg += "\n%s Failed - %s.\n%s\n%s" % (str(cmd_str), proc.returncode, s_out, s_err)
          
        result['failed'] = True
        result['rc'] = -1
        result['msg'] = "Unable to find MI external IPs " + msg
        return result

# return this MI's internal fixed IP 
def get_mi_int_fixed(user, mi_ip_address, pem, op_type):
    msg = ''
    global mi_a_int_ip
    global mi_b_int_ip

    # Retrieve MI-A and MI-B internal fixed IPs
    lcm_util_cmd = ""
    target = ""
    version_cmd = ""
    target = user + "@" + mi_ip_address
    lcm_util_cmd  = "/opt/LSS/share/basecfg/fi/bin/lcm_util -a get_mi_int_ips"
    version_cmd = "sudo /opt/LSS/sbin/mi_adm -a version"

    cmd_str = DEFAULT_SSH_OPTIONS + ["-i", pem, target, lcm_util_cmd]
    proc = Popen(cmd_str, stdout=PIPE, stderr=PIPE)
    (std_out, std_err) = proc.communicate()
    if proc.returncode != 0:
        not_allowed_str = user + ' is not allowed to execute'
        invalid_choice_str = "invalid choice: \'get_mi_int_ips\'"
        if (re.findall("Permission denied:\s+'/data0/FLD/lcm_util.log'", std_err)):
            # Handle SU from loads when 'lcmadm' cannot execute 'lcm_util' without 'sudo'
            lcm_util_cmd = "sudo /opt/LSS/share/basecfg/fi/bin/lcm_util -a get_mi_int_ips"
            cmd_str = DEFAULT_SSH_OPTIONS + ["-i", pem, target, lcm_util_cmd]
            proc = Popen(cmd_str, stdout=PIPE, stderr=PIPE)
            (std_out, std_err) = proc.communicate()
            if proc.returncode != 0:
                msg += "%s - %s Failed - %s.\n%s\n%s" % (op_type, str(cmd_str), proc.returncode, std_out, std_err)
                return (-1, "", msg)
            mi_int_ips = json.loads(std_out);
            mi_a_int_ip = mi_int_ips['mi_a_ip'];
            mi_b_int_ip = mi_int_ips['mi_b_ip'];
        elif std_err.find(not_allowed_str) >= 0:
            #msg += "%s - %s Failed - %s.\n%s" % (op_type, str(cmd_str), proc.returncode, std_err)
            target = "root@" + mi_ip_address
            cmd_str = DEFAULT_SSH_OPTIONS + ["-i", pem, target, lcm_util_cmd]
            proc = Popen(cmd_str, stdout=PIPE, stderr=PIPE)
            (std_out, std_err) = proc.communicate()
            if proc.returncode != 0:
                msg += "%s - %s Failed - %s.\n%s\n%s" % (op_type, str(cmd_str), proc.returncode, std_out, std_err)
                return (-1, "", msg)
            mi_int_ips = json.loads(std_out);
            mi_a_int_ip = mi_int_ips['mi_a_ip'];
            mi_b_int_ip = mi_int_ips['mi_b_ip'];
        elif std_err.find(invalid_choice_str) >= 0:
            # 'get_mi_int_ips' is a new option in R36 in later releases.
            # Handle SU from older releases to R36
            #msg += "%s - %s Failed - %s.\n%s" % (op_type, str(cmd_str), proc.returncode, std_err)
            mi_a_int_ip = "169.254.64.1"
            mi_b_int_ip = "169.254.65.1"

        if ((mi_a_int_ip == "") and (mi_b_int_ip == "")):
            msg += "\n%s Failed - %s.\n%s\n%s" % (cmd_str, proc.returncode, std_out, std_err)
            return (-1, "", msg)
    else:
        mi_int_ips = json.loads(std_out);
        mi_a_int_ip = mi_int_ips['mi_a_ip'];
        mi_b_int_ip = mi_int_ips['mi_b_ip'];

    # Return correct MI fixed IP
    cmd_str = DEFAULT_SSH_OPTIONS + ["-i", pem, user + "@" + mi_ip_address, "/opt/LSS/bin/lsalias"]
    proc = Popen(cmd_str, stdout=PIPE, stderr=PIPE)
    (std_out, std_err) = proc.communicate()

    if proc.returncode == 0:
        if std_out.find(mi_a_int_ip) != -1:
            return (0, mi_a_int_ip, msg)

        if std_out.find(mi_b_int_ip) != -1:
            return (0, mi_b_int_ip, msg)

    msg += "%s - '%s' Failed: %s\n%s" % (op_type, str(cmd_str), std_err, std_out)
    return (-1, "", msg)

# run the lcm_util command to get the mi external IP addresses
# return the MI A fixed, MI B fixed and MI float in that order
def run_lcm_util(user, valid_mi_ip, mi_int_fix_ip, pem, op_type):
    cpy_pem_lcmadm(user, valid_mi_ip, pem)

    retmap = attrdict({"mi_a_ip": 0, "mi_b_ip": 0, "mi_f_ip": 0, "msg": "", "returncode": 0})
    target = ""
    lcm_util_cmd = ""
    target = user + "@" + valid_mi_ip
    lcm_util_cmd  = "/opt/LSS/share/basecfg/fi/bin/lcm_util -a get_mi_ext_ips"

    ssh_string = DEFAULT_SSH_OPTIONS + ["-i", pem, target, lcm_util_cmd]
    proc = Popen(ssh_string, stdout=PIPE, stderr=PIPE)
    std_out, std_err = proc.communicate()
    if proc.returncode != 0:
        # Check if command allowed to run as 'root'
        not_allowed_str = user + ' is not allowed to execute'
        if (re.findall("Permission denied:\s+'/data0/FLD/lcm_util.log'", std_err)):
            retmap.msg += "%s - %s Failed - %s.\n%s" % (op_type, str(ssh_string), proc.returncode, std_err)
            lcm_util_cmd  = "sudo /opt/LSS/share/basecfg/fi/bin/lcm_util -a get_mi_ext_ips"
            cmd_str = DEFAULT_SSH_OPTIONS + ["-i", pem, target, lcm_util_cmd]
            proc = Popen(cmd_str, stdout=PIPE, stderr=PIPE)
            (std_out, std_err) = proc.communicate()
        elif std_err.find(not_allowed_str) >= 0:
            retmap.msg += "%s - %s Failed - %s.\n%s" % (op_type, str(ssh_string), proc.returncode, std_err)
            target = "root@" + valid_mi_ip
            cmd_str = DEFAULT_SSH_OPTIONS + ["-i", pem, target, lcm_util_cmd]
            proc = Popen(cmd_str, stdout=PIPE, stderr=PIPE)
            (std_out, std_err) = proc.communicate()

    rmv_pem_lcmadm(user, valid_mi_ip, pem)

    if proc.returncode == 0:
        mi_ips = json.loads(std_out)
        retmap.mi_a_ip  =  mi_ips['mi_a_ips'][0]
        retmap.mi_b_ip  =  mi_ips['mi_b_ips'][0]
        retmap.mi_f_ip  =  mi_ips['mi_f_ips'][0]
        return (retmap)
    
    retmap.returncode = proc.returncode
    retmap.msg += "%s - '%s' Failed: %s\n%s" % (op_type, ssh_string, std_out, std_err)

    return (retmap)

# copy pem file to lcmadm on MI
def cpy_pem_lcmadm(user, valid_mi_ip, pem):
    filename = os.path.basename(pem)
    dst_file = user + '@[' + valid_mi_ip + ']:$HOME/' + filename

    scp_string = [ 'scp', '-o', 'BatchMode=yes',             \
                          '-o', 'ConnectTimeout=30',          \
                          '-o', 'StrictHostKeyChecking=no',  \
                          '-i',  pem,                        \
                          pem,                               \
                          dst_file                           \
                 ]

    rc = Popen(scp_string, stdout=PIPE, stderr=PIPE)
    std_out, std_err = rc.communicate()

    return rc.returncode

# remove the pem file copied to lcmadm on MI
def rmv_pem_lcmadm(user, valid_mi_ip, pem):
    filename = os.path.basename(pem)
    rmt_cmd = "rm " + filename
    ssh_string = DEFAULT_SSH_OPTIONS + ["-i", pem, user + "@" + valid_mi_ip, rmt_cmd]
    rc = Popen(ssh_string, stdout=PIPE, stderr=PIPE)
    std_out, std_err = rc.communicate()

    return rc.returncode

