#!/usr/bin/python

DOCUMENTATION = '''
---
action_plugin: lcp_mi_ip_file.py
short_description: action plugin used to look up MI IP addresses and create a record of them.  

This plugin will create the mi_ip_file.json file
'''

import json      # json interpreter module
import os        # os access module

from ansible                import constants as C
from ansible.plugins.action import ActionBase
from ansible.errors         import AnsibleError

#display = Display()

class ActionModule(ActionBase):

    def run(self, tmp=None, task_vars=None):
        if task_vars is None:
            task_vars = dict()

        result = super(ActionModule, self).run(tmp, task_vars)

        # Default the return result
        result.update(dict(
            changed = False,
            rc      = 0,
            stderr  = '',
            stdout  = '',
        ))

        # Looking for 3 arguments to this action plugin
        # stackID : Stack string ID 
        # MI_A    : MI A external fixed IP
        # MI_B    : MI B external fixed IP
        # MI_F    : MI   external float IP

        if 'stackID' not in self._task.args:
            raise AnsibleError("'stackID' is a required argument.")
        stackID = self._task.args.get('stackID', None)

        if 'MI_A' not in self._task.args:
            raise AnsibleError("'MI_A' is a required argument.")
        MI_A = self._task.args.get('MI_A', None)

        if 'MI_B' not in self._task.args:
            raise AnsibleError("'MI_B' is a required argument.")
        MI_B = self._task.args.get('MI_B', None)

        if 'MI_F' not in self._task.args:
            raise AnsibleError("'MI_F' is a required argument.")
        MI_F = self._task.args.get('MI_F', None)

        # This action item does not fail
        result['changed'] = False

        {"stackID":{"MI_A":"1","MI_B":"2","MI_F":"3"}}
        # New Entry string
        new_entry_s = "{\"" + stackID + "\":{"              + \
                            "\"MI_A_ip\":\"" + MI_A + "\"," + \
                            "\"MI_B_ip\":\"" + MI_B + "\"," + \
                            "\"MI_F_ip\":\"" + MI_F + "\"}" + \
                      "}"

        # New Entry Object
        new_entry = json.loads(new_entry_s)

        # Does mi_ip_file.json exist
        if not os.path.exists('mi_ip_file.json'):

            # Enter new string into json
            jas = json.loads(new_entry_s)

            # Write new entry to local json IP file
            json_data_file = open('mi_ip_file.json','w')
            json.dump(jas, json_data_file)
            json_data_file.close

            return result

        # If mi_ip_file.json is empty
        if os.path.getsize('mi_ip_file.json') == 0:

            # Delete the empty file
            os.remove('mi_ip_file.json')

            # Enter new string into json
            jas.loads(new_entry_s)

            # Write new entry to local json IP file
            json_data_file = open('mi_ip_file.json','w')
            json.dump(jas, json_data_file)
            json_data_file.close

            return result

        # IP file exists and is not size 0
        with open('mi_ip_file.json', 'r') as json_data_file:
            file_entry_s = json_data_file.read().replace('\n', '')

        json_data_file.close

        # Confirm that the file json is valid
        if not is_valid_json(file_entry_s):
            # Delete the invalid json file
            os.remove('mi_ip_file.json')
            jas = json.loads('{}')
        else:
            jas = json.loads(file_entry_s)

        # add the new entry to the json
        jas.update(new_entry)

        json_data_file = open('mi_ip_file.json','w')
        json.dump(jas, json_data_file)
        json_data_file.close

        return result

def is_valid_json( json_string ):
    try:
        jtst = json.loads(json_string)
    except ValueError, e:
        return False

    return True

