This CSAR was generated to run in a CBAM managed cloud.
