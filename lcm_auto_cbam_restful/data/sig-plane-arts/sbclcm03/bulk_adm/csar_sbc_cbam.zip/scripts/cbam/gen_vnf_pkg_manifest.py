#!/usr/bin/python
#
# Name:
#	tl/pkg/csars/scripts/cbam/gen_vnf_pkg_manifest
#
# Description:
#	Generates and add manifest file to VNF package
#

import sys
import os
import shutil
import yaml
import argparse
import hashlib
import time
from gettext import gettext as _
from subprocess import Popen, PIPE

manifest_file_name = ""
# VNF package will include ETSI SOL001-SOL004 standard files as well as vendor specific artifacts
# VNF file name and manifest are added to the list later.
VNFD_SRC_LIST = ["LCM",
         "templates",
         "TOSCA-Metadata",
         "TOSCA-Definitions",
         "ChangeLog.txt",
         "Tests",
         "images",
         "Licenses"
     ]

SOL_EXTENDED_LIST = [
        "cbam-extensions"
     ]

DEPRECATED_TOSCA_VERSIONS = [
        "tosca_simple_profile_for_nfv_1_0_0_nokia", #Initial CBAM GA release
        "tosca_simple_profile_for_nfv_1_0_0_nokia_3_1_0",
        "tosca_simple_profile_for_nfv_1_0_0_nokia_3_2_0",
        "tosca_simple_profile_for_nfv_1_0_0_nokia_3_3_0"
    ]

#Not include content in manifest file since their path is known
SKIP_DIR_LIST = ["TOSCA-Definitions", "TOSCA-Metadata"]
vnfd_properties = {}
tosca_dict = {}

class attrdict(dict):
    """A dict whose items can also be accessed as member variables."""
    def __init__(self, *args, **kwargs):
        dict.__init__(self, *args, **kwargs)
        self.__dict__ = self

# Define run_cmd
def run_cmd(command):
    """ Module to handle unix commands/scripts while tracking error streams. """
    retCode = attrdict(
        { "returncode": 0,
          "std_err":"",
          "std_out":"",
          "cmd": ""
        })

    proc = Popen(command, shell = True, stdout = PIPE, stderr = PIPE)
    retCode.std_out, retCode.std_err = proc.communicate()
    retCode.returncode = proc.returncode
    return retCode

#
# Name: get_vnfd_properties
#
# Description: Read vnfd and return vnfd data
#
def get_vnfd_properties(artifacts_dir):
    global VNFD_SRC_LIST
    global manifest_file_name
    etsi_sol_pkg = False
    #Get VNF file name from TOSCA-Metadata/TOSCA.meta
    #File name is fixed in standards
    vnfd_properties = {}
    tosca_meta_file = artifacts_dir + "/TOSCA-Metadata/TOSCA.meta"
    if os.path.exists(tosca_meta_file) == False:
        msg = 'TOSCA.meta file does not exist: %s' % (tosca_meta_file)
        raise Exception(msg)

    tosca_dict = {}
    with open(tosca_meta_file, "r") as f:
        tosca_dict = yaml.load(f, Loader=yaml.SafeLoader)

    if ("Entry-Definitions" not in tosca_dict.keys()):
            msg = "Unable to find 'Entry-Definitions' in VNFD"
            raise Exception(msg)

    vnfd_file = os.path.join(artifacts_dir, tosca_dict["Entry-Definitions"])
    if os.path.exists(vnfd_file) == False:
        msg = 'VNFD file does not exist: %s' % (vnfd_file)
        raise Exception(msg)
    VNFD_SRC_LIST.append(tosca_dict["Entry-Definitions"])

    if ("Entry-Manifest" in tosca_dict.keys()):
        manifest_file_name = tosca_dict["Entry-Manifest"]
    else:
        # Generate manifest file name from vnfd file name per etsi SOL004
        tmp_file = tosca_dict["Entry-Definitions"]
        manifest_file_name = tmp_file[:tmp_file.rfind(".yaml")] + ".mf"
    VNFD_SRC_LIST.append(manifest_file_name)
    VNFD_SRC_LIST.append(manifest_file_name[:manifest_file_name.rfind(".mf")] + ".cert")

    vnfd_dict = {}
    with open(vnfd_file, "r") as f:
        vnfd_dict = yaml.load(f, Loader=yaml.SafeLoader)

    if (    ("topology_template" in vnfd_dict.keys())
        and ("substitution_mappings" in vnfd_dict["topology_template"].keys())
        and ("properties" in vnfd_dict["topology_template"]["substitution_mappings"].keys())):
        # Handle non-SOL001 VNFD format
        vnfd_properties = vnfd_dict["topology_template"]["substitution_mappings"]["properties"]
        etsi_sol_pkg = False
    elif ("imports" in vnfd_dict.keys()):
        # Handle SOL001 VNFD format
        vnfd_properties = vnfd_dict["dsl_definitions"]
        vnfd_properties["product_info_name"] = vnfd_properties["product_name"]
        etsi_sol_pkg = True
    else:
        msg = "Unable to get VNFD substitution mappings properties"
        raise Exception(msg)
    vnfd_properties["tosca_definitions_version"] = vnfd_dict["tosca_definitions_version"]

    return (etsi_sol_pkg, tosca_dict, vnfd_properties)

def update_workflows_if_needed(artifacts_dir):
    global vnfd_properties
    global tosca_dict
    workbooks2 = artifacts_dir + "/LCM/workbooks2"
    workbooks = artifacts_dir + "/LCM/workbooks"
    is_sol_or_cbam_compliant = (True if (("tosca_definitions_version" in vnfd_properties.keys())
          and (vnfd_properties["tosca_definitions_version"] not in DEPRECATED_TOSCA_VERSIONS)) else False)

    if (is_sol_or_cbam_compliant == True):
        #New tosca version that supports SOL003, use restructured workflows in 'workbooks2'
        if os.path.isdir(workbooks2):
            run_cmd("rm -rf " + workbooks)
            run_cmd("mv " + workbooks2 + " " + workbooks)
    else:
        # Old tosca version that only supports non-SOL003 workflows
        if os.path.isdir(workbooks2):
            run_cmd(" rm -rf " + workbooks2)

#
# Name: create_manifest_sha256
#
# Description: Creates manifest file
#
def create_manifest_sha256(artifacts_dir):
    mano_str = ""
    data_str = ""
    global VNFD_SRC_LIST
    global vnfd_properties
    global tosca_dict

    if os.path.exists(artifacts_dir) == False:
        msg = 'Directory does not exist: %s' % (artifacts_dir)
        raise Exception(msg)

    if ((vnfd_properties == {}) or (tosca_dict == {})):
        etsi_sol_pkg, tosca_dict, vnfd_properties = get_vnfd_properties(artifacts_dir)

    # Update 'workbooks' directory based on whether SOL001/SOL003 is supported
    update_workflows_if_needed(artifacts_dir)

    mano_str += "metadata:\n"
    mano_str += "   vnf_provider_id: %s\n" % (vnfd_properties["provider"])
    mano_str += "   vnf_product_name: %s\n" % (vnfd_properties["product_info_name"])
    mano_str += "   vnf_package_version: %s\n" % (vnfd_properties["descriptor_id"])
    mano_str += "   vnf_release_data_time: %s\n\n" % (time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime()))
    mano_str += "non_mano_artifact_sets::\n"
    mano_str += "   prv.nokia.cbam:\n"
    if etsi_sol_pkg == True:
        mano_str += "       Source: cbam-extensions/lcm.vnfd.extensions.yaml\n"

    #Delete any old manifest file
    manifest_file = artifacts_dir + "/" + manifest_file_name
    if os.path.exists(manifest_file) == True:
        os.remove(manifest_file)

    for root, dirs, files in os.walk(artifacts_dir):
        for filename in files:
            basename = os.path.relpath(root, artifacts_dir)
            y = basename.find("/")
            if y >= 0:
                top_dir = basename[:y].split()[0]
                if ((top_dir not in VNFD_SRC_LIST) or (top_dir in SKIP_DIR_LIST)):
                    continue
            elif (basename in SKIP_DIR_LIST):
                continue
            elif (basename not in VNFD_SRC_LIST):
                if (basename == "."):
                    if (filename not in VNFD_SRC_LIST):
                        continue
                else:
                    continue

            full_path = os.path.join(root, filename)
            rel_path = os.path.relpath(full_path, artifacts_dir)
            mano_str += "       Source: %s\n" % (rel_path)
            sha256_hash = hashlib.sha256()
            with open(full_path,"rb") as f:
                # Read and update hash string value in blocks of 4K
                for byte_block in iter(lambda: f.read(4096),b""):
                    sha256_hash.update(byte_block)
                data_str += "Source: %s\nAlgorithm: SHA-256\nHash: %s\n\n" % (rel_path, sha256_hash.hexdigest())

    mano_str += "\n"

    with open(manifest_file, "w") as f:
        f.write(mano_str)
        f.write(data_str)

def sign_manifest_file(work_dir, product_name, t_dict):
    if ("Entry-Manifest" in t_dict.keys()):
        manifest_fname = t_dict["Entry-Manifest"]
    else:
        tmp_file = t_dict["Entry-Definitions"]
        manifest_fname = tmp_file[:tmp_file.rfind(".yaml")] + ".mf"
    file_prefix = manifest_fname[:manifest_fname.rfind(".mf")]

    root_dir = work_dir + "/../.cert_dir"
    config_file = root_dir + "/openssl.cnf"
    private_key = root_dir + "/.priv.key.pem"
    public_key = root_dir + "/pub.key.pem"
    csr_request = root_dir + "/csr.pem"
    signed_cert = work_dir + "/" + file_prefix + ".cert"
    signature_file = root_dir + "/" + file_prefix + ".cms"
    manifest_file_path = work_dir + "/" + manifest_fname
    CA_CONFIG = (
        "# Directory and file locations.\n"
        "[ CA_default ]\n"
        "certs                  = " + root_dir + "/certs\n"
        "crl_dir                = " + root_dir + "/crl\n"
        "new_certs_dir          = " + root_dir + "/newcerts\n"
        "database               = " + root_dir + "/index.txt\n"
        "serial                 = " + root_dir + "/serial\n"
        "RANDFILE               = " + root_dir + "/.rnd \n"
        "\n"
        "[ req ]\n"
        "default_bits           = 4096\n"
        "default_keyfile        = " + private_key + "\n",
        "distinguished_name     = req_distinguished_name\n"
        "attributes             = req_attributes\n"
        "prompt                 = no\n"
        "output_password        =\n"
        "\n"
        "[ req_distinguished_name ]\n"
        "C                      = US\n"
        "ST                     = " + ("TX" if (product_name == "SBC") else "IL") + "\n"
        "L                      = " + ("Austin" if (product_name == "SBC") else "Naperville") + "\n"
        "O                      = Nokia\n"
        "OU                     = " + product_name + "\n"
        "CN                     = https://www.nokia.com\n"
        "\n"
        "[ req_attributes ]\n"
        "challengePassword      =\n")

    run_cmd("rm -rf " + root_dir)
    run_cmd("mkdir -p " + root_dir)
    config_str = "".join(CA_CONFIG)
    with open(config_file,"w") as f:
        f.write(config_str)

    COMMAND_LIST = [
            # Generate private key and CSR (Certificate Signing Request)
            "openssl req  -config " + config_file + " -nodes -new -x509 -days 7300 -sha256 -keyout " + \
                private_key + " -out " + csr_request,
            "chmod 600 " + private_key,

            # Review/Verify the Certificate file
            #openssl x509 -text -noout -in " + csr_request,

            # Genertate a Self-signed Certificate
            "openssl x509 -in " + csr_request + " -signkey " + private_key + " -sha256 -days 3650 -outform pem -out " + \
                signed_cert,
            "chmod 600 " + signed_cert,

            # Get public key from certificate
            #"openssl x509 -pubkey -noout -in " + signed_cert,

            # Generate manifest file signature
            "openssl cms -sign -in " + manifest_file_path + " -inkey " + private_key + \
                   " -signer " + signed_cert + " -outform PEM -nosmimecap -nodetach -nocerts -noattr -out " + \
                   signature_file,

            # Verify msg
            #"openssl cms -verify -in " + signature_file + " -inform PEM -CAfile " + signed_cert + " -certfile " + signed_cert + " -inkey " + public_key,
        ]

    for cmd in COMMAND_LIST:
        ret = run_cmd(cmd)
        if ret.returncode != 0:
            sys.exit(1)

    # Append signature to manifest file
    if os.path.exists(signature_file) == True:
        sig_data = ""
        with open(signature_file,"r") as f:
            sig_data = f.read()
        if ((sig_data != "") and (os.path.exists(manifest_file_path) == True)):
            with open(manifest_file_path,"a") as f:
                f.write(sig_data)

def unzip_pkg_to_dir(pkg, unzip_dir):
    if os.path.exists(unzip_dir) == True:
        shutil.rmtree(unzip_dir)

    ret = run_cmd("unzip " + pkg + " -d " + unzip_dir)
    if ret.returncode != 0:
        print "FAILED: '%s' std_err=%s:%s" % (ret.cmd, ret.returncode, ret.std_err)
        cleanup()
        sys.exit(1)

def get_base_parser():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('-v', '--vnf-pkg', help=_('VNF package.'))
    parser.add_argument('-c', '--csop-dir', help=_('CSOP dir.'))
    parser.add_argument('-h', '--help', action='store_true', help=argparse.SUPPRESS)
    return (parser)

parser = get_base_parser()
argv = sys.argv[1:]
(options, args) = parser.parse_known_args(argv)
if not args and options.help or not argv:
    parser.print_help()
    sys.exit(1)

if options.vnf_pkg != None:
    vnf_pkg = options.vnf_pkg
    if os.path.exists(vnf_pkg) == False:
        print "ERROR - unable to find VNF package: ", vnf_pkg
        sys.exit(1)

    CWDIR = os.getcwd()
    NEW_PKG_DIR = CWDIR + "/new_pkg"
    unzip_pkg_to_dir(vnf_pkg, NEW_PKG_DIR)
    create_manifest_sha256(NEW_PKG_DIR)
    if os.path.isdir(NEW_PKG_DIR):
        new_vnf_pkg = vnf_pkg[:vnf_pkg.rfind(".")] + ".updated.zip"
        cmdstr = "cd " + NEW_PKG_DIR + "; zip ../" + new_vnf_pkg + " -r * >/dev/null"
	ret = os.system(cmdstr)
    run_cmd("rm -rf " + NEW_PKG_DIR)
