#!/usr/bin/python
#
# Name:
#	tl/pkg/csars/scripts/cbam/csar2csopCBAM
#
# Description:
#	Generate a CBAM compliant csop.zip.
#	This version generates per-VM type nested template files.
#
#	Note that this script may have dependencies on the HOT
#	template file layouts in the csar.zip.
#
#	This script assumes
#	- Both VMs in a pair use the same subnets on the same vNICs.
#	- Cloud-assigned IP addresses are not supported.
#

import sys
import os
import shutil
import yaml
import json
import copy
import argparse
import csar2csopCOM
from gen_vnf_pkg_manifest import *

parser = argparse.ArgumentParser(description='Collect inputs.')
parser.add_argument('--s', '--csar_dir', required=True, metavar='csar', help='The base csar (input) directory.')
parser.add_argument('--o', '--csop_dir', required=True, metavar='csop', help='The base csop (output) directory.')
parser.add_argument('--b', '--base_file', required=True, metavar='base.hot', help='The base HOT file.')
parser.add_argument('--e', '--ext_file', required=True, metavar='JSONext', help='The JSON extension file.')
parser.add_argument('--i', '--instantiate_file', required=True, metavar='instantiate', help='The JSON instantiate parameters file.')
parser.add_argument('--v', '--vnfd_file', required=True, metavar='vnfd', help='The VNFD file.')
parser.add_argument('--m', '--meta_file', required=True, metavar='meta', help='The ToscaMetadata file.')
parser.add_argument('--n', '--netserv', required=False, default='Neutron', metavar='netserv', help='The cloud network service type.')
parser.add_argument('--d', '--disable_intsec', required=False, default='no', metavar='disable_intsec', help='Internal network security disabled.')
parser.add_argument('--l', '--load_image', required=False, default='Image', metavar='load_image', help='VM boot method [Image|Volume].')
parser.add_argument('--g', '--server_groups', required=False, default='false', metavar='server_groups', help='Per-VM pair/N+k group anti-affinity support.')
parser.add_argument('--t', '--template_version', required=False, default='kilo', metavar='template_version', help='OpenStack release ID string (e.g. \"kilo\")')
parser.add_argument('--a', '--additional_files', required=False, default='{}', metavar='additional_files', help='Optional additional files.')

args = parser.parse_args()

csar_dir = args.s
csop_dir = args.o
netserv = args.n
disable_intsec = args.d
addl_files = yaml.load(args.a, Loader=yaml.SafeLoader)

# Read the boot type argument.
bootype = args.l

# Note whether anti-affinity server groups are requested.
server_groups = args.g

# Get the template version value to use.
tvers = csar2csopCOM.hot_version(args.t)

vnfd_file_name = os.path.basename(args.v)
cbam_ext_file = os.path.basename(args.e)
cbam_instantiate_file = os.path.basename(args.i)
deploy_type = "CBAM"
if hasattr(args, 'n'):
	if args.n.startswith("CBAM_VMWARE"):
		deploy_type = args.n

if deploy_type == "CBAM":
    fname = args.b
    finfo = open(fname, 'r')
    basedata = yaml.load(finfo.read(), Loader=yaml.SafeLoader)
    finfo.close()
    new_basename = "LCM.hot.yaml"

    # The VM template files will be re-read many times and closed later.
    pairtemplatename = csar_dir + "/templates/kilo_vnfm/LCP-PairGroup.template.yaml"
    pairtemplatefile = open(pairtemplatename, 'r')

    nktemplatename = csar_dir + "/templates/kilo_vnfm/LCP-VMGroupMember.template.yaml"
    nktemplatefile = open(nktemplatename, 'r')

    # The FORMATXLATE file will also be updated.
    fmtxlatename = csar_dir + "/templates/kilo_vnfm/LCP-CBAM.template.yaml"
    fmtxlatefile = open(fmtxlatename, 'r');
    fmtxlatedata = yaml.load(fmtxlatefile.read())

    # Convert the extensions file to an ENV file for easier access.
    j2env = csar_dir + "/scripts/cbam/EXTjson2env"
    cmdstr = "chmod +x " + j2env
    ret = os.system(cmdstr)
    fname = csop_dir + "/../LCMenv"
    cmdstr = j2env + " " + args.e + " > " + fname
    ret = os.system(cmdstr)
    finfo = open(fname, 'r')
    envdata = yaml.load(finfo.read(), Loader=yaml.SafeLoader)
    finfo.close()

    # Read in the extensions file in case it needs to be modified.
    fname = args.e
    finfo = open(fname, 'r')
    extdata = yaml.load(finfo.read())
    finfo.close

# Rename the script destination directory.
target = csop_dir + "/LCM"
cmdstr = "mv -f " + csop_dir + "/scripts/LCM " + target
ret = os.system(cmdstr)

# Copy any additional scripts into the target directory.
SKIP_ADDTL_FILE_LIST = ["EXTjson2env", "csar2csopCBAM.py",
		"Tests", "ChangeLog.txt", "TOSCA-Definitions",
		"vnf_upgrade_pkg_gen.py",
		"gen_vnf_pkg_manifest.py"
	]
tdir = csar_dir + "/scripts/cbam"
for tfile in os.listdir(tdir):
	if tfile in SKIP_ADDTL_FILE_LIST:
		continue
	shutil.copy(tdir + "/" + tfile, target)

# Remove the scripts directory.
cmdstr = "rm -rf " + csop_dir + "/scripts"
ret = os.system(cmdstr)

# Get the template files.
# First remove the template files from the output.
cmdstr = "rm -rf " + csop_dir + "/templates/*"
ret = os.system(cmdstr)

# Copy the template files to the correct location.
if deploy_type == "CBAM":
    tdir = csar_dir + "/templates/kilo_vnfm"
    target = csop_dir + "/templates"
    for tfile in os.listdir(tdir):
	if tfile == os.path.basename(pairtemplatename) or tfile == os.path.basename(nktemplatename):
		continue
	if tfile == os.path.basename(fmtxlatename):
		continue
	shutil.copy(tdir + "/" + tfile, target)

# Add additional files.
target = csop_dir
shutil.copy(args.v, target + "/" + vnfd_file_name)

target = csop_dir + "/cbam_json"
cmdstr = "mkdir -p " + target
ret = os.system(cmdstr)
shutil.copy(args.i, target + "/" + cbam_instantiate_file)
shutil.copy(args.e, target + "/" + cbam_ext_file)

# Populate the metadata directory.
target = csop_dir + "/TOSCA-Metadata"
run_cmd("mkdir -p " + target)
shutil.copy(args.m, target + "/TOSCA.meta")

# Get vnfd properties
etsi_sol_pkg, tosca_dict, vnfd_properties = get_vnfd_properties(csop_dir)
is_cbam_or_sol_compliant = (True if (("tosca_definitions_version" in vnfd_properties.keys())
          and (vnfd_properties["tosca_definitions_version"] not in DEPRECATED_TOSCA_VERSIONS)) else False)

if deploy_type == "CBAM":
    # Loop through the resources in the base (master) HOT file.
    # Use a copy though so the original cn be modified as needed.
    basedata_copy = copy.deepcopy(basedata)

    # Collect resource group counts as we go.
    grp_type_counts = {"pair": {}, "N+k": {}}

    pvals = envdata["parameters"]["cbam"]["extensions"]
    for attr, rscdata_copy in basedata_copy["resources"].iteritems():

	# Get a reference to the real data.
	rscdata = csar2csopCOM.get_rscdata(basedata, attr)

	# Skip resources that are not VM pair types.
	if rscdata["type"] != os.path.basename(pairtemplatename) and rscdata["type"] != os.path.basename(nktemplatename):
		continue

	pdata = rscdata["properties"]

	# Save the tag for brevity.
	tag = pdata["group_tag"]
	rsc_pvals = pvals[tag]

	# Reset the template read to the start of the file
	# and get a copy of the contents.
	if rscdata["type"] == os.path.basename(pairtemplatename):
		templatefile = pairtemplatefile
		group_type = "pair"
		sidelist = ["A", "B"]
	else:
		templatefile = nktemplatefile
		group_type = "N+k"
		sidelist = ["A"]

		# Add a server group to the master hot file if it
		# has not already been done.
		sg_tag = tag + "_SG"
		if sg_tag not in basedata["resources"]:
			basedata["resources"][sg_tag] = {
				"type": "OS::Nova::ServerGroup",
				"properties": {
			  		"policies": ["anti-affinity"]
				}
			}

		# Set the SG parameter in the master HOT file.
		rscdata["properties"]["server_group"] = {"get_resource": sg_tag}

	if "count" in rscdata_copy["properties"]:
		# This is a resource group.
		grp_type_counts[group_type][tag] = rscdata_copy["properties"]["count"]
	else:
		# This must be the OAM pair.
		grp_type_counts[group_type][tag] = 1

	templatefile.seek(0)
	tdata = yaml.load(templatefile.read())

	tdata["description"] = "Generate resources for '" + tag + "' VMs."

	# Add the "anything but empty" constant parameter used
	# to format port fixed_ip attributes.
	abe = {"type": "json"}
	abe["description"] = "      Step 1 maps \"anything but empty\" (abe) to an empty string and an empty string to \"no_comma\".  Step 2 maps an empty string to: \"ip_address\": \" (i.e. part of ip_address json entry).  Step 3 maps an empty string to the closing quote of the json entry.  Step 4 maps an empty string to a comma and close quote."
	abe["default"] = { "step1": {"": "no_comma"}, "step2": {"": ", \"ip_address\": \""}, "step3": {"": "\""}, "step4": {"": ", \""} }

	tdata["parameters"]["abe2ip"] = abe
	resv_ips = {}
	aap_info = {}

	if server_groups == "true" and group_type == "pair":
		# Add an anti-affinity server group to the template.
		AAG_rsc = "NOKIA-LCP-AAG"
		tdata["resources"][AAG_rsc] = {
			"type": "OS::Nova::ServerGroup",
			"properties": {
			  "policies": ["anti-affinity"]
			}
		}

	if bootype == "Volume":
		# Add and set the boot type parameters for this VM type.
		# The size value is provided via YACT.
		tdata["parameters"]["boot_volume_size"] = {"type": "number", "description": "Boot volume size in GB. This should match the flavor boot disk size."}
		tdata["parameters"]["bootvol_type"] = {"type": "string", "description": "Source of boot image."}
		pdata["bootvol_type"] = {"get_param": ["cbam", "extensions", "bootvol_type"]}
		base_bootname = "NOKIA-LCP-BootVol"
		base_storagename = "NOKIA-LCP-Block-Storage"

	# See if pre-created internal security groups were provided.
	# If the were, add and set the parameters.
	if "int0_secgroup_uuid" in pvals:
		tdata["parameters"]["int0_secgroup_uuid"] = {"type": "string", "description": "Security group for internal network 0."}
		pdata["int0_secgroup_uuid"] = {"get_param": ["cbam", "extensions", "int0_secgroup_uuid"]}

	if "int1_secgroup_uuid" in pvals:
		tdata["parameters"]["int1_secgroup_uuid"] = {"type": "string", "description": "Security group for internal network 1."}
		pdata["int1_secgroup_uuid"] = {"get_param": ["cbam", "extensions", "int1_secgroup_uuid"]}

	# Update both VMs and associated resources.
	side2idx = {"A": "0", "B": "1"}

	if "storagevol_type" in envdata["parameters"]["cbam"]["extensions"]:
		# YACT has already set the parameter in the master
		# HOT file but we need to add it here and apply it.
		tdata["parameters"]["storagevol_type"] = {"type": "string", "description": "Storage volume type."}

		for side in sidelist:
			tdata["resources"]["NOKIA-LCP-Block-Storage"+side]["properties"]["volume_type"] = {"get_param": "storagevol_type"}

	for side in sidelist:
		sidx = side2idx[side]
		cfg = pdata["config_info"][sidx]

		# Add neutron ports for each vNIC.
		portrsc_list = []

		vnic_num = pdata["config_info"]["vnic_count"]
		# Prepare IPinfo output.
		t_ipinfo = ""
		p_ipinfo = {}
		assigned_ips = []
		aap_info[sidx] = {}
		predef_ipinfo = []
		first_ext = ""
		first_ext_ipcount = 0

		for vnic_idx in range(vnic_num):
			aap_info[sidx][vnic_idx] = []
			vidx_str = str(vnic_idx)
			if vnic_idx < 10:
				vidx_2digit = "0" + vidx_str
			else:
				vidx_2digit = vidx_str

			this_vnic = cfg["vnic_info"][vidx_str]

			# The 0th enty has general data for this vNIC.
			vdata = this_vnic[0]

			fixed_ips = []
			fixed_count = 0
			predef_ipinfo.insert(vnic_idx, [])
			assigned_ips.insert(vnic_idx, [])

			# External vNICs will have only the floating IPs
			# in the AAP, internals will still have the subnet CIDR.
			aap = aap_info[sidx][vnic_idx]
			alw_cnt = 0

			ip_count = int(vdata["count"])

			# The 0th entry has general information in it
			# so if data is read out it will be from 1 index
			# higher than the loop index.

			if ip_count == 0:
				# Must be an internal vNIC.
				if vnic_idx == 0:
					snet = "INTERNALnet0"
				else:
					snet = "INTERNALnet1"

				is_internal = True
				fixed_ips.insert(fixed_count, {"subnet": {"get_param": ["int_net_info", snet, "subnet_id"]}})
				fixed_count += 1

				aap.insert(alw_cnt, {"ip_address": "169.254.0.0/16"})
				alw_cnt += 1

			for ipidx in range(ip_count):
				if ipidx < 10:
					ipidx_str = "00" + str(ipidx)
				elif ipidx < 100:
					ipidx_str = "0" + str(ipidx)
				else:
					ipidx_str = str(ipidx)

				label = this_vnic[ipidx+1]["label"]
				snet = this_vnic[ipidx+1]["subnet"]

				if snet == "INTERNALnet0":
					is_internal = True
					fixed_ips.insert(fixed_count, {"subnet": {"get_param": ["int_net_info", snet, "subnet_id"]}})
					fixed_count += 1

					aap.insert(alw_cnt, {"ip_address": "169.254.0.0/16"})
					alw_cnt += 1

					continue
				elif snet == "INTERNALnet1":
					is_internal = True
					fixed_ips.insert(fixed_count, {"subnet": {"get_param": ["int_net_info", snet, "subnet_id"]}})
					fixed_count += 1

					aap.insert(alw_cnt, {"ip_address": "169.254.0.0/16"})
					alw_cnt += 1

					continue

				# External IP. Cloud-assigned IP addresses
				# are not supported.
				is_internal = False

				if first_ext == "":
					first_ext = vidx_str
					first_ext_ipcount = ip_count

				addr = {"get_param": ["usage_info", "group_info", {"get_param": "group_id"}, {"get_param": "group_index"}, str(sidx), "vnic_info", str(vnic_idx), "set_ips", label]}
				fipmap = {"subnet": {"get_param": ["ext_net_info", snet, "subnet_id"]}, "ip_address": addr}

				if netserv == "Neutron":
					# All IPs go in the fixed list,
					# all VIPs go in the AAP.
					fixed_ips.insert(fixed_count, fipmap)
					fixed_count += 1

					if "float" in label:
						if ":" in pvals["ext_net_info"][snet]["cidr"]:
							val = {"str_replace": {"template": "$ip/128", "params": {"$ip": addr}}}
						else:
							val = {"str_replace": {"template": "$ip/32", "params": {"$ip": addr}}}

						aap.insert(alw_cnt, {"ip_address": val})
						alw_cnt += 1
				elif netserv == "Nsip":
					# "Nsip" = "Neutron Single IP".
					# The AAP allows all IPs. Only a single
					# IP goes in the fixed_ips attribute.
					# The rest go on reserved ports.

					if (fixed_count == 0) and ("float" not in label or ip_count < 2):
						# Insert the entry.
						fixed_ips.insert(fixed_count, fipmap)
						fixed_count += 1

					else:
						# Save the IP info so they can
						# be reserved on a separate
						# Neutron port.
						if snet not in resv_ips:
							resv_ips[snet] = []
						resv_ips[snet].append(fipmap)

				elif netserv == "Cisco":
					# List individual VIPs only in the AAP.

					if "float" in label:
						# Cisco does not accept CIDR
						# formatted values.
						val = {"str_replace": {"template": "$ip", "params": {"$ip": addr}}}
						aap.insert(alw_cnt, {"ip_address": val})
						alw_cnt += 1
					else:
						fixed_ips.insert(fixed_count, fipmap)
						fixed_count += 1
				elif netserv == "Nuage":
					# For Nuage only one (v4) fixed IP goes
					# on the VM's port. The rest go in the
					# AAP and a separate neutron port not
					# connected to any VM.

					if ":" in pvals["ext_net_info"][snet]["cidr"]:
						iptype = "v6"
					else:
						iptype = "v4"

					if fixed_count == 0 and (iptype == "v4") and ("float" not in label or ip_count < 2):
						# Insert the entry.
						fixed_ips.insert(fixed_count, fipmap)
						fixed_count += 1

					else:
						# Nuage does not accept CIDR
						# formatted values.
						val = {"str_replace": {"template": "$ip", "params": {"$ip": addr}}}

						aap.insert(alw_cnt, {"ip_address": val})
						alw_cnt += 1

						# Save the IP info in case we need
						# to reserve these on a separate
						# Neutron port.
						if snet not in resv_ips:
							resv_ips[snet] = []
						resv_ips[snet].append(fipmap)

				# Save the IP info from the label in case
				# this port was pre-created.
				predef_ipinfo[vnic_idx].insert(ipidx, addr)

			# See if the port resource was pre-created.
			# This should never be true for internal networks.
			# If is pre-created for one group in the set the
			# it is pre-created for all.
			pval_vnic0 = rsc_pvals["0"]["0"]["vnic_info"]

			mac_address = ""

			if vidx_str in pval_vnic0 and "port_uuid" in pval_vnic0[vidx_str]:
				uuid = {"get_param": ["usage_info", "group_info", {"get_param": "group_id"}, {"get_param": "group_index"}, str(sidx), "vnic_info", vidx_str, "port_uuid"]}
				mac_address = {"get_param": ["usage_info", "group_info", {"get_param": "group_id"}, {"get_param": "group_index"}, str(sidx), "vnic_info", vidx_str, "mac_address"]}

				# Save the ID so it can be attached to the VM.
				portrsc_list.insert(vnic_idx, {"port": uuid})

				# Define the PortIpInfo output for this port.
				# We have to trust that the user listed the
				# same IPs on the port as are in the extensions.
				for ipidx in range(ip_count):
					assigned_ips[vnic_idx].insert(ipidx, {"list_join": ['', ["\"", predef_ipinfo[vnic_idx][ipidx], "\""]]})

			else:
				# Insert the port resource.
				vnic_rsc = "NOKIA-LCP-VM" + side + "port" + vidx_str
				# Save the resource name so it can be attached
				# to the VM.
				entry = {"port": {"get_resource": vnic_rsc}}
				portrsc_list.insert(vnic_idx, entry)

				portname = {"get_param": ["usage_info", "group_info", {"get_param": "group_id"}, {"get_param": "group_index"}, str(sidx), "vnic_info", vidx_str, "portname"]}

				# All subnets have to be on the same network.
				snet = this_vnic[1]["subnet"]
				# Default values.
				secgroups = [{"get_param": "sec_group"}]
				net_qos_policy = ""

				if snet == "INTERNALnet0":
					network = {"get_param": ["int_net_info", snet, "id"]}
					if "int0_secgroup_uuid" in pvals:
						secgroups = [{"get_param": ["int0_secgroup_uuid"]}]
				elif snet == "INTERNALnet1":
					network = {"get_param": ["int_net_info", snet, "id"]}
					if "int1_secgroup_uuid" in pvals:
						secgroups = [{"get_param": ["int1_secgroup_uuid"]}]
				else:
					network = {"get_param": ["ext_net_info", snet, "id"]}
					if "secgroup_uuid" in pvals["ext_net_info"][snet]:
						secgroups = [{"get_param": ["ext_net_info", snet, "secgroup_uuid"]}]
					if "net_qos_policy" in pvals["ext_net_info"][snet]:
						net_qos_policy = [{"get_param": ["ext_net_info", snet, "net_qos_policy"]}]

				if netserv == "Neutron" or netserv == "Nsip":
					# Use a generic IP address entry for the
					# external AAPs to support subnet growth.
					s = vdata["allowed_subnets"][0]
					if s == "INTERNALnet0":
						aap = [{"ip_address": "169.254.0.0/16"}]
					elif s == "INTERNALnet1":
						aap = [{"ip_address": "169.254.0.0/16"}]
					else:
						# External vNIC.
						aap = [{"ip_address": "0.0.0.0/0"}, {"ip_address": "::/0"}]

				elif is_internal == False:
					# External floating IPs are only
					# specified on side 0.
					aap = aap_info["0"][vnic_idx]

				tdata["resources"][vnic_rsc] = {
					"type": "OS::Neutron::Port",
					"properties": {
						"name": portname,
						"network": network,
						"replacement_policy": "AUTO",
						"binding:vnic_type": this_vnic[0]["binding_type"],
						"security_groups": secgroups,
						"allowed_address_pairs": aap,
						"fixed_ips": fixed_ips
					}
				}

				if netserv == "Nuage" and is_internal == True:
					# Port security is disabled at the
					# network level but a security group
					# is still required.
					tdata["resources"][vnic_rsc]["properties"]["port_security_enabled"] = "True"
				if net_qos_policy != "":
					tdata["resources"][vnic_rsc]["properties"]["qos_policy"] = net_qos_policy
				# Some network service types do not support
				# security groups on some ports.
				if (netserv == "Nuage" or netserv == "Cisco") and \
					(this_vnic[0]["binding_type"] == "direct" or \
				 	ip_count == 0):

					# If the security_groups attribute is
					# not set at all the port will get the
					# default security group applied. So we
					# have to set it to the empty list
					# instead of deleting it.
					if (netserv == "Cisco") or (this_vnic[0]["binding_type"] == "direct"):
						tdata["resources"][vnic_rsc]["properties"]["security_groups"] = []

					# The AAP should not be set.
					del tdata["resources"][vnic_rsc]["properties"]["allowed_address_pairs"]

				if is_internal == True and disable_intsec == "yes":
					if "allowed_address_pairs" in tdata["resources"][vnic_rsc]["properties"]:
						del tdata["resources"][vnic_rsc]["properties"]["allowed_address_pairs"]
					tdata["resources"][vnic_rsc]["properties"]["security_groups"] = []
					tdata["resources"][vnic_rsc]["properties"]["port_security_enabled"] = "False"

				# Even if none of the special cases above apply,
				# security enablement can be overridden at the
				# network level.

				if (snet in pvals["ext_net_info"]) and ("security_setting" in pvals["ext_net_info"][snet]):
					sset = pvals["ext_net_info"][snet]["security_setting"]

					if sset == "enabled":
						# Explicitly enable security.
						tdata["resources"][vnic_rsc]["properties"]["port_security_enabled"] = "True"
					elif sset == "disabled":
						tdata["resources"][vnic_rsc]["properties"]["port_security_enabled"] = "False"
						tdata["resources"][vnic_rsc]["properties"]["security_groups"] = []
						if "allowed_address_pairs" in tdata["resources"][vnic_rsc]["properties"]:
							del tdata["resources"][vnic_rsc]["properties"]["allowed_address_pairs"]

				# Define the PortIpInfo output for this port.
				assigned_ips.insert(vnic_idx, [])

				if ip_count == 0:
					assigned_ips[vnic_idx].insert(0, {"list_join": ['', ["\"", {"get_attr": [vnic_rsc, "fixed_ips", 0, "ip_address"]}, "\""]]})

				for ipidx in range(ip_count):
					assigned_ips[vnic_idx].insert(ipidx, {"list_join": ['', ["\"", {"get_attr": [vnic_rsc, "fixed_ips", ipidx, "ip_address"]}, "\""]]})


			if vnic_idx > 0:
				t_ipinfo += ",{"
			else:
				t_ipinfo += "{"

			key = "$ip_count" + vidx_2digit
			t_ipinfo += "\"count\": \"" + key + "\", "
			p_ipinfo[key] = ip_count

			key = "$btype" + vidx_2digit
			t_ipinfo += "\"binding_type\": \"" + key + "\", "
			p_ipinfo[key] = vdata["binding_type"]

			key = "$mac" + vidx_2digit
			t_ipinfo += "\"mac_address\": \"" + key + "\", "
			if mac_address != "":
				p_ipinfo[key] = mac_address
			else:
				p_ipinfo[key] = {"get_attr": [vnic_rsc, "mac_address"]}

			key = "$assgip" + vidx_2digit
			t_ipinfo += "\"assigned_ips\": [" + key + "], "
			p_ipinfo[key] = {"list_join": [',', assigned_ips[vnic_idx]]}

			key = "$l2info" + vidx_2digit
			t_ipinfo += "\"label2info\": [" + key + "]"
			p_ipinfo[key] = {}
			p_ipinfo[key]["list_join"] = []
			p_ipinfo[key]["list_join"].insert(0, ',')
			p_ipinfo[key]["list_join"].insert(1, [])
			tmp = {}
			tmp["str_replace"] = {}
			tmp["str_replace"]["params"] = {}


			# In some cases (e.g. SBC IMS IPs) the vnic may have
			# labels specified beyond the first "count" entries.
			# Bulk config needs this info even though those IPs
			# are not assigned on this port.

			lidx = 0
			t_labels = []
			for line in this_vnic:
				if "label" not in line:
					continue

				if lidx < 10:
					lstr = "$ip00" + str(lidx)
				elif lidx < 100:
					lstr = "$ip0" + str(lidx)
				else:
					lstr = "$ip" + str(lidx)

				t_labels.insert(lidx, "{\"label\": \"" + line["label"] + "\", \"subnet\": \"" + line["subnet"] + "\", \"ip\": \"" + lstr + "\"}")

				tmp["str_replace"]["params"][lstr] = {"get_param": ["usage_info", "group_info", {"get_param": "group_id"}, {"get_param": "group_index"}, str(sidx), "vnic_info", str(vnic_idx), "set_ips", line["label"]]}

				lidx += 1

			tmp["str_replace"]["template"] = ','.join(t_labels)

			p_ipinfo[key] = tmp

			t_ipinfo += "} "


		# Update other resources in the per-VM type template.
		rscname = "NOKIA-LCP-VM" + side
		vmrsc = tdata["resources"][rscname]
		vmprop = vmrsc["properties"]

		if server_groups == "true" and group_type == "pair":
			vmprop["scheduler_hints"] = {"group": {"get_resource": AAG_rsc}}
		# If booting from volume, update the server and
		# volume attachments.
		if bootype == "Volume":
			# Generate the boot volume.
			bootname = base_bootname+side
			storagename = base_storagename+side

			storage = tdata["resources"][storagename]["properties"]
			namestr = str(storage["name"])
			namemap = yaml.load(namestr.replace("storage", "boot"))
			tdata["resources"][bootname] = {
				"type": "OS::Cinder::Volume",
                                "depends_on": [storagename],
				"properties": {
					"image": copy.deepcopy(vmprop["image"]),
					"availability_zone": copy.deepcopy(storage["availability_zone"]),
					"name": namemap,
					"volume_type": {"get_param": "bootvol_type"},
					"size": {"get_param": "boot_volume_size"}
				}
			}

			if side == "B":
				tdata["resources"][bootname]["depends_on"].append(base_bootname+"A")

			# Clean up other resources.
			del tdata["resources"]["NOKIA-LCP-BlockAttach"+side]
			del vmprop["image"]
			vmprop["block_device_mapping_v2"] = [
				{
        				"device_name": "vda",
					"boot_index": 0,
					"volume_id": {"get_resource": bootname},
					"delete_on_termination": True
				},
				{
        				"device_name": "vdb",
					"boot_index": -1,
					"volume_id": {"get_resource": storagename},
					"delete_on_termination": True
				}
			]

			# Update other parts of the template.
			dep_cnt = len(vmrsc["depends_on"])
			vmrsc["depends_on"].insert(int(dep_cnt), bootname)
			tdata["parameters"]["bootvol_type"] = {"description": "Boot volume type value.", "type": "string"}

		# If a storage volume has been provided, delete the volume
		# declaration and references to it.
		# If is pre-created for one group in the set the
		# it is pre-created for all.
		if "storage_uuid" in rsc_pvals["0"]["0"]:
			tmp = "NOKIA-LCP-Block"
			vol = tmp + "-Storage" + side 
			del tdata["resources"][vol]
			attachname = tmp + "Attach" + side

			get_voluuid = {"get_param": ["usage_info", "group_info", {"get_param": "group_id"}, {"get_param": "group_index"}, str(sidx), "storage_uuid"]}

			# If boot from volume is also used the
			# attach resource has already been deleted
			# but the server has a block-device mapping instead.

			if attachname in tdata["resources"]:
				volattach = tdata["resources"][attachname]
				volattach["properties"]["volume_id"] = get_voluuid
				dep_cnt = len(volattach["depends_on"])
				for cnt in range(dep_cnt):
					if volattach["depends_on"][cnt] == vol:
						volattach["depends_on"].pop(cnt)
						break

			# Remove references to the storage volume resource.
			if bootype == "Volume":
				vmprop["block_device_mapping_v2"][1]["volume_id"] = get_voluuid

			vmprop["user_data"]["str_replace"]["params"]["$uuid_storage"] = get_voluuid

			# This will allow install checks in CLDbase to
			# continue to work. Other actions (like a heal
			# done via nova rebuild) may not work.
			vmprop["metadata"]["created_at"] = "now"

			dep_cnt = len(vmrsc["depends_on"])
			for cnt in range(dep_cnt):
				if vmrsc["depends_on"][cnt] == vol:
					vmrsc["depends_on"].pop(cnt)
					break

			bvol = tdata["resources"][bootname]
			dep_cnt = len(bvol["depends_on"])
			for cnt in range(dep_cnt):
				if bvol["depends_on"][cnt] == vol:
					bvol["depends_on"].pop(cnt)
					break

		# Delete the port resource groups.
		pgname = "NOKIA-LCP-VMportGroup" + side
		del tdata["resources"][pgname]

		# Delete depends_on references to the port resource groups.
		# Update references to the port resources.
		netlist = []
		dep_cnt = len(vmrsc["depends_on"])

		for cnt in range(dep_cnt):
			if vmrsc["depends_on"][cnt] == pgname:
				vmrsc["depends_on"].pop(cnt)
				break

		for cnt in range(len(portrsc_list)):
			# Attach the port the VM.
			entry = portrsc_list[cnt]
			netlist.insert(cnt, entry)

			# Add local resources to the depends_on list.
			if "get_resource" in entry["port"]:
				rscname = entry["port"]["get_resource"]
				vmrsc["depends_on"].insert(cnt+dep_cnt, rscname)

		vmprop["networks"] = netlist

		vmprop["user_data"]["str_replace"]["params"]["$ipinfo"] = {"str_replace": {"template": t_ipinfo, "params": p_ipinfo}}

		# Update the output value for this side.
		extPort = "NOKIA-LCP-VM" + side + "port" + first_ext

		out_fmt = ""
		outparams = {}
		for ipidx in range(first_ext_ipcount):
			if ipidx < 10:
				ipidx_str = "$ip00" + str(ipidx)
			elif ipidx < 10:
				ipidx_str = "$ip0" + str(ipidx)
			else:
				ipidx_str = "$ip" + str(ipidx)

			out_fmt += ipidx_str + ", "
			if extPort in tdata["resources"]:
				outparams[ipidx_str] = {"get_attr": [extPort, "fixed_ips", ipidx, "ip_address"]}
			else:
				outparams[ipidx_str] = assigned_ips[int(first_ext)][ipidx]

		# Remove the extra comma and whitespace.
		out_fmt = out_fmt[:-2]

		if first_ext_ipcount == 0:
			tdata["outputs"]["VM"+side+"-EXT_IPS"]["value"] = ""
		else:
			tdata["outputs"]["VM"+side+"-EXT_IPS"]["value"] = {"str_replace": {"template": out_fmt, "params": outparams}}

	if netserv == "Nuage" or netserv == "Cisco" or netserv == "Nsip":
		# Generate the reserved port neutron ports for the VM type.
		# First collect all the floating IP addresses.
		#
		# Nuage does not support IPV6-only ports. So for a given
		# network we will do 1 IPV4 and as many IPV6s as we
		# can on each port until we run out of IPV6.
		# This assumes that there are sufficient IPV4s to do this.

		net2snet = {}
		for sn, sninfo in pvals["ext_net_info"].iteritems():
			if sn not in resv_ips:
				continue
			if ":" in sninfo["cidr"]:
				sntype = "v6"
			else:
				sntype = "v4"
			if sninfo["id"] not in net2snet:
				net2snet[sninfo["id"]] = {"sn": sn, "v4": [], "v6": []}
			net2snet[sninfo["id"]][sntype].extend(resv_ips[sn])

		for net, netinfo in net2snet.iteritems():
			network = {"get_param": ["ext_net_info", netinfo["sn"], "id"]}
			pname = "Reserve_Port_" + tag + "_" + netinfo["sn"] + "_"

			v4start = 0
			v4cnt = len(netinfo["v4"])
			v6start = 0
			v6cnt = len(netinfo["v6"])
			port_idx = 0

			while (v6start+4) <= v6cnt:
				csar2csopCOM.resv_ip_port(tdata["resources"], pname+str(port_idx), pname+str(port_idx), network, netinfo["v4"][v4start:(v4start+1)]+netinfo["v6"][v6start:(v6start+4)])
				port_idx += 1
				v4start += 1
				v6start += 4

			v6_rem = v6cnt - v6start

			if v6_rem > 0:
				csar2csopCOM.resv_ip_port(tdata["resources"], pname+str(port_idx), pname+str(port_idx), network, netinfo["v4"][v4start:(v4start+1)]+netinfo["v6"][v6start:(v6start+v6_rem)])
				port_idx += 1
				v4start += 1

			while (v4start+5) <= v4cnt:
				csar2csopCOM.resv_ip_port(tdata["resources"], pname+str(port_idx), pname+str(port_idx), network, netinfo["v4"][v4start:(v4start+5)])
				port_idx += 1
				v4start += 5

			if v4start < v4cnt:
				csar2csopCOM.resv_ip_port(tdata["resources"], pname+str(port_idx), pname+str(port_idx), network, netinfo["v4"][v4start:])

	# Create the nested file data and update the master hot file.
	type = "nest_" + tag + ".yaml"
	csar2csopCOM.new_hot_file(csop_dir, type, tdata)
	rscdata["type"] = type

    # Close the template files.
    pairtemplatefile.close()
    nktemplatefile.close()

    # Update the format translate file.

    # Add Pair and N+K VM counts.
    tstr = "0"
    params = {}
    for tag in grp_type_counts["pair"]:
	tstr = tstr + " + $" + tag
	params["$" + tag] = grp_type_counts["pair"][tag]
    fmtxlatedata["outputs"]["total_vm_pairs"] = {
		"description": "String that will evaluate to the total number of VM pairs. Note that the 0th entry is always the OAM and as a static resource it does not have a dynamic count. Therefore it is hard-coded to 1 here.",
		"value": {"str_replace": {"template": tstr, "params": params}}
	}
    # Now N+k VMs.
    tstr = "0"
    params = {}
    for tag in grp_type_counts["N+k"]:
	tstr = tstr + " + $" + tag
	params["$" + tag] = grp_type_counts["N+k"][tag]
    fmtxlatedata["outputs"]["total_nk_vm_count"] = {
		"description": "String that will evaluate to the total number of N+k VMs.",
		"value": {"str_replace": {"template": tstr, "params": params}}
	}

    # Add the storage volume type.
    if "storagevol_type" in envdata["parameters"]["cbam"]["extensions"]:
	fmtxlatedata["outputs"]["storagevol_type"] = {
		"description": "Volume type for storage volumes.",
		"value": {"get_param": ["cbam", "extensions", "storagevol_type"]}
	}

    # Update the fmtxlate HOT file.
    csar2csopCOM.new_hot_file(csop_dir, fmtxlatename, fmtxlatedata)

    # Update the new copy of the master HOT file.
    csar2csopCOM.new_hot_file(csop_dir, new_basename, basedata)

    if netserv == "Nuage" or netserv == "Cisco":
	commonname = "LCP-Base.template.yaml"
	fname = csar_dir + "/templates/kilo_vnfm/" + commonname
	finfo = open(fname, 'r');
	commondata = yaml.load(finfo.read())
	finfo.close()

	cmdstr = "rm -rf " + csop_dir + "/templates/" + commonname
	ret = os.system(cmdstr)

	# Update the common resource file.
	commondata["resources"]["NOKIA-LCP-InternalNet0"]["properties"]["resource_def"]["properties"]["port_security_enabled"] = "False"
	commondata["resources"]["NOKIA-LCP-InternalNet1"]["properties"]["resource_def"]["properties"]["port_security_enabled"] = "False"

	csar2csopCOM.new_hot_file(csop_dir, commonname, commondata)

    # Update the heat template version for all files.
    tsrc = csop_dir + "/templates/"
    cmdstr = "for f in $(ls " + tsrc + "*.yaml); do chmod +w ${f}; /bin/sed -i -e \"s/^heat_template_version:*$/heat_template_version: " + tvers + "/g\" ${f}; done"
    ret = os.system(cmdstr)

    # Update the JSON extensions if needed.
    if bootype == "Volume":
	for val in extdata["extensions"]:
		if val["name"] == "bootvol_type":
			break

	# If the bootvol_type key was not found, add it.
	if val["name"] != "bootvol_type":
		extdata["extensions"].append({"name": "bootvol_type", "value": "tripleo-ceph"})

	target = csop_dir + "/cbam_json/LCM_extensions.json"
	outfile = open(target, 'w')
	outfile.write(json.dumps(extdata, indent=4))
	outfile.close

# Copy and rename any additional files to the requested locations.
for path, src in addl_files.iteritems():
	dir = os.path.dirname(path)
	file = os.path.basename(path)
	dest = csop_dir + "/" + dir
	cmdstr = "mkdir -p " + dest + ";cp " + src + " " + dest + "/" + file
	ret = os.system(cmdstr)

if deploy_type == "CBAM":
    if is_cbam_or_sol_compliant == True:
        # Now update FORMATXLATE file
        # Note that this code is added here to avoid the dep with other
        # R36 IMRs
        fmtxlatedata = {}
        fmtxlatename = csop_dir + "/templates/LCP-CBAM.template.yaml"
        with open(fmtxlatename, 'r') as f:
            try:
                fmtxlatedata = yaml.load(f.read(), Loader=yaml.SafeLoader)
            except yaml.YAMLError as exc:
                raise exc

        #Update 'defaults'
        usage_info_params = fmtxlatedata["outputs"]["usage_info"]["value"]
        if "defaults" in usage_info_params.keys():
            fmtxlatedata["outputs"]["usage_info"]["value"]["defaults"] = {"get_param": ["lcp", "defaults"]}

        #Update 'group_info'
        if "group_info" in usage_info_params.keys():
            for grp_id, grp_params in usage_info_params["group_info"].iteritems():
                fmtxlatedata["outputs"]["usage_info"]["value"]["group_info"][grp_id] = {
                        "get_param": ["lcp", "group_info", {"get_param": ["vmtype_list", int(grp_id)]}]}

        # Update 'ext_net_info'
        fmtxlatedata["outputs"]["ext_net_info"]["value"] = {"get_param": ["lcp", "ext_net_info"]}

        fmtxlatedata["parameters"]["lcp"] = {"type": "json",
                    "description": "Values provided via the CBAM VNFD and input files."}

        csar2csopCOM.new_hot_file(csop_dir, fmtxlatename, fmtxlatedata)

# Generate a vnf_pkg.zip file to make installation easier.
# Base the name off the system prefix.
zipdir = "vnf_pkg"
vnf_pkg_name = zipdir + ".zip"
product_name = vnfd_properties["product_name"]
if product_name.upper() == "SBC":
    vnf_pkg_name = "Nokia_SBC_sig_VNF_Package.zip"
elif product_name == "SGSIWF":
    vnf_pkg_name = "Nokia_9380_WCS_VNF_Package.zip"
elif product_name != "":
    vnf_pkg_name = "Nokia_" + product_name.upper() + "_VNF_Package.zip"
if os.path.isdir(csop_dir + "/" + zipdir):
	cmdstr = "cd " + csop_dir + "/" + zipdir + "; zip ../" + vnf_pkg_name + " -r * >/dev/null"
	ret = os.system(cmdstr)

# Check if "ChangeLog.txt" exist
change_log_file = csar_dir + "/scripts/cbam/ChangeLog.txt"
if os.path.exists(change_log_file) == False:
    # Create empty changeLog file
    open(csop_dir + "/ChangeLog.txt", 'a').close()
else:
    run_cmd("cp -r " + change_log_file + " " + csop_dir)

#Add dummy image file to VNF package
image_suffix = "_image.qcow2"
if deploy_type.startswith("CBAM_VMWARE"):
    image_suffix = "_image.vmdk"
image_file = csop_dir + "/images/" + (product_name.lower() if (product_name != "") else "fake") + image_suffix
if os.path.exists(image_file) == False:
    run_cmd("> " + image_file)

cbam_ext_dir = os.path.dirname(csop_dir) + "/cbam-extensions"
run_cmd("rm -rf " + csop_dir + "/cbam-extensions")
if etsi_sol_pkg == True:
    # Generate SOL compliant VNF package
    run_cmd("cp -r " + csar_dir + "/scripts/cbam/TOSCA-Definitions" + " " + csop_dir)
    run_cmd("cp -r " + cbam_ext_dir + " " + csop_dir)

    for src in SOL_EXTENDED_LIST:
        file_path = csop_dir + "/" + src
        run_cmd("cd " + csop_dir + "; zip -r " + vnf_pkg_name + " " + src)

#Add Test scripts
run_cmd("cp -r " + csar_dir + "/scripts/cbam/Tests" + " " + csop_dir)

#Add License files
licenses_dir = csop_dir + "/Licenses"
if not os.path.isdir(licenses_dir):
    run_cmd("mkdir " + licenses_dir)
license_str = "# Please update with 'Feature' and 'Capacity' License key(s)\n"
license_str += '"Feature License":\n'
license_str += '"Capacity  License":\n'
with open(licenses_dir + "/Licenses.txt", "w") as f:
    f.write(license_str)

#Add upgrade.json file to aid with VNF PKG upgrade with SOL001/SOL003
update_json_file = csop_dir + "/cbam_json/LCM_pkg_upgrade_api4.json"
if (is_cbam_or_sol_compliant == True):
    upgrade_dict = {"apiVersion": 4.0}
    with open(update_json_file, "w") as f:
        f.write(json.dumps(upgrade_dict, sort_keys=False, indent=2, ensure_ascii=False))
elif (os.path.exists(update_json_file) == True):
    run_cmd("rm -rf " + update_json_file)

# Generate manifest file
# CBAM will ignore manifest file if SOL is not supported
create_manifest_sha256(csop_dir)
sign_manifest_file(csop_dir, product_name, tosca_dict)

for src in VNFD_SRC_LIST:
    run_cmd("cd " + csop_dir + "; zip -r " + vnf_pkg_name + " " + src)

 
