#!/usr/bin/python
#
# Name:
#	tl/pkg/csars/scripts/csar2csopCOM
#
# Description:
#	Common functions for csar2csop scripts.
#

import sys
import os
import yaml
import json
import re
import datetime

# Name:
#	get_rscdata()
#
# Description:
#	Get the attributes of a resource or resource group member.
#

def get_rscdata(basedata, tag):

	if "resource_def" in basedata["resources"][tag]["properties"]:
		rscdata = basedata["resources"][tag]["properties"]["resource_def"]
	else:
		rscdata = basedata["resources"][tag]

	return rscdata

# Name:
#	remove_defaults()
#
# Description:
#	Remove default settings from parameters in this HOT file.
#

def remove_defaults(basedata):

	for p, pval in basedata["parameters"].iteritems():
		if "default" in pval:
			del pval["default"]

# Name:
#	remove_constraints()
#
# Description:
#	Remove constraint settings from parameters in this HOT file.
#

def remove_constraints(basedata):

	for p, pval in basedata["parameters"].iteritems():
		if "constraints" in pval:
			del pval["constraints"]

# Name:
#	new_hot_file()
#
# Description:
#	Generate a HOT template file "name" with content from "source"
#	in the templates directory for the provided csop base directory.
#

def new_hot_file(dir, name, yamlsrc):
	# Make sure the templates directory exists.
	target = dir + "/templates"

	if not os.path.exists(target):
		os.makedirs(target)

	outstr = ""

	today = datetime.date.today()
	outstr += "## Copyright: Nokia Inc. " + str(today.year) + "\n"
	outstr += "## Version: " + str(today) + "-v01\n\n"

	outstr += "## Name: \"" + name + "\"\n"
	outstr += "## Description: HOT Template File\n\n"

	outstr += "heat_template_version: " + str(yamlsrc["heat_template_version"]) + "\n\n"

	# Generate yaml output without aliases.
	yaml.dumper.SafeDumper.ignore_aliases = lambda self, data: True

	for key in ["description", "parameters", "resources", "outputs"]:
		# AT&T has special formatting requirements for
		# network cloud port value_specs.
		if key not in yamlsrc:
			continue

		if key != "resources":
			tmpstr = yaml.dump(yamlsrc[key], indent=2, width=float("inf"), default_flow_style=False, Dumper=yaml.dumper.SafeDumper)
			outstr += key + ":\n  " + "  ".join(tmpstr.splitlines(True)) + "\n"
			continue

		# Special formatting for resources.
		outstr += key + ":\n"
		for id, rsc in yamlsrc[key].iteritems():
			if rsc["type"] != "OS::Neutron::Port":
				tmpstr = yaml.dump(rsc, indent=2, width=float("inf"), default_flow_style=False, Dumper=yaml.dumper.SafeDumper)

				outstr += "  " + id + ":\n    " + "    ".join(tmpstr.splitlines(True)) + "\n"
				continue

			# Special formatting for OS::Neutron::Port
			outstr += "  " + id + ":\n"
			for attr, aval in rsc.iteritems():
				if attr != "properties":
					outstr += "    " + attr + ": " + json.dumps(aval) + "\n"
					continue

				outstr += "    " + attr + ":\n"

				for p, pval in aval.iteritems():
					tmpstr = json.dumps(pval)
					if p == "value_specs":
						outstr += "      " + p + ":\n        " +  "      ".join(tmpstr.splitlines(True)) + "\n"

					else:
						outstr += "      " + p + ": " + tmpstr + "\n"
			outstr += "\n"

	basename = os.path.basename(name)
        output = target + "/" + basename
        outfile = open(output, 'w')
        outfile.write(outstr)
        outfile.close()

# Name:
#	new_env_file()
#
# Description:
#	Generate an ENV template file "name" with content from "source"
#	in the templates directory for the provided csop base directory.
#

def new_env_file(dir, name, yamlsrc, basedata):

	# Make sure the templates directory exists.
	target = dir + "/templates"

	if not os.path.exists(target):
		os.makedirs(target)

	outstr = ""
	today = datetime.date.today()
	outstr += "## Copyright: Nokia Inc. " + str(today.year) + "\n"
	outstr += "## Version: " + str(today) + "-v01\n\n"

	outstr += "## Name: \"" + name + "\"\n"
	outstr += "## Description: Environment Template\n"

	# To accomodate AT&T requirements most of these values should
	# be YAML formatted but JSON types should be formatted as JSON
	# instead of YAML dictionaries (OpenStack Heat is fine with any
	# of these formats).

	# Generate yaml output without aliases.
	yaml.dumper.SafeDumper.ignore_aliases = lambda self, data: True

	outstr += "parameters:\n\n"

	for category in ["PSEUDO-CONSTANTS", "SITE-SPECIFIC", "parameters"]:

		if category not in yamlsrc:
			continue

		if category != "parameters":
			outstr += "##------------------------------------------------\n"
			outstr += "## " + category + ":\n\n"

		pinfo = basedata["parameters"]
		pvals = yamlsrc[category]

		for p in sorted(pvals):
			outstr += "  " + p + ": "
			if pinfo[p]["type"] == "json":
				outstr += json.dumps(pvals[p]) + "\n"
			elif pinfo[p]["type"] == "number":
				outstr += str(pvals[p]) + "\n"
			elif pinfo[p]["type"] == "comma_delimited_list":
				outstr += "\n"
				tmpstr = yaml.dump(pvals[p], width=float("inf"), default_flow_style=False, default_style='"', Dumper=yaml.dumper.SafeDumper)
				for line in tmpstr.splitlines():
					outstr += "    " + line + "\n"
			else:
				outstr += "'" + "".join(pvals[p].splitlines()) + "'\n"
			outstr += "\n"
		outstr += "\n"

	basename = os.path.basename(name)
        output = target + "/" + basename
        outfile = open(output, 'w')
        outfile.write(outstr.replace("...", ""))
        outfile.close()

# Name:
#	net2contrail
#
# Description:
#	Change the internal network to a contrail resource.
#
def net2contrail(rsc):

	rsc["type"] = "OS::ContrailV2::VirtualNetwork"
	prop = rsc["properties"]
	del prop["admin_state_up"]
	del prop["shared"]
	prop["is_shared"] = "False"
	vnp = {}
	vnp["virtual_network_properties_rpf"] = "disable"
	vnp["virtual_network_properties_forwarding_mode"] = "l2_l3"
	prop["virtual_network_properties"] = vnp

# Name:
#	gen_internal_hostIPs
#
# Description:
#	Generate a list of internal host IP addresses for the provided
#	compute value.
#
def gen_internal_hostIPs(compute, ip_list, ip_count):

	# The possible host internal IPs are:
	#	169.254.[0|1|16|17|32|33|48|49|64|65].<compute>/32
	# The segment value determines which of the 3rd octet
	# values apply. For legacy systems:
	#	segment = member index
	#	compute = group index
	# Since we don't know those actual member index at this time,
	# we will add all possible 3rd octet values (it's harmless to have
	# extras).

	for octet3 in ["0", "1", "16", "17", "32", "33", "48", "49", "64", "65"]:
		ipstr["ip_address"] = "169.254." + octet3 + "." + cval + "/32"
		ip_list.insert(ip_count, copy.copy(ipstr))
		ip_count += 1

# Name:
#	gen_internal_serviceIPs
#
# Description:
#	Generate a list of internal IP addresses for a
#	pool type (numeric value) and pool ID.
#
def gen_internal_serviceIPs(poolType, poolId, ip_list, ip_count):

	# Internal service IPs are:
	# fixed:
	# 	169.254.(128+svctype).(2*poolId+membernum)/32
	# float:
	#	169.254.(192+svctype).(poolId)/32 (first come first served)
	#
	# We will generate all the IPs for both sides of a mated pair
	# since we don't know which VM is which here and and can't
	# do arithmetic in heat.

	ipstr = {}

	# Fixed internals.
	ipstr["ip_address"] = "169.254." + str(128+poolType) + "." + str(2*poolId) + "/32"
	ip_list.insert(ip_count, copy.copy(ipstr))
	ip_count += 1

	ipstr["ip_address"] = "169.254." + str(128+poolType) + "." + str(2*poolId+1) + "/32"
	ip_list.insert(ip_count, copy.copy(ipstr))
	ip_count += 1

	# Floating IP.
	ipstr["ip_address"] = "169.254." + str(192+poolType) + "." + str(poolId) + "/32"
	ip_list.insert(ip_count, copy.copy(ipstr))
	ip_count += 1

# Name:
#	resv_ip_port()
#
# Description:
#	Generate a reserved IP address port.
#

def resv_ip_port(rscdata, rscname, name, network, ipmap):

	rscdata[rscname] = {
		"type": "OS::Neutron::Port",
		"properties": {
			"name": name,
			"network": network,
			"replacement_policy": "AUTO",
			"security_groups": [],
			"fixed_ips": ipmap
		}
	}

# Name:
#	ip_label2param()
#
# Description:
#	VMtype + network role + VM side + IP usage label
#	to IP parameter name.
#
#	IP labels have several parts. Some are optional. E.g.
#	"servicetype=ims-0;float;nitype=published;subnet=accessv4;VM=pair:cscf:5:0:0"
#
#	To work as a parameter name all special characters must be
#	removed. Removing redundant data (such as service type if it
#	matches the VM type) helps shorten the result.
#

def ip_label2param(vmtype, net_role, type, label):

	# AT&T requires the network_role values to be from a provided list.
	# In general those values are used in the gDIF and passed on through.
	# The exception is the "duplex" subnets. They still need to be
	# tagged as duplex for bulk load but that tag should not appear
	# in most HOT file parameters.
	network_role = re.sub(r'(_duplex)', "", net_role)

	if "float" not in label:
		# MSO configurations only use 1 fixed IP per port
		# so follow the default convention.
		if type == "v6":
			pname = vmtype + "_" + network_role + "_v6_ips"
		else:
			pname = vmtype + "_" + network_role + "_ips"
		return(pname)

	ltag = re.sub("[:;]", "_", label)
	ltag = re.sub("\-", "", ltag)
	ltag = ltag.replace("servicetype="+vmtype, "")
	ltag = ltag.replace("servicetype=", "")
	ltag = ltag.replace("subnet="+net_role, "")
	ltag = ltag.replace("subnet=", "")
	ltag = ltag.replace("nitype=", "")
	ltag = ltag.replace("VM=", "")
	# Now replace any remaining '=' symbols.
	ltag = ltag.replace("=", "_")
	# Remove all underscores to avoid ASDC processing issues.
	ltag = ltag.replace("_", "")
	if type == "v6":
		pname = vmtype + "_" + network_role + "_" + ltag + "_v6_vips"
	else:
		pname = vmtype + "_" + network_role + "_" + ltag + "_vips"

	pname = pname.replace("__", "_")
	pname = re.sub("_$", "", pname)

	return(pname)

# Name:
#	hot_version()
#
# Description:
#	Map an identifying string to the appropriate HOT version string.

def hot_version(vers_id):
	vid = vers_id.lower()

	map = {
		"kilo": "2015-04-30",
		"liberty": "2015-10-15",
		"mitaka": "2016-04-08",
		"newton": "2016-10-14",
		"ocata": "2017-02-24",
		"pike": "2017-09-01",
		"queens": "2018-03-02",
		"rocky": "2018-08-31",
		"": ""
	}

	return(map[vid])

