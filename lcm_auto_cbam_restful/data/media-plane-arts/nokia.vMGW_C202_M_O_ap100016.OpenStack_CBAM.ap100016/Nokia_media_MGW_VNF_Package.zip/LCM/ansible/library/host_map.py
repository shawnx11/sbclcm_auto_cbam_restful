#! /usr/bin/python
#
# host_map.py
# ---------------
# Script to manage the map table between host accounts and  v7510 SCM vm-accounts in RMS platform
# It is called by S99Local
# 24-Dec.17 miao zhanyong, draft version:
#       add an entry/delete an entry/loop the map table/get the vm-account with specify host account user name
#
#

import sys, os, getopt, filecmp, string
import json
import re
import commands
import hashlib

MAP_TABLE_PATH = os.path.dirname(os.path.realpath(__file__)) + "/../roles/config_drive/media/"
MAP_TABLE_NAME = MAP_TABLE_PATH + "host-table.json"

def usage():
    print "Usage:     host_map.py -a {add|delete|clear|get-vm-name|checkhost|show|get_count}"
    print "           [-h <host-user-name>] [-v <vm-user-name>] [-p <passphrase>] -V"

def load_table():
    if os.path.exists(MAP_TABLE_NAME):
        try:
            with open(MAP_TABLE_NAME) as table_fd:
                table_js = json.load(table_fd)
                return table_js
        except Exception as ex:
            print ex
            return {}
    else:
        return {}


def store_table(table_js):
    if isinstance(table_js, dict):
        try:
            with open(MAP_TABLE_NAME, 'w') as table_fd:
                json.dump(table_js, table_fd, indent=4)
                return 0
        except Exception as ex:
            print("ERROR: store table raise exception " + str(ex))
            return -1
    else:
        print ("ERROR: invalid data " + type(table_js))
        return -2

def show_table():
    table = load_table()
    if (len(table) == 0):
        print "the table is null"
        return
    for x in table.items():
         print x
    print "count:" + str(len(table.items()))

def clear_table():
    table = load_table()
    if (len(table) != 0):
        table.clear()
        store_table(table)

def get_count():
    table = load_table()
    print len(table)

def add_entry(h_username, v_username, passphrase):
    table = load_table()
    md5 = hashlib.md5() 
    md5.update(passphrase) 
    passvalue = md5.hexdigest() 
            
    if (table.has_key(h_username)):
        table[h_username]['username'] = v_username
        table[h_username]['passphrase'] = passvalue
    else:
        value = {'username': v_username, 'passphrase':passvalue}
        table[h_username]= value
    store_table(table)

def del_entry(h_username, passphrase):
    table = load_table()
    if (table.has_key(h_username)):
        md5 = hashlib.md5()
        md5.update(passphrase)
        passvalue = md5.hexdigest()
        if (table[h_username]['passphrase'] == passvalue):
            table.pop(h_username)
            return store_table(table)
        else:
           print "please input the right passphrase\n"
           return -1
    return 0
    
def check_exist(h_username):
    table = load_table()
    return (table.has_key(h_username))
    
def get_vmusername(h_n=''):
    table = load_table()
    if (len(table) == 0):
        return "cloud-user"
    if h_n == '' or not h_n:
        for key, value in table.items():
            if value['username'] != '':
                return value['username'];
    else:
        if table.has_key(h_n) and table[h_n]['username'] != '':
            return table[h_n]['username']
    return None

def test():
    show_table()
    add_entry("host_1", "vm_1", "abc")
    add_entry("host_2", "vm_2", "abc")
    add_entry("host_3", "", "abcd")

    show_table()
    if (check_exist("host_1")):
        print "host_1 is in the table\n"
    else:
        print "host_1 is not in the table\n"
    print "host_2 vm name: "+ get_vmusername("host_2")
    print "dynamic vm name: "+ get_vmusername()
    
    del_entry("host_1", "abdc")
    show_table()
    return (0)

def main(argv):
    action = None
    verbose = False
    host_un = None
    vm_name = None
    passph = None

    try:
        opts, args = getopt.getopt(argv[0:],
                    'Va:h:v:p:',
                    [ 'verbose', 'action=', 'host-user-name=', 'vm-user-name=', 'passphrase=', 'help'])
#        print opts + args
    except getopt.GetoptError as err:
        print('ERROR: Invalid arguments: ' + str(err))
        usage()
        sys.exit(1)

    for opt, arg in opts:
        #print("opt: %s, arg: %s"%(opt,arg))
        if opt == '--help':
            usage()
            sys.exit(0)
        if opt in ('-V', '--verbose'):
            verbose = True
        #    print("verbose: %s"%verbose)
        elif opt in ('-a', '--action'):
            action = arg
        #    print("action: %s"%action)
        elif opt in ('-h', '--host-user-name'):
            host_un = arg
        #    print("host_un: %s"%host_un)
        elif opt in ('-v', '--vm-user-name'):
            vm_name = arg
        #    print("vm_name: %s"%vm_name)
        elif opt in ('-p', '--passphrase'):
            passph = arg
        #    print("passph: %s"%passph)
        else:
            usage()
            sys.exit(1)

    if not action:
        print('ERROR: Please specify action')
        sys.exit(1)
    if action in ('add'):
        if( (not host_un) or (not vm_name) or (not passph)):
            print('ERROR: please specify the parameter')
            sys.exit(1)
        return add_entry(host_un, vm_name, passph)
    elif action in ('delete'):
        if( (not host_un) or (not passph)):
             print('ERROR: please specify the parameter')
             sys.exit(1)
        return del_entry(host_un, passph)
    elif action in ('get-vm-name'):
        vm_name =  get_vmusername(host_un)
        if not vm_name:
            sys.exit(1);
        print vm_name
        return 0
    elif action in ('checkhost'):
        if( not host_un):
            print('ERROR: please specify the parameter host name')
            sys.exit(1)
        print check_exist(host_un)
    elif action in ('show'):
        show_table()
    elif action in ('get_count'):
        get_count()
    elif action in ('clear'):
        clear_table()
    else:
         print('ERROR: invalide action '+action)
         sys.exit(1)
    return 0    

if  __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))

