#!/usr/bin/env python2
''' 
resource data crosscheck:
    syntex check
    logical check

'''

from __future__ import print_function
from io import FileIO
import yaml
import getopt
import sys


def _is_str(obj):
  '''judge if obj is a string (str or unicode)'''
  try:
    return isinstance(obj, basestring)
  except NameError:
    return isinstance(obj, str)

def load_yaml_file(filename):
    try:
        istream = FileIO(filename, 'r')
        cloud_data = yaml.load(istream)
        istream.close()
        if not cloud_data:
            print(filename + ' is empty')
            return None

        return cloud_data
    except Exception as ex:
        print('ERROR: Exception raised in load_yaml_file:' + str(ex))
        return None

def check_platform_syntax(cloud_data):
    if 'platform' not in cloud_data:
        print('ERROR: platform is not defined')
        return False
    if not _is_str(cloud_data['platform']):
        print('ERROR: platform should be a string')
        return False
    return True

def check_deploy_via_media_oam_syntax(cloud_data):
    if 'deploy_via_media_oam' not in cloud_data:
        print('ERROR: deploy_via_media_oam is not defined')
        return False
    if not (cloud_data['deploy_via_media_oam'] == "yes"):
        print('ERROR: deploy_via_media_oam should be defined as "yes": ' + str(cloud_data['deploy_via_media_oam']))
        return False
    return True

def check_site_name_syntax(cloud_data):
    if 'site_name' not in cloud_data:
        print('ERROR: site_name is not defined')
        return False
    if not _is_str(cloud_data['site_name']):
        print('ERROR: site_name should be a string: ' + str(cloud_data['site_name']))
        return False
    return True

def check_media_qcow2name_syntax(cloud_data):
    if 'media_qcow2name' not in cloud_data:
        print('ERROR: media_qcow2name is not defined')
        return False
    if not _is_str(cloud_data['media_qcow2name']):
        print('ERROR: media_qcow2name should be a string: '  + str(cloud_data['media_qcow2name']))
        return False
    return True

def check_vm_resource_numbers_syntax(cloud_data):
    if 'vm_resource_numbers' not in cloud_data:
        print('ERROR: vm_resource_numbers is not defined')
        return False
    vm_resource_numbers = cloud_data['vm_resource_numbers']
    if not isinstance(vm_resource_numbers, dict):
        print('ERROR: Invalid vm_resource_numbers format')
        return False
    for vm_type in ['MCM']:
        if vm_type not in vm_resource_numbers:
            print('ERROR: ' + vm_type + ' numbers is not defined in vm_resource_numbers')
            return False
        vm_config = vm_resource_numbers[vm_type]
        if not isinstance(vm_config, dict):
            print('ERROR: Invalid vm_resource_numbers format')
            return False
        for num_key in ['max', 'init']:
            if num_key not in vm_config:
                print('ERROR: ' + num_key + ' of ' + vm_type +' is not defined in vm_resource_numbers')
                return False
            if not isinstance(vm_config[num_key], int):
                print('ERROR: Resource number should be a integer')
                return False
            if vm_config[num_key] not in [0, 1]:
                print('ERROR: ' + vm_type + ' ' + num_key + ' Resource number should be defined as "0" or "1": ' + str(vm_config[num_key]))
                return False
        if vm_config['max'] < vm_config['init']:
                print('ERROR: ' + vm_type + ' Resource number init value should less or equal to max value')
                return False

    return True

def check_ip_config_syntax_14_1(ip_config_info, net_type):
    if not ip_config_info:
        return True

    for ipver in ['ipv4', 'ipv6']:
        if ipver in ip_config_info:
            ip_info = ip_config_info[ipver]
            if not isinstance(ip_info, dict):
                print('ERROR: Invalid IP config format: ' + str(ip_info))
                return False
            if 'fixed_ips' in ip_info:
                fixed_ips = ip_info['fixed_ips']
                if not isinstance(fixed_ips, list):
                    print('ERROR: Invalid IP config format: ' + str(fixed_ips))
                    return False
                if len(fixed_ips) != 2:
                    print('ERROR: fixed_ips should have two elements: ' + str(fixed_ips))
                    return False
                for ip in fixed_ips:
                    if not _is_str(ip):
                        print('ERROR: IP address should be a string: ' + str(ip))
                        return False

            if 'vip_ip' in ip_info:
                vip_ip = ip_info['vip_ip']
                if not _is_str(vip_ip) and not isinstance(vip_ip, list):
                    print('ERROR: ' + str(net_type) + ' IP address should be a string or list: ' + str(vip_ip))
                    return False
                if isinstance(vip_ip, list):
                    if net_type in ['OAM', 'mate_OAM']:
                        vip_length = 1
                    if net_type in ['SIG', 'mate_SIG', 'SIG2', 'mate_SIG2']:
                        vip_length = 32
                    if len(vip_ip) > vip_length:
                        print('ERROR: ' + str(net_type) + ' IP address must not exceed ' + str(vip_length) + ': ' + str(vip_ip))
                        return False

            if 'prefix' in ip_info:
                prefix = ip_info['prefix']
                if not _is_str(prefix):
                    print('ERROR: prefix should be a string: ' + str(prefix))
                    return False
            if 'gw' in ip_info:
                gw = ip_info['gw']
                if not _is_str(gw):
                    print('ERROR: gw should be a string: ' + str(gw))
                    return False
    return True

def check_external_ip_config_syntax(cloud_data):
    if 'external_ip_config' not in cloud_data:
        return True

    external_ip_config = cloud_data['external_ip_config']
    if not isinstance(external_ip_config, dict):
        print('ERROR: Invalid external_ip_config format')
        return False
    for red_name in external_ip_config:
        if red_name == 'SCM':
            scm_ip_config_infos = external_ip_config['SCM']
            if not isinstance(scm_ip_config_infos, dict):
                print('ERROR: Invalid external_ip_config format for SCM')
                return False
            for net_type in ['SIG', 'OAM', 'SIG2']:
                if net_type not in scm_ip_config_infos:
                    continue
                scm_ip_config_info = scm_ip_config_infos[net_type]
                if not isinstance(scm_ip_config_info, dict):
                    print('ERROR: Invalid external_ip_config format for SCM')
                    return False
                if not check_ip_config_syntax_14_1(scm_ip_config_info, net_type):
                    return False
            if 'network' in scm_ip_config_infos['SIG']:
                if 'SIG2' not in scm_ip_config_infos:
                    print('ERROR: SIG2 should define if SIG vlan id has been defined')
                    return False
                elif 'network' not in scm_ip_config_infos['SIG2']:
                    print('ERROR: SIG2 vlan id must define')
                    return False
            else:
                if 'SIG2' in scm_ip_config_infos:
                    print('ERROR: No need to define SIG2 while vlan id of SIG has not been defined')
                    return False

    return True

def check_cloud_res_syntax_14_1(cloud_data):
    if not cloud_data:
        print('ERROR: Resource file is empty')
        return False

    if not isinstance(cloud_data, dict):
        print('ERROR: Invalid cloud resource data file')
        return False

    if not check_platform_syntax(cloud_data):
        return False

    if not check_deploy_via_media_oam_syntax(cloud_data):
        return False

    if not check_site_name_syntax(cloud_data):
        return False

    if not check_media_qcow2name_syntax(cloud_data):
        return False

    if not check_vm_resource_numbers_syntax(cloud_data):
        return False

    if not check_external_ip_config_syntax(cloud_data):
        return False

    return True


def data_check(resource_file):
    cloud_data = load_yaml_file(resource_file)
    if not cloud_data:
        return False

    if not check_cloud_res_syntax_14_1(cloud_data):
        return False

    return True


def main(argv):

    resource_file = 'media-vars/media-resource-data.yaml'

    ret_val = data_check(resource_file)
    if ret_val:
        sys.exit(0)
    else:
        sys.exit(1)


if __name__ == "__main__":
    main(sys.argv)
