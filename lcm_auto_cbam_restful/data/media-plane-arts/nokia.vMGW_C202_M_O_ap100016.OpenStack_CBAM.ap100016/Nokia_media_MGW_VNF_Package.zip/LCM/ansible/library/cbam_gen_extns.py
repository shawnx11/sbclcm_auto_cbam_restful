#!/usr/bin/env python

# --------------------------------------------------------------------------- #
"""Generates DR extensions file."""

# --------------------------------------------------------------------------- #
# Core modules.
import argparse
import json
import os
import re
import sys
from subprocess import Popen, PIPE, STDOUT

# --------------------------------------------------------------------------- #
# Argument values.
arg_values = None

# --------------------------------------------------------------------------- #
# Extra vars dictionary.
extra_vars_dict = {}

# --------------------------------------------------------------------------- #
def load_from_json_file(json_file, data_dict):
    """Loads data from the JSON file into the given dictionary.
       Returns data dictionary on success or None on error.
       """
    try:
        with open(json_file, 'r') as jFile:
            data_dict = json.load(jFile)
            return data_dict
    except Exception as exc:
        print('ERROR: Failed to load data from {0}.\n[{1}]'.format(
            json_file, str(exc)))
    
    return None

# --------------------------------------------------------------------------- #
def gen_extns_file():
    """Generates the DR extensions file."""

    cbam_extns_dict = extra_vars_dict['extensions']
    extns_dict = {}
    extns_dict['extensions'] = []

    for ex_key, ex_val in cbam_extns_dict.items():
        inner_dict = {}
        inner_dict['name'] = ex_key
        inner_dict['value'] = ex_val

        extns_dict['extensions'].append(inner_dict)

    extns_file = 'DR.extensions.json'
    try:
        with open(extns_file, 'w') as jFile:
            json.dump(extns_dict, jFile, indent=4)
    except Exception as exc:
        print('ERROR: Failed to write data to {0}.\n[{1}]'.format(
            extns_file, str(exc)))
        sys.exit(1)

# --------------------------------------------------------------------------- #
def load_orgi_dr_extns():
    """Load data from the original DR extensions JSON file."""

    global extra_vars_dict
    extra_vars_dict = load_from_json_file(
        arg_values.orgi_dr_extns_json,
        extra_vars_dict)
    
    if (extra_vars_dict == None):
        sys.exit(1)

# --------------------------------------------------------------------------- #
def parse_args():
    """Parse script arguments."""

    script_desc = 'DR extensions file generator.'

    args_parser = argparse.ArgumentParser(description=script_desc)
    args_parser.add_argument('orgi_dr_extns_json',
        help='Original DR extensions JSON file')    
    
    # Parse the arguments.
    global arg_values
    arg_values = args_parser.parse_args()

# --------------------------------------------------------------------------- #
def main():
    """Script entry point."""

    # Parse arguments.
    parse_args()

    # Load original DR extensions to dictionary.
    load_orgi_dr_extns()

    # Generate the extensions file.
    gen_extns_file()

# --------------------------------------------------------------------------- #
# Execute when run as a script.
if (__name__ == "__main__"):
    main()
