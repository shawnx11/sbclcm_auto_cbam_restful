#!/usr/bin/env bash

path=$1
scm_tipc_ip=$2
user=$3
key_file=$4
shift 4
ip_arraystring=$*
temp1=$(echo $ip_arraystring|sed s/[[:space:]]//g)
temp=$(echo $temp1|cut -d "[" -f 2)
ip_array=$(echo $temp|cut -d ']' -f 1)
OLD_IFS="$IFS"
IFS=","
array=($ip_array)
IFS="$OLD_IFS"

if [[ ! -f $key_file ]]
then
   echo "There is no $key_file on this host"
   exit 1
fi

for tempip in ${array[*]}
do
  ip=$(echo $tempip|cut -d 'u' -f 2)

  if [ "$ip" != "$scm_tipc_ip" ]
  then 
    #transfer key.pem to vm
    scp -o StrictHostKeyChecking=no -i $key_file $key_file $user@$ip:$key_file
    #transfer tar.gz file
    ssh -t -o StrictHostKeyChecking=no -i $key_file $user@$ip "cd $path;sudo scp -o StrictHostKeyChecking=no -i $key_file $user@$scm_tipc_ip:/mnt/backup/$ip.tar.gz .;cd $path;sudo sudo tar --same-owner -zxvpf $ip.tar.gz;sleep 25s;rm -rf $ip.tar.gz"
  else
    #transfer tar.gz file on SCM (localhost)
    cd $path;sudo cp /mnt/backup/$ip.tar.gz .;sudo sudo tar --same-owner -zxvpf $ip.tar.gz;sleep 25s;rm -rf $ip.tar.gz
  fi
done
sleep 50s

