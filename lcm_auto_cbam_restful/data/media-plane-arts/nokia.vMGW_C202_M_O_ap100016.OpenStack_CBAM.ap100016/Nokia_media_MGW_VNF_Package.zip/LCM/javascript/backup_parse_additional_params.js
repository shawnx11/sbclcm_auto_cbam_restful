var retMap = {
  "rc": "0",
  "err_msg": "",
  "backup_server_ip1": "",
  "backup_server_dir1": "",
  "backup_server_user_name1": "",
  "backup_server_credentials1": "",
  "backup_server_ip2": "",
  "backup_server_dir2": "",
  "backup_server_user_name2": "",
  "backup_server_credentials2": ""
};

// Valid pattern example: "johndoe@10.1.12.19:/home/johndoe/rje"
var default_server_str = "<user@IPaddress:/path>";
var default_creds1_str = "<First Backup Server Security Certificate>";
var default_creds2_str = "<Second Backup Server Security Certificate>";

//get remote server info from addlParams
var backup_server_info1 = ($.addlParams.backup_server1).trim();
var backup_server_info2 = ($.addlParams.backup_server2).trim();
var backup_server_credentials1 = ($.addlParams.backup_server_credentials1).trim();
var backup_server_credentials2 = ($.addlParams.backup_server_credentials2).trim();

var reg_patt = /^(.*)@(.*):(.*)$/mi;
var matchArr1 = null;
var matchArr2 = null;

// If the Backup Server value in the CBAM GUI text box is empty, ignore it.
if ((backup_server_credentials1 !== default_creds1_str) && (backup_server_credentials1 !== "")){
   retMap.backup_server_credentials1 = backup_server_credentials1;
}

if ((backup_server_credentials2 !== default_creds2_str) && (backup_server_credentials2 !== "")){
   retMap.backup_server_credentials2 = backup_server_credentials2;
}

if (( backup_server_info1 !== default_server_str) && (backup_server_info1 !== "")) {
  matchArr1 = reg_patt.exec(backup_server_info1);
}

if ((backup_server_info2 !== default_server_str) && (backup_server_info2 !== "")) {
  matchArr2 = reg_patt.exec(backup_server_info2);
}

if (matchArr1 || matchArr2) {
  if (matchArr1) {
    retMap.backup_server_user_name1 = matchArr1[1];
    retMap.backup_server_ip1 = matchArr1[2];
    retMap.backup_server_dir1 = matchArr1[3];
  }
  if (matchArr2) {
    retMap.backup_server_user_name2 = matchArr2[1];
    retMap.backup_server_ip2 = matchArr2[2];
    retMap.backup_server_dir2 = matchArr2[3];
  }
}
else if ((backup_server_info1 !== default_server_str) && (backup_server_info1 !== "") ||
         (backup_server_info2 !== default_server_str) && (backup_server_info2 !== "")) {
  retMap.rc = "1";
  retMap.err_msg = "Invalid format for backup server info.";
}
return retMap;

