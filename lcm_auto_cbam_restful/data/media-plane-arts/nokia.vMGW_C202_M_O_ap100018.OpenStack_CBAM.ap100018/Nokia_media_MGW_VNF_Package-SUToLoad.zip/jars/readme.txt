
jars in this dir are for vmware independent disk operation:
attach
detach
delete

