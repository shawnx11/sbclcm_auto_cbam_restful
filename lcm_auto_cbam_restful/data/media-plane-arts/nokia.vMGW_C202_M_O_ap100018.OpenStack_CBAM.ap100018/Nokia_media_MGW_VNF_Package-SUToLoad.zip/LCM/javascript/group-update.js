var script=[
"#!/bin/sh", 
"echo \"$1\" >> /root/params",
"if [ \"x$1\" = \"xprecustomization\" ]; then", 
"  export LC_ALL=\"en_US.UTF-8\"", 
"fi", 
"if [ \"x$1\" = \"xpostcustomization\" ]; then", 
"cd /opt/v7510/bin/",
"./cloud_init_disable.sh",
"./v7510_OS_vmware_tools_script.sh",
"fi", 
"exit 0"
].join("\n")

function isNumeric(n) {
 return !isNaN(parseFloat(n)) && isFinite(n)
}

function getCustomization(imageId){
  if(imageId.includes("scm"))
  {
   return script;
   }
  if(imageId.includes("pim"))
  {
   return script;
   }
  if(imageId.includes("mcm"))
  {
   return script;
   }
}

function stackParamsUpdate(cbam) {
  mcm_grp_num = parseInt(cbam.resources.MCM_Server_Group.count);
  pim_grp_num = parseInt(cbam.resources.PIM_Server_Pair_Group.count);

  if(cbam.extensions.default_action == "recreate")
  {
    if((mcm_grp_num != 0)||(pim_grp_num != 0))
    {
      throw "Select restore_level as instantiation level id when recreate after disaster";
    }
  }
  else
  {
    if((mcm_grp_num == 0)&&(pim_grp_num == 0))
    {
      throw "restore_level as instantiation level id only in disaster recovery";
    }
  }

  if(cbam.extensions.default_action != "recreate")
  {
    return cbam;
  }

  cbam.resources = cbam.extensions.resource_backup;
  if(cbam.extensions.media_params.platform == "VMWare"){
    for(var aspectGroupID in cbam.resources){
      for(var step in cbam.resources[aspectGroupID]){
        if(isNumeric(step)){
          cbam.resources[aspectGroupID][step].server.configuration.publicSshKey = cbam.publicSshKey;
          cbam.resources[aspectGroupID][step].server.script = getCustomization(cbam.resources[aspectGroupID][step].server.imageId);
        }
      }
    } 
  }

  cbam.vdus = cbam.extensions.vdus_backup;

  return cbam;
}
