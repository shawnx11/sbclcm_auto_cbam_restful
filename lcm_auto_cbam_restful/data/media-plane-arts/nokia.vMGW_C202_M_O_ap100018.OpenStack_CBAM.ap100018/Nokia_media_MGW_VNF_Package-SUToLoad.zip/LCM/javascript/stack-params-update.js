return {
    cbam: stackParamsUpdate($.stack_params.cbam)
}
