var ansible_extra_vars = {
  "vm_user": "",
  "appl_user": "",
};

ansible_extra_vars.vm_user = ($.operation_result.vm_user).trim();
ansible_extra_vars.appl_user = ($.operation_result.appl_user).trim();

return ansible_extra_vars;

