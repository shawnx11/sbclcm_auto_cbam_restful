function parse_vm_user() {
    var default_vm_user = "This user is mandatory when the lcm_admin_user has been updated!";
    var lcm_admin_user = ($.stack_params.cbam.extensions.lcm_admin_user).trim();
    var vm_user = (addlParams.lcm_user).trim();

    if (lcm_admin_user == "cloud-user") {
        if ((vm_user == default_vm_user) || (vm_user == "") || (vm_user == "cloud-user"))
            retMap.vm_user = "cloud-user";
        else
            throw "lcm_user is not needed when the lcm_admin_user is cloud-user!";
    }
    else {
        if ((vm_user == default_vm_user) || (vm_user == "")) 
            throw "lcm_user is mandatory when the lcm_admin_user is not cloud-user!";
        else if ( vm_user == lcm_admin_user)
            throw "lcm_user can not be same with lcm_admin_user!";
        else
            retMap.vm_user = vm_user;
    }
}

function parse_image() {
    retMap["imageId"] = "";
    var default_imageId = "new image name";
    var imageId = (addlParams.image).trim();
    if ((imageId == default_imageId) || (imageId == "")) {
        throw "Invalid input image!";
    }
    else { 
        retMap["imageId"] = imageId;
    }
}

function parse_template() {
    retMap["templateName"] = "";
    var default_templateName = "new vApp template";
    var templateName = (addlParams.new_template_name).trim();
    if ((templateName == default_templateName) || (templateName == "")) {
        throw "Invalid input new vApp temlate name!";
    }
    else {
        retMap["templateName"] = templateName;
    }
}
function parse_remote_server_info() {
    var remote_server_info = {
        "backup_server_credentials1": "",
        "backup_server_credentials2": "",
        "backup_server_user_name1": "",
        "backup_server_user_name2": "",
        "backup_server_ip1": "",
        "backup_server_ip2": "",
        "backup_server_dir1": "",
        "backup_server_dir2": ""
    }

    // Valid pattern example: "johndoe@10.1.12.19:/home/johndoe/rje"
    var default_server_str = "<user@IPaddress:/path>";
    var default_creds1_str = "<First Backup Server Security Certificate>";
    var default_creds2_str = "<Second Backup Server Security Certificate>";
    
    //get remote server info from addlParams
    var backup_server_info1 = (addlParams.backup_server1).trim();
    var backup_server_info2 = (addlParams.backup_server2).trim();
    var backup_server_credentials1 = (addlParams.backup_server_credentials1).trim();
    var backup_server_credentials2 = (addlParams.backup_server_credentials2).trim();
    
    var reg_patt = /^(.*)@(.*):(.*)$/mi;
    var matchArr1 = null;
    var matchArr2 = null;
    
    // If the Backup Server value in the CBAM GUI text box is empty, ignore it.
    if ((backup_server_credentials1 !== default_creds1_str) && (backup_server_credentials1 !== "")){
       remote_server_info.backup_server_credentials1 = backup_server_credentials1;
    }
    
    if ((backup_server_credentials2 !== default_creds2_str) && (backup_server_credentials2 !== "")){
       remote_server_info.backup_server_credentials2 = backup_server_credentials2;
    }
    
    if (( backup_server_info1 !== default_server_str) && (backup_server_info1 !== "")) {
      matchArr1 = reg_patt.exec(backup_server_info1);
    }
    if ((backup_server_info2 !== default_server_str) && (backup_server_info2 !== "")) {
      matchArr2 = reg_patt.exec(backup_server_info2);
    }
    
    if (matchArr1 || matchArr2) {
      if (matchArr1) {
        remote_server_info.backup_server_user_name1 = matchArr1[1];
        remote_server_info.backup_server_ip1 = matchArr1[2];
        remote_server_info.backup_server_dir1 = matchArr1[3];
      }
      if (matchArr2) {
        remote_server_info.backup_server_user_name2 = matchArr2[1];
        remote_server_info.backup_server_ip2 = matchArr2[2];
        remote_server_info.backup_server_dir2 = matchArr2[3];
      }
    }
    else if ((backup_server_info1 !== default_server_str) && (backup_server_info1 !== "") ||
             (backup_server_info2 !== default_server_str) && (backup_server_info2 !== "")) {
        throw "Invalid format for backup server info!";
    }
    retMap["remote_server_info"] = remote_server_info;
}
function parse_register_account() {
    retMap["lcm_user"] = "";
    retMap["rc"] = 0;
    var lcm_user = (addlParams.lcm_user).trim();
    var appl_user = (addlParams.appl_user).trim();
    var appl_passwd = (addlParams.appl_passwd).trim();
    var passphrase = (addlParams.lcm_admin_passphrase).trim();
    var inject_well_known_temp_key = (addlParams.inject_well_known_temp_key).trim();
    var lcm_admin_user = $.stack_params.cbam.extensions.lcm_admin_user
    if (lcm_admin_user == "cloud-user"){
       retMap.rc = 1;
       throw "this function is not support when lcm_admin_user is 'cloud-user',please update lcm_admin_user first!";
     }
    if (lcm_user.length === 0||appl_user.length === 0||appl_passwd.length === 0||passphrase.length === 0) 
    {
       retMap.rc = 1;
       throw "Invalid input parameter,value cannot be empty";
     }
    if (lcm_user == "cloud-user"){
       retMap.rc =1;
       throw "cannot register the cloud-user, please use other lcm user name!";
   }
    if (lcm_user == lcm_admin_user) {
       retMap.rc = 1;
       throw "lcm_user cannot be the same with lcm_admin_user";
   }
    if (inject_well_known_temp_key.toLowerCase()!="no"&&inject_well_known_temp_key.toLowerCase()!="yes"){
       retMap.rc = 1;
       throw "the value of the inject_wll_known_temp_key can only be yes or no!";
 }
    retMap.lcm_user = lcm_user;
    retMap.appl_user = appl_user;
    retMap.appl_passwd = appl_passwd;
    retMap.passphrase = passphrase;
}
function parse_unregister_account(){
    retMap["rc"] = 0;
    retMap["lcm_user"] = "";
    retMap["passphrase"] = "";
    var lcm_user = (addlParams.lcm_user).trim();
    var passphrase = (addlParams.lcm_admin_passphrase).trim();
    var lcm_admin_user = $.stack_params.cbam.extensions.lcm_admin_user
    if (lcm_admin_user == "cloud-user"){
       retMap.rc = 1;
       throw "this function is not support when lcm_admin_user is 'cloud-user',please update lcm_admin_user first!";
     }
    if (lcm_user.length === 0) {
       retMap.rc = 1;
       throw "Invalid input parameter,lcm user value cannot be empty";
     }
    if (passphrase.length === 0) {
       retMap.rc = 1;
       throw "Invalid input parameter,lcm admin passphrase cannot be empty";
     }
    if (lcm_user == lcm_admin_user) {
       retMap.rc = 1;
       throw "lcm_user cannot be the same with lcm_admin_user";
   }
    retMap.lcm_user = lcm_user;
    retMap.passphrase = passphrase;
}
function parse_backup_url(){
    retMap["backup_url"] = ""; 
    var default_url = "backup url"
    var url = (addlParams.BackupUrl).trim();
    if ((url == default_url) || (url == "")) {
        throw "BackupUrl is mandatory when doing resotre!"
    }
    var reg_patt=/^(http|ftp|https):\/\/./;
    if (reg_patt.test(url) == false){
        throw "Invalid pattern of BackupUrl!";
    }
    else{
        retMap["backup_url"] = url; 
    }
}   

function parse_vnfc_heal_list() {
    var default_vnfcHealList = "<one or more comma separated vm names>"
    var vnfcHealList = (addlParams.vmHealList).trim();
    if ((vnfcHealList == default_vnfcHealList) || (vnfcHealList == "")) {
        throw "vmHealList not specified!";
    }
    var platform = $.stack_params.cbam.extensions.media_params.platform
    if (platform == "OpenStack")
    {
        var SCM10_Name = "010"
        var SCM11_Name = "011"
    }
    else if (platform == "VMWare")
    {
        var SCM10_Name = $.stack_params.cbam.resources.SCM_Server_Pair[0].server.name
        var SCM11_Name = $.stack_params.cbam.resources.SCM_Server_Pair[1].server.name
    }
    if (vnfcHealList.indexOf(SCM10_Name)>=0 && vnfcHealList.indexOf(SCM11_Name)>=0){
        throw "SCM10 and SCM11 cannot been heal at the same time.";
    } 

    retMap["vnfcHealList"] = vnfcHealList;
}
function parse_update_lcm_admin_user() {
    var curlcmadminuser = ($.stack_params.cbam.extensions.lcm_admin_user).trim();
    var newlcmadminuser = (addlParams.new_lcm_admin_user).trim()
    var currpassphrase = (addlParams.current_passphrase).trim()
    var newpassphrase = (addlParams.new_passphrase).trim()
    var confirmpassphrase = (addlParams.confirm_new_passphrase).trim()
    if(newlcmadminuser=="cloud-user"&&(newpassphrase!=""||confirmpassphrase!=""))
    { 
      throw "If the new_lcm_admin_user is cloud-user,the newpassphrase must be empty!"
    }
    else if(newlcmadminuser!="cloud-user"&&(newpassphrase==""||confirmpassphrase==""))
    {
      throw "The new passphrase and the confirm passphrase must been provided"
    }
    else if((newlcmadminuser == curlcmadminuser)&&(newlcmadminuser == "cloud-user"))
    {
       throw "cloud-user is not permitted to change its passphrase"
    }
    else if(newpassphrase!=confirmpassphrase)
    {
      throw "The confirm lcm admin passphrase is not the same with the new lcm admin passphrase"
    }
    else if (curlcmadminuser !="cloud-user"&&currpassphrase=="")
    {
      throw "The current lcm admin passphrase must been provided"
    }
    else if(newlcmadminuser.length === 0)
    {
      throw "new lcm admim user is null, Invalid input parameter!"
    }  
      retMap.lcm_admin_user = newlcmadminuser
      retMap.curr_passphrase = currpassphrase
      retMap.new_passphrase = newpassphrase
      retMap.confirm_passphrase = confirmpassphrase
}

//Main 
var addlParams = $.operation_params.additionalParams;

// Setup retMap
var retMap = { 
  "vm_user": "cloud-user",
  "appl_user": "diag"
};
 
//for custom workflow
if ($.op_type === "nssu" || $.op_type === "issu") {
  var platform = $.stack_params.cbam.extensions.media_params.platform
  if (platform == "OpenStack")
  {
    parse_image();
  }
  else if (platform == "VMWare")
  {
    parse_template();
  }
    parse_vm_user();
    return retMap;
}
else if ($.op_type === "backup") {
    parse_vm_user();
    parse_remote_server_info();
    return retMap;
}
else if ($.op_type === "restore") {
    parse_vm_user();
    parse_backup_url();
    return retMap;
}
else if ($.op_type === "auto_scale") {
    retMap["aspectList"] = $.aspect_list;
}
else if ($.op_type === "heal") {
    parse_vm_user();
    parse_vnfc_heal_list();
    return retMap;
}
else if (($.op_type === "backout") || ($.op_type === "rollback")) {
    parse_vm_user();
    parse_backup_url();
    return retMap;
}
else if ($.op_type === "post_dr_recovery") {

    return retMap;
}
else if ($.op_type === "register") {
    parse_register_account();
    return retMap;
}
else if ($.op_type === "unregister") {
    parse_unregister_account();
    return retMap;
}
else if ($.op_type === "update_lcm_admin_user"){
    parse_update_lcm_admin_user();
    return retMap;    
}
//for built-in workflow
else if (typeof($.operation_params) !== "undefined") {
    //scale action
    if (("type" in $.operation_params) && (($.operation_params.type == "in") || $.operation_params.type == "out")) {
        parse_vm_user();
        return retMap;
    }
    //reinstall for disaster recovery
//    else if (typeof(addlParams) !== "undefined") {
//        if (("disasterRecovery" in addlParams) && (providerType == "VMWARE")) {
//            if (addlParams.disasterRecovery === "") {
//                retMap["FIELD_INSTALL"] = "TRUE";
//            }
//            else {
//                   retMap["FIELD_INSTALL"] = "FALSE";
//            }
//        } else if (("backup_file1" in addlParams) || ("backup_file2" in addlParams)) {
//            if ((addlParams.backup_file1 === "") && (addlParams.backup_file2 === "")) {
//                retMap["FIELD_INSTALL"] = "TRUE";
//            }
//            else {
//                retMap["FIELD_INSTALL"] = "FALSE";
//            }
//        }
//    }
}

return retMap;

