#!/bin/bash

# kill_scm_appl.sh
# -------------------
# Script to stop monit and v7510 service of plane B after plane split
# Script to stop monit and v7510 service of plane A after system take over

systemctl stop monit
systemctl stop v7510
