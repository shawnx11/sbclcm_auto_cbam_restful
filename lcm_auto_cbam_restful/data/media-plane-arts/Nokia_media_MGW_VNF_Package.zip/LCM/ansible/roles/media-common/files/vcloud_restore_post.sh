#!/usr/bin/env bash

path=$1
scm_tipc_ip=$2
user=$3
key_file=$4
shift 4
ip_arraystring=$*
temp1=$(echo $ip_arraystring|sed s/[[:space:]]//g)
temp=$(echo $temp1|cut -d "[" -f 2)
ip_array=$(echo $temp|cut -d ']' -f 1)
OLD_IFS="$IFS"
IFS=","
array=($ip_array)
IFS="$OLD_IFS"
file="/opt/v7510/data/.vmware_delay"

if [[ ! -f $key_file ]]
then
   echo "There is no $key_file on this host"
   exit 1
fi

for tempip in ${array[*]}
do
  if [[ -f $key_file ]]
  then
    ip=$(echo $tempip|cut -d 'u' -f 2)
    if [ "$ip" != "$scm_tipc_ip" ]
    then
      # delete .vmware_delay from host
      if ssh $user@$ip -i $key_file -o StrictHostKeyChecking=no test -e $file
      then 
        ssh -t $user@$ip -i $key_file -o StrictHostKeyChecking=no "sudo rm -f $file;echo $file existed on $ip, has been deleted"
      else 
        echo "$file does not exist on $ip"
      fi
      #cleanup - delete key file
      if ssh $user@$ip -i $key_file -o StrictHostKeyChecking=no test -e $key_file
      then 
        ssh -t $user@$ip -i $key_file -o StrictHostKeyChecking=no "sudo rm -f $key_file;echo $key_file existed on $ip, has been deleted"
      else 
        echo "$key_file does not exist on $ip"
      fi
    
    fi
  else 
    echo "$key_file does not exist on $scm_tipc_ip"
  fi
done

#cleanup - delete key file from scm
if [[ -f $key_file ]] 
then
  sudo rm -f $key_file
  echo "$key_file existed on $scm_tipc_ip, has been deleted"
else 
  echo "$key_file does not exist on $scm_tipc_ip"
fi

#delete .vmware_delay from scm
if [[ -f $file ]] 
then
  sudo rm -f $file
  echo "$file existed on $scm_tipc_ip, has been deleted"
else 
  echo "$file does not exist on $scm_tipc_ip"
fi

